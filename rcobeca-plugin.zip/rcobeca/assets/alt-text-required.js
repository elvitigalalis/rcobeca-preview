/**
 * The block editor will not save while an image in the post has no alt text:
 * an Image, Media & Text or Cover block's photo, or the featured image (whose
 * alt text lives in the media library). It locks saving and says what needs
 * it (includes/alt-text.php).
 */
( function ( wp ) {
	const { select, dispatch, subscribe } = wp.data;
	const ID = 'rcobeca-alt-text';
	const blank = ( text ) => ! ( text || '' ).trim();

	const missing = ( blocks ) =>
		blocks.reduce( ( count, block ) => {
			const a = block.attributes;
			const bad =
				( block.name === 'core/image' && a.url && blank( a.alt ) ) ||
				( block.name === 'core/media-text' && a.mediaType === 'image' && a.mediaUrl && blank( a.mediaAlt ) ) ||
				( block.name === 'core/cover' && ( a.backgroundType || 'image' ) === 'image' && a.url && ! a.useFeaturedImage && blank( a.alt ) );
			return count + ( bad ? 1 : 0 ) + missing( block.innerBlocks || [] );
		}, 0 );

	// The featured image's alt text, once the media library answers (undefined until then).
	const featuredMissing = () => {
		const id = select( 'core/editor' ).getEditedPostAttribute( 'featured_media' );
		if ( ! id ) {
			return false;
		}
		const media = select( 'core' ).getMedia( id, { context: 'view' } );
		return !! media && blank( media.alt_text );
	};

	let last = '';
	subscribe( () => {
		if ( ! select( 'core/editor' ).getCurrentPostId() ) {
			return;
		}
		const count = missing( select( 'core/block-editor' ).getBlocks() );
		const featured = featuredMissing();
		const state = count + '/' + featured;
		if ( state === last ) {
			return;
		}
		last = state;
		if ( ! count && ! featured ) {
			dispatch( 'core/editor' ).unlockPostSaving( ID );
			dispatch( 'core/notices' ).removeNotice( ID );
			return;
		}
		const problems = [];
		if ( count ) {
			problems.push(
				( count === 1 ? '1 image has no alt text.' : count + ' images have no alt text.' ) +
					' Select each image and describe it under “Alternative text” in its settings (who, what, where).'
			);
		}
		if ( featured ) {
			problems.push( 'The featured image has no alt text. Open it from “Featured image” and describe it under “Alternative text”.' );
		}
		dispatch( 'core/editor' ).lockPostSaving( ID );
		dispatch( 'core/notices' ).createWarningNotice( problems.join( ' ' ) + ' The post can be saved once every image has it.', {
			id: ID,
			isDismissible: false,
		} );
	} );
} )( window.wp );
