/**
 * Editor UI shared by the data-view blocks (Committee, Committee history,
 * Past Presidents, Life Members, Person details): each previews its
 * server-rendered output, and offers in the sidebar the attributes its
 * block.json gives a "label". Plain script, no build step; the block list
 * comes from includes/data-view-blocks.php.
 */
( function ( blocks, element, blockEditor, components, ServerSideRender ) {
	const el = element.createElement;

	function control( props, key, field ) {
		const common = { key, label: field.label, help: field.help, __nextHasNoMarginBottom: true };
		if ( 'boolean' === field.type ) {
			return el( components.ToggleControl, Object.assign( common, {
				checked: !! props.attributes[ key ],
				onChange: ( value ) => props.setAttributes( { [ key ]: value } ),
			} ) );
		}
		return el( components.TextControl, Object.assign( common, {
			value: props.attributes[ key ] || '',
			onChange: ( value ) => props.setAttributes( { [ key ]: value } ),
		} ) );
	}

	Object.entries( window.rcobecaDataViewBlocks || {} ).forEach( function ( [ name, fields ] ) {
		blocks.registerBlockType( name, {
			edit( props ) {
				const inputs = Object.entries( fields ).map( ( [ key, field ] ) => control( props, key, field ) );
				return el(
					'div',
					blockEditor.useBlockProps(),
					inputs.length ? el( blockEditor.InspectorControls, null, el( components.PanelBody, { title: 'Settings' }, inputs ) ) : null,
					el( components.Disabled, null, el( ServerSideRender, { block: name, attributes: props.attributes } ) )
				);
			},
			save: () => null,
		} );
	} );
} )( window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.components, window.wp.serverSideRender );
