<?php
/**
 * Renders the home page's Royal Charity Ball band: the current Ball (the one
 * /ball/ is about) in the state its Event is in, so the band never sells last
 * year's tickets. With a Ball-night photo: the headline, details and next
 * step left, the photo right. Without one: the headline left; date, venue
 * and the next step right.
 *
 * @package RCOBECA
 *
 * @var array $attributes Block attributes: image (a Ball-night photo).
 */

use RCOBECA\Events;

defined( 'ABSPATH' ) || exit;

$rcobeca_ball  = Events::current_ball();
$rcobeca_state = $rcobeca_ball ? Events::state( $rcobeca_ball ) : Events::BETWEEN;
$rcobeca_named = Events::edition_title( $rcobeca_ball );
$rcobeca_when  = $rcobeca_ball ? trim( Events::date_label( $rcobeca_ball ) . ( '' !== Events::place( $rcobeca_ball ) ? "\n" . Events::place( $rcobeca_ball ) : '' ) ) : '';
$rcobeca_raise = $rcobeca_ball ? Events::get( $rcobeca_ball, 'funds_raised' ) : '';

$rcobeca_texts  = array(
	Events::SAVE_THE_DATE => __( 'Dinner, music and dancing for Royal College. Tickets go on sale soon.', 'rcobeca' ),
	Events::ON_SALE       => __( 'Dinner, music and dancing for Royal College. Book your seats, or support the evening with a sponsorship or a Souvenir Journal ad.', 'rcobeca' ),
	Events::SOLD_OUT      => __( 'Every seat is taken: thank you! A gift still funds Royal College.', 'rcobeca' ),
	Events::BALL_NIGHT    => __( 'Welcome! Find your table by typing your full name.', 'rcobeca' ),
	Events::THANK_YOU     => __( 'Thank you to every guest, sponsor, advertiser and volunteer who made the evening.', 'rcobeca' ),
	Events::BETWEEN       => __( 'Our flagship evening of dinner, music and dancing, whose proceeds fund Royal College and causes in Sri Lanka and the US. The next Ball’s date will be announced here.', 'rcobeca' ),
);
$rcobeca_action = array(
	Events::ON_SALE    => array( home_url( '/ball/#tickets' ), __( 'Buy tickets', 'rcobeca' ) ),
	Events::SOLD_OUT   => array( home_url( '/donate/' ), __( 'Make a donation', 'rcobeca' ) ),
	Events::BALL_NIGHT => array( home_url( '/ball/#find-your-table' ), __( 'Find your table', 'rcobeca' ) ),
)[ $rcobeca_state ] ?? array( home_url( '/ball/' ), __( 'About the Ball', 'rcobeca' ) );

// Between Balls the headline is the Ball itself, and the last one is a fact below it.
$rcobeca_heading = Events::BETWEEN === $rcobeca_state ? __( 'The Royal Charity Ball', 'rcobeca' ) : $rcobeca_named;
$rcobeca_meta    = $rcobeca_when;
if ( Events::BETWEEN === $rcobeca_state && $rcobeca_ball ) {
	$rcobeca_meta = '' !== Events::place( $rcobeca_ball )
		/* translators: 1: e.g. "The 30th Royal Charity Ball", 2: date, 3: venue. */
		? sprintf( __( '%1$s was held on %2$s at %3$s.', 'rcobeca' ), $rcobeca_named, Events::date_label( $rcobeca_ball ), Events::place( $rcobeca_ball ) )
		/* translators: 1: e.g. "The 30th Royal Charity Ball", 2: date. */
		: sprintf( __( '%1$s was held on %2$s.', 'rcobeca' ), $rcobeca_named, Events::date_label( $rcobeca_ball ) );
}
$rcobeca_photo = (int) ( $attributes['image'] ?? 0 );
$rcobeca_photo = wp_attachment_is_image( $rcobeca_photo ) ? $rcobeca_photo : 0;

ob_start();
?>
			<?php if ( '' !== $rcobeca_meta ) : ?>
				<p class="rcobeca-ball-band__meta"><?php echo nl2br( esc_html( $rcobeca_meta ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped first. ?></p>
			<?php endif; ?>
			<p class="rcobeca-ball-band__text"><?php echo esc_html( $rcobeca_texts[ $rcobeca_state ] ); ?></p>
			<?php if ( Events::THANK_YOU === $rcobeca_state && '' !== $rcobeca_raise ) : ?>
				<p class="rcobeca-ball-band__raised"><strong><?php echo esc_html( $rcobeca_raise ); ?></strong> <?php esc_html_e( 'raised', 'rcobeca' ); ?></p>
			<?php endif; ?>
			<div class="wp-block-buttons">
				<div class="wp-block-button is-style-gold"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( $rcobeca_action[0] ); ?>"><?php echo esc_html( $rcobeca_action[1] ); ?></a></div>
				<div class="wp-block-button is-style-outline rcobeca-on-dark"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/ball/past/' ) ); ?>"><?php esc_html_e( 'Past Balls', 'rcobeca' ); ?></a></div>
			</div>
<?php
$rcobeca_details = (string) ob_get_clean();
?>
<section <?php echo get_block_wrapper_attributes( array( 'class' => 'rcobeca-ball-band alignfull is-state-' . $rcobeca_state . ( $rcobeca_photo ? ' has-photo' : '' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> aria-labelledby="rcobeca-ball-band-heading">
	<div class="rcobeca-ball-band__inner">
		<div class="rcobeca-ball-band__main">
			<p class="is-style-kicker"><?php echo esc_html( Events::state_label( $rcobeca_state ) ); ?></p>
			<h2 class="rcobeca-ball-band__heading" id="rcobeca-ball-band-heading"><?php echo esc_html( $rcobeca_heading ); ?></h2>
			<?php echo $rcobeca_photo ? $rcobeca_details : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above. ?>
		</div>
		<div class="rcobeca-ball-band__aside">
			<?php
			if ( $rcobeca_photo ) {
				echo wp_get_attachment_image(
					$rcobeca_photo,
					'large',
					false,
					array(
						'class'   => 'rcobeca-ball-band__photo',
						'loading' => 'lazy',
						'sizes'   => '(max-width: 781px) 100vw, 560px',
					)
				);
			} else {
				echo $rcobeca_details; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
			}
			?>
		</div>
	</div>
</section>
