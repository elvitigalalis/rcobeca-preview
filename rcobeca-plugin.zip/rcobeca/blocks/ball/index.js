/**
 * Editor preview for a server-rendered RCOBECA block (no build step): the
 * editor shows what render.php returns. The sidebar picks the hero photo.
 */
( function ( blocks, element, blockEditor, components, ServerSideRender ) {
	const el = element.createElement;

	blocks.registerBlockType( 'rcobeca/ball', {
		edit: function ( props ) {
			const image = props.attributes.heroImage;
			const pick = function ( open ) {
				return el( components.Button, { variant: 'secondary', onClick: open.open }, image ? 'Replace hero photo' : 'Choose hero photo' );
			};
			return el(
				'div',
				blockEditor.useBlockProps(),
				el(
					blockEditor.InspectorControls,
					null,
					el(
						components.PanelBody,
						{ title: 'Hero photo' },
						el( 'p', null, 'A Ball-night photo behind the title, under a navy overlay.' ),
						el(
							blockEditor.MediaUploadCheck,
							null,
							el( blockEditor.MediaUpload, {
								allowedTypes: [ 'image' ],
								value: image,
								onSelect: function ( media ) {
									props.setAttributes( { heroImage: media.id } );
								},
								render: pick,
							} )
						),
						image
							? el( components.Button, { variant: 'link', isDestructive: true, onClick: function () { props.setAttributes( { heroImage: 0 } ); } }, 'Remove hero photo' )
							: null
					)
				),
				el( ServerSideRender, {
					block: 'rcobeca/ball',
					attributes: props.attributes,
					urlQueryArgs: props.context && props.context.postId ? { post_id: props.context.postId } : {},
				} )
			);
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.components, window.wp.serverSideRender );
