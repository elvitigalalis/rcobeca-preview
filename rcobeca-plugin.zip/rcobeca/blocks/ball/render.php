<?php
/**
 * Renders the Royal Charity Ball page (/ball/): the newest Ball in the state
 * set on its Event. Modelled on the Opera Theatre of Saint Louis gala page
 * (one evergreen URL, status label, event information card, sponsors by tier
 * "as of" a date) with Princeton's event details card.
 *
 * States: save-the-date, on-sale, sold-out, ball-night, thank-you, between.
 * Tickets (the Zeffy card) appear only while on sale, and never once the
 * Ball's date has passed (Events::state()).
 *
 * Ball night: the "Find your table" section renders the rcobeca/table-lookup
 * block (ticket #8) with the Ball's ID as eventId, when that block exists.
 *
 * @package RCOBECA
 *
 * @var array $attributes Block attributes: heroImage (a Ball-night photo behind the hero).
 */

use RCOBECA\Events;

defined( 'ABSPATH' ) || exit;

$rcobeca_ball  = Events::current_ball();
$rcobeca_state = $rcobeca_ball ? Events::state( $rcobeca_ball ) : Events::BETWEEN;
$rcobeca_date  = static fn( string $ymd, string $format ) => '' !== $ymd ? gmdate( $format, (int) strtotime( $ymd . ' 12:00:00 UTC' ) ) : '';
$rcobeca_get   = static fn( string $key ) => $rcobeca_ball ? Events::get( $rcobeca_ball, $key ) : '';

// Between Balls the page is about the Ball itself, not the last one.
$rcobeca_between = Events::BETWEEN === $rcobeca_state;
$rcobeca_title   = $rcobeca_between ? __( 'Royal Charity Ball', 'rcobeca' ) : Events::edition_title( $rcobeca_ball );

$rcobeca_ads = $rcobeca_ball ? Events::ad_tiers( $rcobeca_ball ) : array();
// Each tier links to its own Zeffy purchase; the shared ad link is only for tiers without one.
$rcobeca_tier_links = (bool) array_filter( array_column( $rcobeca_ads, 'url' ) );
$rcobeca_ad_url     = $rcobeca_ads && ! in_array( '', array_column( $rcobeca_ads, 'url' ), true ) ? '' : $rcobeca_get( 'ad_url' );
$rcobeca_show_ads   = in_array( $rcobeca_state, array( Events::SAVE_THE_DATE, Events::ON_SALE, Events::SOLD_OUT ), true ) && ( $rcobeca_ads || '' !== $rcobeca_ad_url );
$rcobeca_sponsors   = $rcobeca_ball && in_array( $rcobeca_state, array( Events::ON_SALE, Events::SOLD_OUT, Events::BALL_NIGHT, Events::THANK_YOU ), true ) ? Events::sponsors( $rcobeca_ball ) : array();
$rcobeca_tickets    = Events::ON_SALE === $rcobeca_state ? rcobeca_zeffy_form( $rcobeca_get( 'ticket_url' ) ) : null;
$rcobeca_raised     = $rcobeca_get( 'funds_raised' );
$rcobeca_count      = max( array_map( static fn( $id ) => (int) Events::get( $id, 'edition' ), array_merge( array( 0 ), Events::balls() ) ) );

/**
 * A button link.
 *
 * @param string $href Target.
 * @param string $label Text.
 * @param string $style Block style: fill, gold or outline.
 */
$rcobeca_button = static function ( string $href, string $label, string $style = 'gold' ): string {
	$class = 'fill' === $style ? '' : ' is-style-' . $style;
	return '<div class="wp-block-button' . esc_attr( $class ) . '"><a class="wp-block-button__link wp-element-button" href="' . esc_url( $href ) . '">' . esc_html( $label ) . '</a></div>';
};

// Sections after the hero alternate white and cream, whichever the state shows
// (Ball night opens on cream, so the Table Lookup card stands out).
$rcobeca_tinted = Events::BALL_NIGHT !== $rcobeca_state;
$rcobeca_tint   = static function () use ( &$rcobeca_tinted ): string {
	$rcobeca_tinted = ! $rcobeca_tinted;
	return $rcobeca_tinted ? ' is-tinted' : '';
};

// The newest past Balls with a page, for the closing band.
$rcobeca_recent = array();
foreach ( Events::balls() as $rcobeca_id ) {
	if ( ( $rcobeca_between || $rcobeca_id !== $rcobeca_ball ) && ! Events::is_upcoming( $rcobeca_id ) && Events::has_page( $rcobeca_id ) ) {
		$rcobeca_recent[] = $rcobeca_id;
	}
	if ( count( $rcobeca_recent ) === 3 ) {
		break;
	}
}
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'rcobeca-ball alignfull is-state-' . $rcobeca_state ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>

	<?php $rcobeca_hero_photo = (int) ( $attributes['heroImage'] ?? 0 ); ?>
	<section class="rcobeca-ball__hero<?php echo wp_attachment_is_image( $rcobeca_hero_photo ) ? ' has-photo' : ''; ?>" aria-labelledby="rcobeca-ball-title">
		<?php
		if ( wp_attachment_is_image( $rcobeca_hero_photo ) ) {
			// Decorative behind the title: alt is empty, the navy overlay carries the contrast.
			echo wp_get_attachment_image(
				$rcobeca_hero_photo,
				'full',
				false,
				array(
					'class'         => 'rcobeca-ball__hero-photo',
					'alt'           => '',
					'sizes'         => '100vw',
					'fetchpriority' => 'high',
					'loading'       => 'eager',
				)
			);
		}
		?>
		<div class="rcobeca-ball__hero-inner">
		<div class="rcobeca-ball__hero-text">
			<p class="rcobeca-ball__status"><span><?php echo esc_html( Events::state_label( $rcobeca_state ) ); ?></span></p>
			<h1 class="rcobeca-ball__title" id="rcobeca-ball-title"><?php echo esc_html( $rcobeca_title ); ?></h1>
			<?php if ( $rcobeca_between ) : ?>
				<p class="rcobeca-ball__lead"><?php esc_html_e( 'RCOBECA’s flagship gala and the most prominent annual Sri Lankan community event in the tri-state area: an evening of dinner, music and dancing whose proceeds fund Royal College, Colombo, and charitable causes in Sri Lanka and the United States.', 'rcobeca' ); ?></p>
				<p class="rcobeca-ball__when"><?php esc_html_e( 'The next Ball’s date will be announced here.', 'rcobeca' ); ?></p>
				<div class="wp-block-buttons rcobeca-ball__actions">
					<?php echo $rcobeca_button( home_url( '/ball/past/' ), __( 'See Past Balls', 'rcobeca' ), 'outline' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
			<?php else : ?>
				<p class="rcobeca-ball__when">
					<?php echo esc_html( Events::date_label( $rcobeca_ball ) ); ?>
					<?php if ( '' !== Events::place( $rcobeca_ball ) ) : ?>
						<br><?php echo esc_html( Events::place( $rcobeca_ball ) ); ?>
					<?php endif; ?>
				</p>
				<?php if ( Events::SAVE_THE_DATE === $rcobeca_state ) : ?>
					<p class="rcobeca-ball__lead"><?php esc_html_e( 'Tickets go on sale soon. Mark your calendar, and watch this page and our newsletter.', 'rcobeca' ); ?></p>
				<?php elseif ( Events::SOLD_OUT === $rcobeca_state ) : ?>
					<p class="rcobeca-ball__lead"><?php esc_html_e( 'Every seat is taken: thank you! Unable to attend? A gift still funds Royal College.', 'rcobeca' ); ?></p>
				<?php elseif ( Events::BALL_NIGHT === $rcobeca_state ) : ?>
					<p class="rcobeca-ball__lead"><?php esc_html_e( 'Welcome! Type your full name to find your table.', 'rcobeca' ); ?></p>
				<?php elseif ( Events::THANK_YOU === $rcobeca_state ) : ?>
					<p class="rcobeca-ball__lead"><?php esc_html_e( 'Thank you to every guest, sponsor, advertiser and volunteer who made the evening.', 'rcobeca' ); ?></p>
					<?php if ( '' !== $rcobeca_raised ) : ?>
						<p class="rcobeca-ball__raised"><strong><?php echo esc_html( $rcobeca_raised ); ?></strong> <?php esc_html_e( 'raised', 'rcobeca' ); ?></p>
					<?php endif; ?>
				<?php endif; ?>
				<div class="wp-block-buttons rcobeca-ball__actions">
					<?php
					// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- buttons are escaped by $rcobeca_button.
					if ( $rcobeca_tickets ) {
						echo $rcobeca_button( '#tickets', __( 'Buy tickets', 'rcobeca' ) );
					}
					if ( Events::SOLD_OUT === $rcobeca_state ) {
						echo $rcobeca_button( home_url( '/donate/' ), __( 'Make a donation', 'rcobeca' ) );
					}
					if ( $rcobeca_show_ads ) {
						echo $rcobeca_button( '#sponsorship', __( 'Sponsorship and ads', 'rcobeca' ), 'outline' );
					}
					if ( Events::BALL_NIGHT === $rcobeca_state ) {
						echo $rcobeca_button( '#find-your-table', __( 'Find your table', 'rcobeca' ) );
					}
					if ( Events::THANK_YOU === $rcobeca_state && '' !== $rcobeca_get( 'photos_url' ) && '' !== Events::live_link( $rcobeca_get( 'photos_url' ) ) ) {
						echo $rcobeca_button( Events::live_link( $rcobeca_get( 'photos_url' ) ), __( 'See the photos', 'rcobeca' ) );
					}
					if ( in_array( $rcobeca_state, array( Events::SAVE_THE_DATE, Events::THANK_YOU ), true ) ) {
						echo $rcobeca_button( home_url( '/ball/past/' ), __( 'Past Balls', 'rcobeca' ), 'outline' );
					}
					// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
					?>
				</div>
			<?php endif; ?>
		</div>
		<?php if ( $rcobeca_between && $rcobeca_count ) : ?>
			<p class="rcobeca-ball__hero-aside rcobeca-ball__count">
				<strong><?php echo esc_html( (string) $rcobeca_count ); ?></strong>
				<?php echo esc_html( sprintf( /* translators: %d: year of the first Ball. */ __( 'Balls since %d, raising funds for Royal College and for causes in Sri Lanka and the United States', 'rcobeca' ), Events::first_ball_year() ) ); ?>
			</p>
		<?php elseif ( ! $rcobeca_between && has_post_thumbnail( $rcobeca_ball ) ) : ?>
			<figure class="rcobeca-ball__hero-aside rcobeca-ball__flyer">
				<?php echo get_the_post_thumbnail( $rcobeca_ball, 'large', array( 'alt' => '' ) ); ?>
			</figure>
		<?php endif; ?>
		</div>
	</section>

	<?php if ( Events::BALL_NIGHT === $rcobeca_state ) : ?>
		<section class="rcobeca-ball__section rcobeca-ball__lookup<?php echo esc_attr( $rcobeca_tint() ); ?>" id="find-your-table" aria-labelledby="rcobeca-ball-lookup">
			<div class="rcobeca-ball__inner rcobeca-ball__inner--narrow">
				<h2 id="rcobeca-ball-lookup"><?php esc_html_e( 'Find your table', 'rcobeca' ); ?></h2>
				<div class="rcobeca-ball__table-lookup">
					<?php
					if ( WP_Block_Type_Registry::get_instance()->is_registered( 'rcobeca/table-lookup' ) ) {
						echo render_block( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- a block's own rendering.
							array(
								'blockName'    => 'rcobeca/table-lookup',
								'attrs'        => array( 'eventId' => $rcobeca_ball ),
								'innerBlocks'  => array(),
								'innerHTML'    => '',
								'innerContent' => array(),
							)
						);
					} else {
						echo '<p>' . esc_html__( 'Table Lookup opens here on Ball night. Until then, the welcome desk will show you to your table.', 'rcobeca' ) . '</p>';
					}
					?>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $rcobeca_between && $rcobeca_ball ) : ?>
		<section class="rcobeca-ball__section rcobeca-ball__recap<?php echo esc_attr( $rcobeca_tint() ); ?>" aria-labelledby="rcobeca-ball-recap">
			<div class="rcobeca-ball__inner rcobeca-ball__split">
				<div class="rcobeca-ball__text">
					<p class="is-style-kicker"><?php esc_html_e( 'The last Ball', 'rcobeca' ); ?></p>
					<h2 id="rcobeca-ball-recap"><a href="<?php echo esc_url( (string) get_permalink( $rcobeca_ball ) ); ?>"><?php echo esc_html( Events::kicker( $rcobeca_ball ) . ', ' . Events::year( $rcobeca_ball ) ); ?></a></h2>
					<p>
						<?php
						/* translators: 1: date, 2: venue. */
						echo esc_html( sprintf( __( 'Held on %1$s at %2$s.', 'rcobeca' ), Events::date_label( $rcobeca_ball ), Events::place( $rcobeca_ball ) ) );
						?>
						<?php echo '' !== $rcobeca_raised ? esc_html( sprintf( /* translators: %s: amount. */ __( 'It raised %s.', 'rcobeca' ), $rcobeca_raised ) ) : ''; ?>
						<?php esc_html_e( 'Thank you to everyone who came, sponsored, advertised and helped.', 'rcobeca' ); ?>
					</p>
					<p class="rcobeca-more"><a href="<?php echo esc_url( (string) get_permalink( $rcobeca_ball ) ); ?>"><?php echo esc_html( sprintf( /* translators: %s: year. */ __( 'Photos, video and the Souvenir Journal from %s', 'rcobeca' ), Events::year( $rcobeca_ball ) ) ); ?></a></p>
				</div>
				<?php
				echo render_block( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- a block's own rendering.
					array(
						'blockName'    => 'rcobeca/event-details',
						'attrs'        => array(
							'eventId' => $rcobeca_ball,
							'heading' => sprintf( /* translators: %s: year. */ __( 'The %s Ball', 'rcobeca' ), Events::year( $rcobeca_ball ) ),
						),
						'innerBlocks'  => array(),
						'innerHTML'    => '',
						'innerContent' => array(),
					)
				);
				?>
			</div>
		</section>
	<?php elseif ( $rcobeca_ball ) : ?>
		<section class="rcobeca-ball__section rcobeca-ball__about<?php echo esc_attr( $rcobeca_tint() ); ?>" aria-labelledby="rcobeca-ball-about">
			<div class="rcobeca-ball__inner rcobeca-ball__split">
				<div class="rcobeca-ball__text">
					<h2 id="rcobeca-ball-about"><?php esc_html_e( 'An evening for Royal College', 'rcobeca' ); ?></h2>
					<?php if ( has_excerpt( $rcobeca_ball ) ) : ?>
						<p class="has-large-font-size"><?php echo esc_html( get_the_excerpt( $rcobeca_ball ) ); ?></p>
					<?php endif; ?>
					<p><?php esc_html_e( 'The Royal Charity Ball has been RCOBECA’s flagship gala since 1994: dinner, music and dancing with friends old and new. Its proceeds fund essential academic and student enrichment programs at Royal College, Colombo, that are not covered by public funding, and other charitable causes in the United States and Sri Lanka.', 'rcobeca' ); ?></p>
					<p><?php esc_html_e( 'Questions about tickets or tables?', 'rcobeca' ); ?> <a href="mailto:tickets@rcobeca.org">tickets@rcobeca.org</a></p>
				</div>
				<?php
				echo render_block( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- a block's own rendering.
					array(
						'blockName'    => 'rcobeca/event-details',
						'attrs'        => array(
							'eventId' => $rcobeca_ball,
							'heading' => __( 'Event information', 'rcobeca' ),
						),
						'innerBlocks'  => array(),
						'innerHTML'    => '',
						'innerContent' => array(),
					)
				);
				?>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $rcobeca_tickets ) : ?>
		<section class="rcobeca-ball__section rcobeca-ball__tickets<?php echo esc_attr( $rcobeca_tint() ); ?>" id="tickets" aria-labelledby="rcobeca-ball-tickets">
			<div class="rcobeca-ball__inner rcobeca-ball__split">
				<div class="rcobeca-ball__text">
					<p class="is-style-kicker"><?php esc_html_e( 'Tickets', 'rcobeca' ); ?></p>
					<h2 id="rcobeca-ball-tickets"><?php esc_html_e( 'Join us for the evening', 'rcobeca' ); ?></h2>
					<?php if ( '' !== $rcobeca_get( 'ticket_prices' ) ) : ?>
						<p class="rcobeca-ball__price"><?php echo esc_html( $rcobeca_get( 'ticket_prices' ) ); ?></p>
					<?php endif; ?>
					<p>
						<?php
						echo '' !== $rcobeca_get( 'deductible' )
							? esc_html( sprintf( /* translators: %s: deductible amount. */ __( 'Tax-deductible portion: %s.', 'rcobeca' ), $rcobeca_get( 'deductible' ) ) ) . ' ' . esc_html__( 'Your Zeffy receipt shows it.', 'rcobeca' )
							: esc_html__( 'Part of each ticket pays for dinner and entertainment; your Zeffy receipt shows the tax-deductible part.', 'rcobeca' );
						?>
					</p>
					<p class="rcobeca-ball__small"><?php esc_html_e( 'Donor-advised funds cannot pay for tickets. To pay by cheque or Zelle, or to reserve a table, email tickets@rcobeca.org.', 'rcobeca' ); ?></p>
				</div>
				<?php
				echo render_block( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- a block's own rendering.
					array(
						'blockName'    => 'rcobeca/zeffy-card',
						'attrs'        => array(
							'formUrl' => $rcobeca_get( 'ticket_url' ),
							'heading' => __( 'Buy tickets', 'rcobeca' ),
						),
						'innerBlocks'  => array(),
						'innerHTML'    => '',
						'innerContent' => array(),
					)
				);
				?>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $rcobeca_show_ads ) : ?>
		<section class="rcobeca-ball__section rcobeca-ball__ads<?php echo esc_attr( $rcobeca_tint() ); ?>" id="sponsorship" aria-labelledby="rcobeca-ball-ads">
			<div class="rcobeca-ball__inner">
				<p class="is-style-kicker"><?php esc_html_e( 'Sponsorship and the Souvenir Journal', 'rcobeca' ); ?></p>
				<h2 id="rcobeca-ball-ads"><?php esc_html_e( 'Support the Ball with an ad', 'rcobeca' ); ?></h2>
				<p class="rcobeca-ball__intro"><?php esc_html_e( 'The printed and PDF Souvenir Journal is funded by sponsors’ advertisements. Every ad is acknowledged in the Journal, and all ads are tax-deductible.', 'rcobeca' ); ?></p>
				<div class="rcobeca-ball__split">
					<?php if ( $rcobeca_ads ) : ?>
						<table class="rcobeca-ball__tiers">
							<thead><tr><th scope="col"><?php esc_html_e( 'Advertisement', 'rcobeca' ); ?></th><th scope="col"><?php esc_html_e( 'Price', 'rcobeca' ); ?></th>
							<?php
							if ( $rcobeca_tier_links ) :
								?>
								<th scope="col"><span class="screen-reader-text"><?php esc_html_e( 'Buy', 'rcobeca' ); ?></span></th><?php endif; ?></tr></thead>
							<tbody>
								<?php foreach ( $rcobeca_ads as $rcobeca_tier ) : ?>
									<tr>
										<th scope="row"><?php echo esc_html( $rcobeca_tier['name'] ); ?></th>
										<td><?php echo esc_html( $rcobeca_tier['price'] ); ?></td>
										<?php if ( $rcobeca_tier_links ) : ?>
											<td>
												<?php if ( '' !== $rcobeca_tier['url'] ) : ?>
													<a class="rcobeca-ball__buy" href="<?php echo esc_url( $rcobeca_tier['url'] ); ?>"><?php esc_html_e( 'Buy', 'rcobeca' ); ?><span class="screen-reader-text"> <?php echo esc_html( $rcobeca_tier['name'] ); ?></span></a>
												<?php endif; ?>
											</td>
										<?php endif; ?>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					<?php endif; ?>
					<div class="rcobeca-ball__specs">
						<?php if ( '' !== $rcobeca_get( 'ad_deadline' ) ) : ?>
							<p><strong><?php esc_html_e( 'Ad copy deadline:', 'rcobeca' ); ?></strong> <?php echo esc_html( $rcobeca_date( $rcobeca_get( 'ad_deadline' ), 'l, F j, Y' ) ); ?></p>
						<?php endif; ?>
						<?php if ( Events::lines( $rcobeca_ball, 'ad_specs' ) ) : ?>
							<ul>
								<?php foreach ( Events::lines( $rcobeca_ball, 'ad_specs' ) as $rcobeca_spec ) : ?>
									<li><?php echo esc_html( $rcobeca_spec ); ?></li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
						<?php if ( '' !== $rcobeca_ad_url ) : ?>
							<div class="wp-block-buttons"><?php echo $rcobeca_button( $rcobeca_ad_url, __( 'Buy an ad or sponsorship', 'rcobeca' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $rcobeca_sponsors ) : ?>
		<section class="rcobeca-ball__section rcobeca-ball__sponsors<?php echo esc_attr( $rcobeca_tint() ); ?>" id="sponsors" aria-labelledby="rcobeca-ball-sponsors">
			<div class="rcobeca-ball__inner">
				<p class="is-style-kicker"><?php esc_html_e( 'With thanks', 'rcobeca' ); ?></p>
				<h2 id="rcobeca-ball-sponsors"><?php esc_html_e( 'Our sponsors', 'rcobeca' ); ?></h2>
				<?php foreach ( $rcobeca_sponsors as $rcobeca_tier => $rcobeca_names ) : ?>
					<div class="rcobeca-ball__tier">
						<h3><?php echo esc_html( $rcobeca_tier ); ?></h3>
						<ul>
							<?php foreach ( $rcobeca_names as $rcobeca_name ) : ?>
								<li><?php echo esc_html( $rcobeca_name ); ?></li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endforeach; ?>
				<?php if ( '' !== $rcobeca_get( 'sponsors_as_of' ) ) : ?>
					<p class="rcobeca-ball__asof">
						<?php echo esc_html( sprintf( /* translators: %s: date. */ __( 'List as of %s.', 'rcobeca' ), $rcobeca_date( $rcobeca_get( 'sponsors_as_of' ), 'F j, Y' ) ) ); ?>
						<?php esc_html_e( 'Missing or misspelt? Email', 'rcobeca' ); ?> <a href="mailto:secretary@rcobeca.org">secretary@rcobeca.org</a>.
					</p>
				<?php endif; ?>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( Events::THANK_YOU === $rcobeca_state && '' !== trim( (string) get_post_field( 'post_content', $rcobeca_ball ) ) ) : ?>
		<section class="rcobeca-ball__section rcobeca-ball__story<?php echo esc_attr( $rcobeca_tint() ); ?>" aria-labelledby="rcobeca-ball-story">
			<div class="rcobeca-ball__inner rcobeca-ball__inner--narrow">
				<h2 id="rcobeca-ball-story"><?php esc_html_e( 'From the evening', 'rcobeca' ); ?></h2>
				<div class="rcobeca-ball__content">
					<?php echo do_blocks( (string) get_post_field( 'post_content', $rcobeca_ball ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the Event's own content. ?>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<section class="rcobeca-ball__section rcobeca-ball__past<?php echo esc_attr( $rcobeca_tint() ); ?>" aria-labelledby="rcobeca-ball-past">
		<div class="rcobeca-ball__inner">
			<div class="rcobeca-ball__past-head">
				<div>
					<p class="is-style-kicker"><?php echo esc_html( sprintf( /* translators: %d: year of the first Ball. */ __( 'Since %d', 'rcobeca' ), Events::first_ball_year() ) ); ?></p>
					<h2 id="rcobeca-ball-past"><?php esc_html_e( 'Past Balls', 'rcobeca' ); ?></h2>
				</div>
				<p class="rcobeca-more"><a href="<?php echo esc_url( home_url( '/ball/past/' ) ); ?>"><?php echo esc_html( sprintf( /* translators: %d: year of the first Ball. */ __( 'Every Ball since %d on Past Balls', 'rcobeca' ), Events::first_ball_year() ) ); ?></a></p>
			</div>
			<ul class="rcobeca-ball__past-list">
				<?php foreach ( $rcobeca_recent as $rcobeca_id ) : ?>
					<li>
						<a href="<?php echo esc_url( (string) get_permalink( $rcobeca_id ) ); ?>">
							<?php if ( has_post_thumbnail( $rcobeca_id ) ) : ?>
								<?php
								echo get_the_post_thumbnail(
									$rcobeca_id,
									'medium_large',
									array(
										'alt'     => '',
										'loading' => 'lazy',
									)
								);
								?>
							<?php endif; ?>
							<span class="rcobeca-ball__past-year"><?php echo esc_html( (string) Events::year( $rcobeca_id ) ); ?></span>
							<span class="rcobeca-ball__past-title"><?php echo esc_html( Events::kicker( $rcobeca_id ) ); ?></span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
</div>
