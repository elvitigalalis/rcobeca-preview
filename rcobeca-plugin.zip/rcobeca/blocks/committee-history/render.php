<?php
/**
 * Renders the Committee history: every Club Year newest first, each a plain
 * list of roles and names, with the President's major events. A name search
 * (view.js) hides the Club Years a name does not appear in.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

$rcobeca_years = rcobeca_committees_by_year();
if ( ! $rcobeca_years ) {
	return;
}

$rcobeca_names = array();
foreach ( $rcobeca_years as $rcobeca_year => $rcobeca_terms ) {
	$rcobeca_names[ $rcobeca_year ] = strtolower( implode( ' | ', array_map( static fn( $t ) => rcobeca_person_name( $t['person'] ), $rcobeca_terms ) ) );
}
wp_interactivity_state(
	'rcobeca/committee-history',
	array(
		'query' => '',
		'names' => array_values( $rcobeca_names ),
	)
);

// Jump links: the newest Club Year of each decade.
$rcobeca_decades = array();
foreach ( array_keys( $rcobeca_years ) as $rcobeca_year ) {
	$rcobeca_decades[ intdiv( $rcobeca_year, 10 ) * 10 ] ??= $rcobeca_year;
}
$rcobeca_search = wp_unique_id( 'rcobeca-history-search-' );
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'rcobeca-history' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> data-wp-interactive="rcobeca/committee-history">
	<div class="rcobeca-history__tools">
		<div class="rcobeca-history__search" role="search">
			<label for="<?php echo esc_attr( $rcobeca_search ); ?>"><?php esc_html_e( 'Find a name', 'rcobeca' ); ?></label>
			<input type="search" id="<?php echo esc_attr( $rcobeca_search ); ?>" autocomplete="off" placeholder="<?php esc_attr_e( 'e.g. Senaviratne', 'rcobeca' ); ?>" data-wp-on--input="actions.search">
			<p class="rcobeca-history__count" role="status" data-wp-text="state.count"></p>
		</div>
		<nav class="rcobeca-history__decades" aria-label="<?php esc_attr_e( 'Club Years by decade', 'rcobeca' ); ?>">
			<?php foreach ( $rcobeca_decades as $rcobeca_decade => $rcobeca_year ) : ?>
				<a href="#club-year-<?php echo (int) $rcobeca_year; ?>"><?php echo esc_html( $rcobeca_decade . 's' ); ?></a>
			<?php endforeach; ?>
		</nav>
	</div>
	<div class="rcobeca-history__years">
		<?php foreach ( $rcobeca_years as $rcobeca_year => $rcobeca_terms ) : ?>
			<?php $rcobeca_highlights = implode( ' ', array_unique( array_filter( array_column( $rcobeca_terms, 'highlights' ) ) ) ); ?>
			<section class="rcobeca-history__year" id="club-year-<?php echo (int) $rcobeca_year; ?>" <?php echo wp_interactivity_data_wp_context( array( 'names' => $rcobeca_names[ $rcobeca_year ] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped by the helper. ?> data-wp-bind--hidden="state.isHidden">
				<div class="rcobeca-history__head">
					<h3 class="rcobeca-history__label"><?php echo esc_html( rcobeca_club_year_label( $rcobeca_year ) ); ?></h3>
					<?php if ( '' !== $rcobeca_highlights ) : ?>
						<p class="rcobeca-history__highlights"><?php echo esc_html( $rcobeca_highlights ); ?></p>
					<?php endif; ?>
				</div>
				<ul class="rcobeca-history__list">
					<?php foreach ( rcobeca_terms_by_role( $rcobeca_terms ) as [ $rcobeca_role, $rcobeca_members ] ) : ?>
						<li>
							<span class="rcobeca-history__role"><?php echo esc_html( $rcobeca_role ); ?></span>
							<span class="rcobeca-history__names"><?php echo implode( ', ', array_map( static fn( $t ) => rcobeca_person_link( $t['person'] ), $rcobeca_members ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>
		<?php endforeach; ?>
	</div>
</div>
