<?php
/**
 * Renders the current Committee (the latest Club Year): one row per Person
 * with every role he holds this year, the officer email, and his photo when
 * there is one. Officers first, then Committee members.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

$rcobeca_year = rcobeca_current_club_year();
if ( null === $rcobeca_year ) {
	return;
}

// One entry per Person, in the order of his first Term.
$rcobeca_people = array();
foreach ( rcobeca_committees_by_year()[ $rcobeca_year ] as $rcobeca_term ) {
	$rcobeca_people[ $rcobeca_term['person'] ] ??= array(
		'roles'   => array(),
		'emails'  => array(),
		'officer' => false,
	);
	$rcobeca_entry                               = &$rcobeca_people[ $rcobeca_term['person'] ];
	$rcobeca_entry['roles'][]                    = $rcobeca_term['role'];
	$rcobeca_entry['emails'][]                   = $rcobeca_term['email'];
	$rcobeca_entry['officer']                    = $rcobeca_entry['officer'] || rcobeca_role_rank( $rcobeca_term['role'] ) < rcobeca_role_rank( 'Committee Member' );
	unset( $rcobeca_entry );
}

$rcobeca_groups = array(
	__( 'Officers', 'rcobeca' )          => array_filter( $rcobeca_people, static fn( $p ) => $p['officer'] ),
	__( 'Committee members', 'rcobeca' ) => array_filter( $rcobeca_people, static fn( $p ) => ! $p['officer'] ),
);
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'rcobeca-committee' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<p class="is-style-kicker rcobeca-committee__year">
		<?php
		/* translators: %s: Club Year, e.g. 2025–26. */
		echo esc_html( sprintf( __( 'Club Year %s', 'rcobeca' ), rcobeca_club_year_label( $rcobeca_year ) ) );
		?>
	</p>
	<?php foreach ( array_filter( $rcobeca_groups ) as $rcobeca_heading => $rcobeca_group ) : ?>
		<section class="rcobeca-committee__group">
			<h2 class="rcobeca-committee__heading"><?php echo esc_html( $rcobeca_heading ); ?></h2>
			<ul class="rcobeca-committee__list" role="list">
				<?php foreach ( $rcobeca_group as $rcobeca_person => $rcobeca_entry ) : ?>
					<?php $rcobeca_roles = array_unique( $rcobeca_entry['roles'] ); ?>
					<li class="rcobeca-committee__person">
						<div class="rcobeca-committee__text">
							<h3 class="rcobeca-committee__name"><?php echo rcobeca_person_link( $rcobeca_person ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?></h3>
							<?php if ( array( 'Committee Member' ) !== $rcobeca_roles ) : ?>
								<p class="rcobeca-committee__roles"><?php echo esc_html( implode( ', ', $rcobeca_roles ) ); ?></p>
							<?php endif; ?>
							<?php foreach ( array_unique( array_filter( $rcobeca_entry['emails'] ) ) as $rcobeca_email ) : ?>
								<p class="rcobeca-committee__email"><a href="<?php echo esc_url( 'mailto:' . $rcobeca_email ); ?>"><?php echo esc_html( $rcobeca_email ); ?></a></p>
							<?php endforeach; ?>
						</div>
						<?php if ( has_post_thumbnail( $rcobeca_person ) ) : ?>
							<figure class="rcobeca-committee__portrait"><?php echo get_the_post_thumbnail( $rcobeca_person, 'medium', array( 'alt' => rcobeca_person_name( $rcobeca_person ) ) ); ?></figure>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		</section>
	<?php endforeach; ?>
</div>
