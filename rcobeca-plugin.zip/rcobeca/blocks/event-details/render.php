<?php
/**
 * Renders an Event's details card (Princeton's "Event Details" panel and the
 * Opera Theatre of Saint Louis "Event information" card): fixed labels,
 * filled from the Event's fields, unknown facts left out.
 *
 * @package RCOBECA
 *
 * @var array    $attributes Block attributes: eventId, heading.
 * @var WP_Block $block Block instance.
 */

use RCOBECA\Events;

defined( 'ABSPATH' ) || exit;

$rcobeca_id = (int) ( $attributes['eventId'] ?? 0 );
$rcobeca_id = $rcobeca_id ? $rcobeca_id : (int) ( $block->context['postId'] ?? get_the_ID() );
if ( Events::POST_TYPE !== get_post_type( $rcobeca_id ) ) {
	return;
}
$rcobeca_heading = '' !== ( $attributes['heading'] ?? '' ) ? $attributes['heading'] : __( 'Event details', 'rcobeca' );
$rcobeca_label   = wp_unique_id( 'rcobeca-event-details-' );

// A past Ball keeps its Souvenir Journal ad tiers and specs as a record (no buy links).
$rcobeca_past     = Events::is_ball( $rcobeca_id ) && ! Events::is_upcoming( $rcobeca_id );
$rcobeca_tiers    = $rcobeca_past ? Events::ad_tiers( $rcobeca_id ) : array();
$rcobeca_specs    = $rcobeca_past ? Events::lines( $rcobeca_id, 'ad_specs' ) : array();
$rcobeca_deadline = $rcobeca_past ? Events::get( $rcobeca_id, 'ad_deadline' ) : '';
$rcobeca_ads      = wp_unique_id( 'rcobeca-event-ads-' );
?>
<section <?php echo get_block_wrapper_attributes( array( 'class' => 'rcobeca-event-details' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> aria-labelledby="<?php echo esc_attr( $rcobeca_label ); ?>">
	<h2 class="rcobeca-event-details__heading" id="<?php echo esc_attr( $rcobeca_label ); ?>"><?php echo esc_html( $rcobeca_heading ); ?></h2>
	<dl class="rcobeca-event-details__list">
		<?php foreach ( Events::details( $rcobeca_id ) as $rcobeca_term => $rcobeca_value ) : ?>
			<div class="rcobeca-event-details__row">
				<dt><?php echo esc_html( $rcobeca_term ); ?></dt>
				<dd><?php echo wp_kses_post( $rcobeca_value ); ?></dd>
			</div>
		<?php endforeach; ?>
	</dl>
	<?php if ( $rcobeca_tiers || $rcobeca_specs ) : ?>
		<section class="rcobeca-event-details__ads" aria-labelledby="<?php echo esc_attr( $rcobeca_ads ); ?>">
			<h3 class="rcobeca-event-details__subheading" id="<?php echo esc_attr( $rcobeca_ads ); ?>"><?php esc_html_e( 'Souvenir Journal ads', 'rcobeca' ); ?></h3>
			<?php if ( $rcobeca_tiers ) : ?>
				<table class="rcobeca-event-details__tiers">
					<thead><tr><th scope="col"><?php esc_html_e( 'Advertisement', 'rcobeca' ); ?></th><th scope="col"><?php esc_html_e( 'Price', 'rcobeca' ); ?></th></tr></thead>
					<tbody>
						<?php foreach ( $rcobeca_tiers as $rcobeca_tier ) : ?>
							<tr><th scope="row"><?php echo esc_html( $rcobeca_tier['name'] ); ?></th><td><?php echo esc_html( $rcobeca_tier['price'] ); ?></td></tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
			<?php if ( '' !== $rcobeca_deadline ) : ?>
				<p><?php esc_html_e( 'Ad copy deadline:', 'rcobeca' ); ?> <?php echo esc_html( gmdate( 'l, F j, Y', (int) strtotime( $rcobeca_deadline . ' 12:00:00 UTC' ) ) ); ?></p>
			<?php endif; ?>
			<?php if ( $rcobeca_specs ) : ?>
				<ul>
					<?php foreach ( $rcobeca_specs as $rcobeca_spec ) : ?>
						<li><?php echo esc_html( $rcobeca_spec ); ?></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</section>
	<?php endif; ?>
</section>
