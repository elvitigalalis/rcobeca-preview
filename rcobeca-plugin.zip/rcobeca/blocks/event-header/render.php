<?php
/**
 * Renders the Event title band: breadcrumb, kicker, title, date and place.
 *
 * @package RCOBECA
 *
 * @var WP_Block $block Block instance.
 */

use RCOBECA\Events;

defined( 'ABSPATH' ) || exit;

$rcobeca_id = (int) ( $block->context['postId'] ?? get_the_ID() );
if ( Events::POST_TYPE !== get_post_type( $rcobeca_id ) ) {
	return;
}
$rcobeca_ball   = Events::is_ball( $rcobeca_id );
$rcobeca_parent = $rcobeca_ball
	? array( home_url( '/ball/past/' ), __( 'Past Balls', 'rcobeca' ) )
	: array( home_url( '/events/' ), __( 'Events', 'rcobeca' ) );
$rcobeca_place  = Events::place( $rcobeca_id );
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'rcobeca-event-header alignfull' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<div class="rcobeca-event-header__inner">
		<nav class="rcobeca-event-header__crumbs" aria-label="<?php esc_attr_e( 'Breadcrumb', 'rcobeca' ); ?>">
			<a href="<?php echo esc_url( $rcobeca_parent[0] ); ?>"><?php echo esc_html( $rcobeca_parent[1] ); ?></a>
		</nav>
		<p class="rcobeca-event-header__kicker"><?php echo esc_html( Events::kicker( $rcobeca_id ) ); ?></p>
		<h1 class="rcobeca-event-header__title"><?php echo esc_html( get_the_title( $rcobeca_id ) ); ?></h1>
		<p class="rcobeca-event-header__when">
			<?php echo esc_html( Events::date_label( $rcobeca_id ) ); ?>
			<?php if ( '' !== $rcobeca_place ) : ?>
				<span aria-hidden="true">·</span> <?php echo esc_html( $rcobeca_place ); ?>
			<?php endif; ?>
		</p>
	</div>
</div>
