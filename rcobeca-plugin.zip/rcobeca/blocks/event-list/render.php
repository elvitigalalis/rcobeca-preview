<?php
/**
 * Renders the Events listing: a type filter, Upcoming (soonest first), then
 * Past events grouped by year, most recent first. One page, no pagination.
 *
 * @package RCOBECA
 *
 * @var array $attributes Block attributes.
 */

use RCOBECA\Events;

defined( 'ABSPATH' ) || exit;

// A read-only filter in the URL; no state changes, so no nonce.
$rcobeca_type = isset( $_GET['type'] ) ? sanitize_key( wp_unslash( $_GET['type'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$rcobeca_type = isset( Events::TYPES[ $rcobeca_type ] ) ? $rcobeca_type : '';
$rcobeca_base = (string) get_permalink();
$rcobeca_past = Events::past( $rcobeca_type );
$rcobeca_soon = Events::upcoming( $rcobeca_type );

$rcobeca_by_year = array();
foreach ( $rcobeca_past as $rcobeca_id ) {
	$rcobeca_by_year[ Events::year( $rcobeca_id ) ][] = $rcobeca_id;
}

$rcobeca_filters = array( '' => __( 'All events', 'rcobeca' ) ) + Events::TYPES;
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'rcobeca-event-list' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<nav class="rcobeca-event-list__filter" aria-label="<?php esc_attr_e( 'Show events of one type', 'rcobeca' ); ?>">
		<ul>
			<?php foreach ( $rcobeca_filters as $rcobeca_slug => $rcobeca_label ) : ?>
				<li><a href="<?php echo esc_url( '' === $rcobeca_slug ? $rcobeca_base : add_query_arg( 'type', $rcobeca_slug, $rcobeca_base ) ); ?>"<?php echo $rcobeca_slug === $rcobeca_type ? ' aria-current="page"' : ''; ?>><?php echo esc_html( 'other' === $rcobeca_slug ? __( 'Other events', 'rcobeca' ) : $rcobeca_label ); ?></a></li>
			<?php endforeach; ?>
		</ul>
	</nav>

	<section class="rcobeca-event-list__upcoming" aria-labelledby="rcobeca-events-upcoming">
		<h2 id="rcobeca-events-upcoming" class="rcobeca-event-list__heading"><?php esc_html_e( 'Upcoming', 'rcobeca' ); ?></h2>
		<?php if ( $rcobeca_soon ) : ?>
			<?php
			foreach ( $rcobeca_soon as $rcobeca_id ) {
				echo rcobeca_event_row( $rcobeca_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
			}
			?>
		<?php else : ?>
			<p class="rcobeca-event-list__empty">
				<?php esc_html_e( 'Nothing is scheduled just yet. The date of the next', 'rcobeca' ); ?>
				<a href="<?php echo esc_url( home_url( '/ball/' ) ); ?>"><?php esc_html_e( 'Royal Charity Ball', 'rcobeca' ); ?></a>
				<?php esc_html_e( 'will be announced here, and in our newsletter.', 'rcobeca' ); ?>
			</p>
		<?php endif; ?>
	</section>

	<section class="rcobeca-event-list__past" aria-labelledby="rcobeca-events-past">
		<h2 id="rcobeca-events-past" class="rcobeca-event-list__heading"><?php esc_html_e( 'Past events', 'rcobeca' ); ?></h2>
		<?php foreach ( $rcobeca_by_year as $rcobeca_year => $rcobeca_ids ) : ?>
			<div class="rcobeca-event-list__year">
				<h3 class="rcobeca-event-list__year-heading"><?php echo esc_html( (string) $rcobeca_year ); ?></h3>
				<div class="rcobeca-event-list__rows">
					<?php
					foreach ( $rcobeca_ids as $rcobeca_id ) {
						echo rcobeca_event_row( $rcobeca_id, 4 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
					}
					?>
				</div>
			</div>
		<?php endforeach; ?>
		<?php if ( ! $rcobeca_by_year ) : ?>
			<p class="rcobeca-event-list__empty"><?php esc_html_e( 'No past events of this type.', 'rcobeca' ); ?></p>
		<?php endif; ?>
	</section>
</div>
