/**
 * Editor UI for the Financial documents listing. Plain script (no build
 * step): the block is server-rendered, so the editor previews render.php.
 */
( function ( blocks, element, blockEditor, ServerSideRender ) {
	const el = element.createElement;

	blocks.registerBlockType( 'rcobeca/financial-documents', {
		edit: function () {
			return el( 'div', blockEditor.useBlockProps(), el( ServerSideRender, { block: 'rcobeca/financial-documents' } ) );
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.serverSideRender );
