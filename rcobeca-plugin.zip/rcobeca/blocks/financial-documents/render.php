<?php
/**
 * Renders the Financial documents by Club Year: an index of the years beside
 * one list per year, newest first. Without any documents it says what will
 * be posted, and how to ask the Treasurer for a copy now.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

$rcobeca_years = rcobeca_documents_by_club_year();
$rcobeca_types = rcobeca_document_types();
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'rcobeca-documents' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<?php if ( ! $rcobeca_years ) : ?>
		<div class="rcobeca-documents__empty">
			<p class="rcobeca-documents__empty-heading"><?php esc_html_e( 'What this section will hold', 'rcobeca' ); ?></p>
			<ul>
				<li><?php esc_html_e( 'The IRS determination letter, which confirms RCOBEC Foundation Inc.’s 501(c)(3) status', 'rcobeca' ); ?></li>
				<li><?php esc_html_e( 'Each Club Year’s annual report or Form 990', 'rcobeca' ); ?></li>
				<li><?php esc_html_e( 'Financial statements', 'rcobeca' ); ?></li>
			</ul>
			<p><?php esc_html_e( 'Each document is posted under its Club Year, newest first, as the Treasurer publishes it.', 'rcobeca' ); ?></p>
			<p class="rcobeca-documents__ask">
				<?php esc_html_e( 'Need the determination letter, or any of these, now? The Treasurer will send a copy on request.', 'rcobeca' ); ?>
				<a class="rcobeca-documents__email" href="<?php echo esc_url( 'mailto:treasurer@rcobeca.org?subject=' . rawurlencode( 'IRS determination letter' ) ); ?>"><?php esc_html_e( 'Email the Treasurer', 'rcobeca' ); ?></a>
			</p>
		</div>
	<?php else : ?>
		<nav class="rcobeca-documents__index" aria-label="<?php esc_attr_e( 'Club Years', 'rcobeca' ); ?>">
			<ul>
				<?php foreach ( array_keys( $rcobeca_years ) as $rcobeca_year ) : ?>
					<li><a href="#club-year-<?php echo esc_attr( (string) $rcobeca_year ); ?>"><?php echo esc_html( rcobeca_club_year_label( $rcobeca_year ) ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</nav>
		<div class="rcobeca-documents__years">
			<?php foreach ( $rcobeca_years as $rcobeca_year => $rcobeca_documents ) : ?>
				<section class="rcobeca-documents__year" id="club-year-<?php echo esc_attr( (string) $rcobeca_year ); ?>" aria-labelledby="club-year-<?php echo esc_attr( (string) $rcobeca_year ); ?>-heading">
					<h3 id="club-year-<?php echo esc_attr( (string) $rcobeca_year ); ?>-heading">
						<?php
						/* translators: %s: Club Year, e.g. 2025–26. */
						echo esc_html( sprintf( __( 'Club Year %s', 'rcobeca' ), rcobeca_club_year_label( $rcobeca_year ) ) );
						?>
					</h3>
					<ul>
						<?php foreach ( $rcobeca_documents as $rcobeca_document ) : ?>
							<li>
								<a href="<?php echo esc_url( $rcobeca_document['url'] ); ?>"><?php echo esc_html( $rcobeca_document['title'] ); ?></a>
								<span class="rcobeca-filetype">(PDF<?php echo '' !== $rcobeca_document['size'] ? ', ' . esc_html( $rcobeca_document['size'] ) : ''; ?>)</span>
								<?php if ( isset( $rcobeca_types[ $rcobeca_document['type'] ] ) && 'other' !== $rcobeca_document['type'] ) : ?>
									<span class="rcobeca-documents__type"><?php echo esc_html( $rcobeca_types[ $rcobeca_document['type'] ] ); ?></span>
								<?php endif; ?>
							</li>
						<?php endforeach; ?>
					</ul>
				</section>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</div>
