<?php
/**
 * Script dependencies for the form block's editor script (written by hand; there is no build step).
 *
 * @package RCOBECA
 */

return array(
	'dependencies' => array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render', 'wp-i18n' ),
	'version'      => '0.1.0',
);
