/**
 * Editor UI for the RCOBECA form. Plain script (no build step): the block is
 * server-rendered, so the editor previews render.php through ServerSideRender.
 */
( function ( blocks, element, blockEditor, components, ServerSideRender, i18n ) {
	const el = element.createElement;
	const __ = i18n.__;

	blocks.registerBlockType( 'rcobeca/form', {
		edit: function ( props ) {
			return el(
				'div',
				blockEditor.useBlockProps(),
				el(
					blockEditor.InspectorControls,
					null,
					el(
						components.PanelBody,
						{ title: __( 'Form', 'rcobeca' ) },
						el( components.SelectControl, {
							label: __( 'Which form', 'rcobeca' ),
							help: __( 'Messages are emailed to the Secretary (Contact questions about donations go to the Treasurer) and never stored.', 'rcobeca' ),
							value: props.attributes.form,
							options: [
								{ label: __( 'Contact', 'rcobeca' ), value: 'contact' },
								{ label: __( 'Update your details', 'rcobeca' ), value: 'update-details' },
							],
							onChange: function ( form ) {
								props.setAttributes( { form: form } );
							},
							__nextHasNoMarginBottom: true,
						} )
					)
				),
				el( components.Disabled, null, el( ServerSideRender, { block: 'rcobeca/form', attributes: props.attributes } ) )
			);
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.components, window.wp.serverSideRender, window.wp.i18n );
