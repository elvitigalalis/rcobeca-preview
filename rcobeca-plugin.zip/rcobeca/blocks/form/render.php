<?php
/**
 * Renders a form from RCOBECA\Forms: the form itself, its error summary after
 * an invalid submission, or its thank-you message after a sent one.
 *
 * @package RCOBECA
 *
 * @var array $attributes Block attributes: form.
 */

defined( 'ABSPATH' ) || exit;

use RCOBECA\Forms;

$rcobeca_name       = (string) ( $attributes['form'] ?? 'contact' );
$rcobeca_definition = Forms::definitions()[ $rcobeca_name ] ?? null;
if ( ! $rcobeca_definition ) {
	return;
}

$rcobeca_id      = Forms::id( $rcobeca_name );
$rcobeca_state   = Forms::state( $rcobeca_name );
$rcobeca_errors  = $rcobeca_state['errors'];
$rcobeca_values  = $rcobeca_state['values'];
$rcobeca_wrapper = get_block_wrapper_attributes(
	array(
		'class' => 'rcobeca-form',
		'id'    => $rcobeca_id,
	)
);

/**
 * Moves keyboard and screen-reader focus to an element once the page loads.
 *
 * @param string $id Element id.
 */
$rcobeca_focus = static function ( string $id ): void {
	echo '<script>addEventListener("load",function(){document.getElementById(' . wp_json_encode( $id ) . ').focus()});</script>';
};
?>
<div <?php echo $rcobeca_wrapper; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped by get_block_wrapper_attributes(). ?>>
<?php if ( Forms::sent( $rcobeca_name ) ) : ?>
	<div class="rcobeca-form__thanks" id="<?php echo esc_attr( $rcobeca_id . '-thanks' ); ?>" role="status" tabindex="-1">
		<h2><?php esc_html_e( 'Thank you', 'rcobeca' ); ?></h2>
		<p><?php echo esc_html( $rcobeca_definition['thanks'] ); ?></p>
		<p class="rcobeca-form__again"><a href="<?php echo esc_url( get_permalink() . '#' . $rcobeca_id ); ?>"><?php esc_html_e( 'Send another', 'rcobeca' ); ?></a></p>
	</div>
	<?php $rcobeca_focus( $rcobeca_id . '-thanks' ); ?>
<?php else : ?>
	<?php if ( $rcobeca_errors ) : ?>
	<div class="rcobeca-form__summary" id="<?php echo esc_attr( $rcobeca_id . '-problem' ); ?>" role="alert" tabindex="-1">
		<h2><?php esc_html_e( 'There is a problem', 'rcobeca' ); ?></h2>
		<ul>
			<?php foreach ( $rcobeca_errors as $rcobeca_key => $rcobeca_error ) : ?>
			<li>
				<?php if ( 'form' === $rcobeca_key ) : ?>
					<?php echo esc_html( $rcobeca_error ); ?>
				<?php else : ?>
					<a href="<?php echo esc_attr( "#$rcobeca_id-$rcobeca_key" ); ?>"><?php echo esc_html( $rcobeca_error ); ?></a>
				<?php endif; ?>
			</li>
			<?php endforeach; ?>
		</ul>
	</div>
		<?php $rcobeca_focus( $rcobeca_id . '-problem' ); ?>
	<?php endif; ?>

	<form class="rcobeca-form__form" method="post" action="<?php echo esc_attr( '#' . $rcobeca_id ); ?>" aria-label="<?php echo esc_attr( $rcobeca_definition['label'] ); ?>" novalidate>
		<p class="rcobeca-form__note"><?php esc_html_e( 'Fields marked optional can be left empty. We email what you send to the committee and do not keep it on this website.', 'rcobeca' ); ?></p>
		<?php
		foreach ( $rcobeca_definition['fields'] as $rcobeca_key => $rcobeca_field ) :
			$rcobeca_type     = $rcobeca_field['type'] ?? 'text';
			$rcobeca_field_id = "$rcobeca_id-$rcobeca_key";
			$rcobeca_value    = $rcobeca_values[ $rcobeca_key ] ?? ( 'checkboxes' === $rcobeca_type ? array() : '' );
			$rcobeca_error    = $rcobeca_errors[ $rcobeca_key ] ?? '';
			$rcobeca_describe = trim( ( isset( $rcobeca_field['hint'] ) ? "$rcobeca_field_id-hint " : '' ) . ( $rcobeca_error ? "$rcobeca_field_id-error" : '' ) );
			$rcobeca_common   = sprintf(
				'id="%1$s" name="%2$s"%3$s%4$s%5$s',
				esc_attr( $rcobeca_field_id ),
				esc_attr( "rcobeca[$rcobeca_key]" ),
				! empty( $rcobeca_field['required'] ) ? ' required' : '',
				$rcobeca_describe ? ' aria-describedby="' . esc_attr( $rcobeca_describe ) . '"' : '',
				$rcobeca_error ? ' aria-invalid="true"' : ''
			);
			$rcobeca_messages = static function () use ( $rcobeca_field, $rcobeca_field_id, $rcobeca_error ): void {
				if ( isset( $rcobeca_field['hint'] ) ) {
					echo '<p class="rcobeca-form__hint" id="' . esc_attr( "$rcobeca_field_id-hint" ) . '">' . esc_html( $rcobeca_field['hint'] ) . '</p>';
				}
				if ( $rcobeca_error ) {
					echo '<p class="rcobeca-form__error" id="' . esc_attr( "$rcobeca_field_id-error" ) . '"><span class="screen-reader-text">' . esc_html__( 'Error:', 'rcobeca' ) . ' </span>' . esc_html( $rcobeca_error ) . '</p>';
				}
			};
			$rcobeca_class    = 'rcobeca-form__field rcobeca-form__field--' . $rcobeca_type . ( $rcobeca_error ? ' has-error' : '' );
			?>
			<?php if ( 'checkboxes' === $rcobeca_type ) : ?>
		<fieldset class="<?php echo esc_attr( $rcobeca_class ); ?>" id="<?php echo esc_attr( $rcobeca_field_id ); ?>">
			<legend><?php echo esc_html( $rcobeca_field['label'] ); ?></legend>
				<?php $rcobeca_messages(); ?>
				<?php foreach ( $rcobeca_field['options'] as $rcobeca_index => $rcobeca_option ) : ?>
			<label class="rcobeca-form__choice"><input type="checkbox" name="<?php echo esc_attr( "rcobeca[$rcobeca_key][]" ); ?>" value="<?php echo esc_attr( $rcobeca_option ); ?>"<?php checked( in_array( $rcobeca_option, (array) $rcobeca_value, true ) ); ?>> <?php echo esc_html( $rcobeca_option ); ?></label>
				<?php endforeach; ?>
		</fieldset>
			<?php else : ?>
		<div class="<?php echo esc_attr( $rcobeca_class ); ?>">
			<label for="<?php echo esc_attr( $rcobeca_field_id ); ?>"><?php echo esc_html( $rcobeca_field['label'] ); ?></label>
				<?php $rcobeca_messages(); ?>
				<?php if ( 'textarea' === $rcobeca_type ) : ?>
			<textarea <?php echo $rcobeca_common; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above. ?> rows="<?php echo 'message' === $rcobeca_key ? 7 : 4; ?>"><?php echo esc_textarea( $rcobeca_value ); ?></textarea>
				<?php elseif ( 'select' === $rcobeca_type ) : ?>
			<select <?php echo $rcobeca_common; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above. ?>>
					<?php foreach ( array_keys( $rcobeca_field['options'] ) as $rcobeca_option ) : ?>
				<option<?php selected( $rcobeca_option, $rcobeca_value ); ?>><?php echo esc_html( $rcobeca_option ); ?></option>
					<?php endforeach; ?>
			</select>
				<?php else : ?>
			<input <?php echo $rcobeca_common; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above. ?> value="<?php echo esc_attr( $rcobeca_value ); ?>"
					<?php
					if ( 'year' === $rcobeca_type ) {
						echo ' type="text" inputmode="numeric" maxlength="4" autocomplete="off"';
					} else {
						echo ' type="' . esc_attr( $rcobeca_type ) . '"' . ( isset( $rcobeca_field['autocomplete'] ) ? ' autocomplete="' . esc_attr( $rcobeca_field['autocomplete'] ) . '"' : '' );
					}
					?>
			>
				<?php endif; ?>
		</div>
			<?php endif; ?>
		<?php endforeach; ?>

		<div class="rcobeca-form__trap" aria-hidden="true">
			<label for="<?php echo esc_attr( "$rcobeca_id-" . Forms::HONEYPOT ); ?>"><?php esc_html_e( 'Leave this field empty', 'rcobeca' ); ?></label>
			<input type="text" id="<?php echo esc_attr( "$rcobeca_id-" . Forms::HONEYPOT ); ?>" name="<?php echo esc_attr( 'rcobeca[' . Forms::HONEYPOT . ']' ); ?>" value="" tabindex="-1" autocomplete="off">
		</div>
		<input type="hidden" name="rcobeca_form" value="<?php echo esc_attr( $rcobeca_name ); ?>">
		<p class="rcobeca-form__actions"><button type="submit" class="wp-element-button"><?php echo esc_html( $rcobeca_definition['submit'] ); ?></button></p>
	</form>
<?php endif; ?>
</div>
