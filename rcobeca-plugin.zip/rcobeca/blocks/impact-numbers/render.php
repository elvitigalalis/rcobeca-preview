<?php
/**
 * Renders the impact band: a heading with an "As of" stamp, then each figure
 * with its sentence and a link to its proof (Giving What We Can's stat band).
 * Figures come from rcobeca_impact_figures(); an editor may add one more.
 *
 * @package RCOBECA
 *
 * @var array $attributes Block attributes: extraFigure, extraLabel, extraLinkText, extraUrl.
 */

defined( 'ABSPATH' ) || exit;

$rcobeca_figures = rcobeca_impact_figures();
$rcobeca_extra   = array();
foreach ( array( 'extraFigure', 'extraLabel', 'extraLinkText', 'extraUrl' ) as $rcobeca_key ) {
	$rcobeca_extra[ $rcobeca_key ] = trim( (string) ( $attributes[ $rcobeca_key ] ?? '' ) );
}
if ( '' !== ( $rcobeca_extra['extraFigure'] ?? '' ) && '' !== ( $rcobeca_extra['extraLabel'] ?? '' ) && '' !== ( $rcobeca_extra['extraUrl'] ?? '' ) ) {
	$rcobeca_figures[] = array(
		'figure' => $rcobeca_extra['extraFigure'],
		'label'  => $rcobeca_extra['extraLabel'],
		'link'   => '' !== ( $rcobeca_extra['extraLinkText'] ?? '' ) ? $rcobeca_extra['extraLinkText'] : __( 'Where this comes from', 'rcobeca' ),
		'url'    => $rcobeca_extra['extraUrl'],
	);
}
if ( ! $rcobeca_figures ) {
	return;
}
?>
<section <?php echo get_block_wrapper_attributes( array( 'class' => 'rcobeca-impact alignfull' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> aria-labelledby="rcobeca-impact-heading">
	<div class="rcobeca-impact__inner">
		<div class="rcobeca-impact__head">
			<p class="is-style-kicker"><?php esc_html_e( 'Our impact', 'rcobeca' ); ?></p>
			<h2 class="rcobeca-impact__heading" id="rcobeca-impact-heading"><?php esc_html_e( 'RCOBECA in numbers', 'rcobeca' ); ?></h2>
			<p class="rcobeca-impact__asof">
				<?php
				/* translators: %s: month and year. */
				echo esc_html( sprintf( __( 'As of %s, counted from our records', 'rcobeca' ), wp_date( 'F Y' ) ) );
				?>
			</p>
		</div>
		<ul class="rcobeca-impact__stats">
			<?php foreach ( $rcobeca_figures as $rcobeca_figure ) : ?>
				<li class="rcobeca-impact__stat">
					<strong class="rcobeca-impact__figure"><?php echo esc_html( $rcobeca_figure['figure'] ); ?></strong>
					<span class="rcobeca-impact__label"><?php echo esc_html( $rcobeca_figure['label'] ); ?></span>
					<a class="rcobeca-impact__proof" href="<?php echo esc_url( $rcobeca_figure['url'] ); ?>"><?php echo esc_html( $rcobeca_figure['link'] ); ?></a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
