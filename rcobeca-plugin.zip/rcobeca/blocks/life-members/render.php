<?php
/**
 * Renders the Life Members honour roll: each name with the date he joined,
 * grouped under the year, deceased members marked with an asterisk and a key,
 * the "as of" date and a corrections address.
 *
 * @package RCOBECA
 *
 * @var array $attributes Block attributes: asOf, email.
 */

defined( 'ABSPATH' ) || exit;

$rcobeca_by_year = array();
foreach ( rcobeca_life_members() as $rcobeca_member ) {
	$rcobeca_since                                       = (string) get_post_meta( $rcobeca_member->ID, 'rcobeca_member_since', true );
	$rcobeca_by_year[ substr( $rcobeca_since, 0, 4 ) ][] = $rcobeca_member;
}
$rcobeca_email = sanitize_email( (string) ( $attributes['email'] ?? '' ) );
$rcobeca_as_of = trim( (string) ( $attributes['asOf'] ?? '' ) );
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'rcobeca-life-members' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<?php if ( '' !== $rcobeca_as_of ) : ?>
		<p class="rcobeca-life-members__as-of">
			<?php
			/* translators: %s: date. */
			echo esc_html( sprintf( __( 'As of %s', 'rcobeca' ), $rcobeca_as_of ) );
			?>
		</p>
	<?php endif; ?>
	<?php foreach ( $rcobeca_by_year as $rcobeca_year => $rcobeca_members ) : ?>
		<section class="rcobeca-life-members__group">
			<h2 class="rcobeca-life-members__year">
				<?php
				/* translators: %s: year. */
				echo esc_html( '' !== (string) $rcobeca_year ? sprintf( __( 'Since %s', 'rcobeca' ), $rcobeca_year ) : __( 'Date not recorded', 'rcobeca' ) );
				?>
			</h2>
			<ul class="rcobeca-life-members__names" role="list">
				<?php foreach ( $rcobeca_members as $rcobeca_member ) : ?>
					<?php
					$rcobeca_person = (int) get_post_meta( $rcobeca_member->ID, 'rcobeca_person', true );
					$rcobeca_name   = esc_html( get_the_title( $rcobeca_member ) );
					if ( $rcobeca_person && rcobeca_person_has_profile( $rcobeca_person ) ) {
						$rcobeca_name = '<a href="' . esc_url( get_permalink( $rcobeca_person ) ) . '">' . $rcobeca_name . '</a>';
					}
					?>
					<?php $rcobeca_since = (string) get_post_meta( $rcobeca_member->ID, 'rcobeca_member_since', true ); ?>
					<li>
						<span class="rcobeca-life-members__name">
							<?php echo $rcobeca_name; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above. ?>
							<?php if ( '1' === get_post_meta( $rcobeca_member->ID, 'rcobeca_deceased', true ) ) : ?>
								<span aria-hidden="true">*</span><span class="rcobeca-life-members__hidden"><?php esc_html_e( '(deceased)', 'rcobeca' ); ?></span>
							<?php endif; ?>
						</span>
						<?php if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $rcobeca_since ) ) : ?>
							<span class="rcobeca-life-members__since"><span class="rcobeca-life-members__dot">·</span> <time datetime="<?php echo esc_attr( $rcobeca_since ); ?>"><?php echo esc_html( gmdate( 'F j, Y', (int) strtotime( $rcobeca_since . ' 12:00:00 UTC' ) ) ); ?></time></span>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		</section>
	<?php endforeach; ?>
	<div class="rcobeca-life-members__notes">
		<p class="rcobeca-life-members__key"><?php esc_html_e( '* Deceased', 'rcobeca' ); ?></p>
		<?php if ( $rcobeca_email ) : ?>
			<p class="rcobeca-life-members__corrections">
				<?php
				printf(
					/* translators: %s: email link. */
					esc_html__( 'Spot a mistake or a missing name? Please write to the Secretary at %s.', 'rcobeca' ),
					'<a href="' . esc_url( 'mailto:' . $rcobeca_email . '?subject=' . rawurlencode( 'Life Members roll: correction' ) ) . '">' . esc_html( $rcobeca_email ) . '</a>'
				);
				?>
			</p>
		<?php endif; ?>
	</div>
</div>
