<?php
/**
 * Renders News: Project and Event stories, newest first (PD Soros listing,
 * Exeter "Alumni Today" rows). With a limit (the home page), that many rows,
 * skipping stories already shown in full higher up the page. Without one (the
 * News page), a lead story with a large photo, then rows, 12 stories to a page:
 * page 2 is /news/2/.
 *
 * @package RCOBECA
 *
 * @var array $attributes Block attributes: limit, headingLevel.
 */

defined( 'ABSPATH' ) || exit;

$rcobeca_limit    = (int) ( $attributes['limit'] ?? 0 );
$rcobeca_level    = max( 2, min( 6, (int) ( $attributes['headingLevel'] ?? 2 ) ) );
$rcobeca_per_page = 12;
$rcobeca_ids      = rcobeca_stories();
$rcobeca_page     = 1;
$rcobeca_pages    = 1;

if ( $rcobeca_limit > 0 ) {
	$rcobeca_ids = array_slice( array_values( array_diff( $rcobeca_ids, rcobeca_shown() ) ), 0, $rcobeca_limit );
} else {
	$rcobeca_pages = rcobeca_news_pages();
	$rcobeca_page  = min( $rcobeca_pages, max( 1, (int) get_query_var( 'page' ) ) );
	$rcobeca_ids   = array_slice( $rcobeca_ids, ( $rcobeca_page - 1 ) * $rcobeca_per_page, $rcobeca_per_page );
}
rcobeca_shown( $rcobeca_ids );

$rcobeca_lead = 0 === $rcobeca_limit && 1 === $rcobeca_page ? array_shift( $rcobeca_ids ) : null;
$rcobeca_base = trailingslashit( (string) get_permalink() );
$rcobeca_url  = static fn( int $n ) => 1 === $n ? $rcobeca_base : $rcobeca_base . $n . '/';

/**
 * One story: kicker and date, linked title, excerpt, photo.
 *
 * @param int  $id Story ID.
 * @param bool $lead Whether this is the lead story.
 */
$rcobeca_story = static function ( int $id, bool $lead ) use ( $rcobeca_level ): string {
	$link  = (string) get_permalink( $id );
	$photo = has_post_thumbnail( $id ) ? get_the_post_thumbnail(
		$id,
		$lead ? 'large' : 'medium_large',
		array(
			'loading' => $lead ? 'eager' : 'lazy',
			'sizes'   => $lead ? '(max-width: 782px) 100vw, 640px' : '(max-width: 600px) 100vw, 220px',
		)
	) : '';
	$class = 'rcobeca-news__item' . ( $lead ? ' is-lead' : '' ) . ( $photo ? ' has-image' : '' );
	$html  = '<article class="' . esc_attr( $class ) . '">';
	if ( $photo ) {
		$html .= '<a class="rcobeca-news__image" href="' . esc_url( $link ) . '" tabindex="-1" aria-hidden="true">' . $photo . '</a>';
	}
	$html   .= '<div class="rcobeca-news__text">';
	$html   .= '<p class="rcobeca-news__meta"><span class="rcobeca-news__kicker">' . esc_html( rcobeca_story_kicker( $id ) ) . '</span> <time datetime="' . esc_attr( rcobeca_story_date( $id ) ) . '">' . esc_html( rcobeca_story_date_label( $id ) ) . '</time></p>';
	$html   .= "<h$rcobeca_level class=\"rcobeca-news__title\"><a href=\"" . esc_url( $link ) . '">' . esc_html( get_the_title( $id ) ) . "</a></h$rcobeca_level>";
	$excerpt = rcobeca_story_excerpt( $id, $lead ? 45 : 28 );
	if ( '' !== $excerpt ) {
		$html .= '<p class="rcobeca-news__excerpt">' . esc_html( $excerpt ) . '</p>';
	}
	return $html . '</div></article>';
};
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'rcobeca-news' . ( $rcobeca_limit > 0 ? ' is-strip' : '' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<?php
	// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- stories are escaped by $rcobeca_story.
	if ( $rcobeca_lead ) {
		echo $rcobeca_story( $rcobeca_lead, true );
	}
	if ( $rcobeca_ids ) {
		echo '<div class="rcobeca-news__list">';
		foreach ( $rcobeca_ids as $rcobeca_id ) {
			echo $rcobeca_story( $rcobeca_id, false );
		}
		echo '</div>';
	}
	// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
	?>
	<?php if ( $rcobeca_pages > 1 ) : ?>
		<nav class="rcobeca-news__pages" aria-label="<?php esc_attr_e( 'More stories', 'rcobeca' ); ?>">
			<?php if ( $rcobeca_page > 1 ) : ?>
				<a class="rcobeca-news__newer" href="<?php echo esc_url( $rcobeca_url( $rcobeca_page - 1 ) ); ?>"><?php esc_html_e( 'Newer stories', 'rcobeca' ); ?></a>
			<?php endif; ?>
			<span class="rcobeca-news__count">
				<?php
				/* translators: 1: page number, 2: number of pages. */
				echo esc_html( sprintf( __( 'Page %1$d of %2$d', 'rcobeca' ), $rcobeca_page, $rcobeca_pages ) );
				?>
			</span>
			<?php if ( $rcobeca_page < $rcobeca_pages ) : ?>
				<a class="rcobeca-news__older" href="<?php echo esc_url( $rcobeca_url( $rcobeca_page + 1 ) ); ?>"><?php esc_html_e( 'Older stories', 'rcobeca' ); ?></a>
			<?php endif; ?>
		</nav>
	<?php endif; ?>
</div>
