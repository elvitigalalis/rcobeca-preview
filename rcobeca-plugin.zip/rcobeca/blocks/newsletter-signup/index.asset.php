<?php
/**
 * Script dependencies for the newsletter sign-up editor script (written by hand; there is no build step).
 *
 * @package RCOBECA
 */

return array(
	'dependencies' => array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render' ),
	'version'      => '0.1.0',
);
