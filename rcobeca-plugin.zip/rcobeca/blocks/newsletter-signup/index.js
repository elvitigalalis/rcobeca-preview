/**
 * Editor UI for the newsletter sign-up button. Plain script (no build step):
 * the block has no settings of its own; its link is set under Settings → Join
 * and newsletter, so the editor just previews render.php.
 */
( function ( blocks, element, blockEditor, components, ServerSideRender ) {
	const el = element.createElement;

	blocks.registerBlockType( 'rcobeca/newsletter-signup', {
		edit: function () {
			return el(
				'div',
				blockEditor.useBlockProps(),
				el( components.Disabled, null, el( ServerSideRender, { block: 'rcobeca/newsletter-signup' } ) )
			);
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.components, window.wp.serverSideRender );
