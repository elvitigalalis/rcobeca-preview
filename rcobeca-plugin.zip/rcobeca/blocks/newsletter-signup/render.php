<?php
/**
 * Renders the newsletter sign-up: a gold button to the Zeffy sign-up form set
 * under Settings → Join and newsletter, or, until it is set, an email to the
 * Secretary asking to join the mailing list.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

$rcobeca_link = rcobeca_zeffy_setting( 'newsletter' );
$rcobeca_note = __( 'Sign-up and unsubscribing are handled by Zeffy, which RCOBECA also uses for payments.', 'rcobeca' );
if ( '' === $rcobeca_link ) {
	$rcobeca_link = 'mailto:secretary@rcobeca.org?subject=' . rawurlencode( __( 'Add me to the RCOBECA newsletter', 'rcobeca' ) );
	$rcobeca_note = __( 'Opens an email to the Secretary, who adds you to the list.', 'rcobeca' );
}
$rcobeca_wrapper = get_block_wrapper_attributes( array( 'class' => 'rcobeca-newsletter-signup' ) );
?>
<div <?php echo $rcobeca_wrapper; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped by get_block_wrapper_attributes(). ?>>
	<div class="wp-block-buttons">
		<div class="wp-block-button is-style-gold"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( $rcobeca_link, array( 'https', 'mailto' ) ); ?>"><?php esc_html_e( 'Sign up for the newsletter', 'rcobeca' ); ?></a></div>
	</div>
	<p class="rcobeca-newsletter-signup__note"><?php echo esc_html( $rcobeca_note ); ?></p>
</div>
