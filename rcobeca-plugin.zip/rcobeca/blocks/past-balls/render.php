<?php
/**
 * Renders Past Balls: one row per Royal Charity Ball, newest first, grouped
 * by decade with a jump bar (California College of the Arts' past galas,
 * simplified). A row links to the Ball's page only when it has one.
 *
 * @package RCOBECA
 *
 * @var array $attributes Block attributes.
 */

use RCOBECA\Events;

defined( 'ABSPATH' ) || exit;

$rcobeca_decades = array();
foreach ( Events::balls() as $rcobeca_id ) {
	if ( ! Events::is_upcoming( $rcobeca_id ) ) {
		$rcobeca_decades[ (int) floor( Events::year( $rcobeca_id ) / 10 ) * 10 ][] = $rcobeca_id;
	}
}
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'rcobeca-past-balls' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<nav class="rcobeca-past-balls__jump" aria-label="<?php esc_attr_e( 'Jump to a decade', 'rcobeca' ); ?>">
		<ul>
			<?php foreach ( array_keys( $rcobeca_decades ) as $rcobeca_decade ) : ?>
				<li><a href="#balls-<?php echo esc_attr( $rcobeca_decade . 's' ); ?>"><?php echo esc_html( $rcobeca_decade . 's' ); ?></a></li>
			<?php endforeach; ?>
		</ul>
	</nav>

	<?php foreach ( $rcobeca_decades as $rcobeca_decade => $rcobeca_ids ) : ?>
		<section class="rcobeca-past-balls__decade" id="balls-<?php echo esc_attr( $rcobeca_decade . 's' ); ?>" aria-labelledby="balls-<?php echo esc_attr( $rcobeca_decade ); ?>-heading">
			<h2 class="rcobeca-past-balls__decade-heading" id="balls-<?php echo esc_attr( $rcobeca_decade ); ?>-heading"><?php echo esc_html( $rcobeca_decade . 's' ); ?></h2>
			<?php foreach ( $rcobeca_ids as $rcobeca_id ) : ?>
				<?php
				$rcobeca_year  = Events::year( $rcobeca_id );
				$rcobeca_page  = Events::has_page( $rcobeca_id );
				$rcobeca_title = esc_html( get_the_title( $rcobeca_id ) );
				$rcobeca_when  = 'year' === Events::get( $rcobeca_id, 'date_precision' ) ? '' : Events::date_label( $rcobeca_id );
				$rcobeca_facts = Events::details( $rcobeca_id );
				unset( $rcobeca_facts[ __( 'Date', 'rcobeca' ) ], $rcobeca_facts[ __( 'Venue', 'rcobeca' ) ] );
				$rcobeca_links = $rcobeca_facts[ __( 'Photos and video', 'rcobeca' ) ] ?? '';
				$rcobeca_doc   = $rcobeca_facts[ __( 'Souvenir Journal', 'rcobeca' ) ] ?? '';
				unset( $rcobeca_facts[ __( 'Photos and video', 'rcobeca' ) ], $rcobeca_facts[ __( 'Souvenir Journal', 'rcobeca' ) ] );
				?>
				<article class="rcobeca-past-ball<?php echo has_post_thumbnail( $rcobeca_id ) && $rcobeca_page ? ' has-image' : ''; ?>" id="ball-<?php echo esc_attr( (string) $rcobeca_year ); ?>">
					<p class="rcobeca-past-ball__year"><?php echo esc_html( (string) $rcobeca_year ); ?></p>
					<div class="rcobeca-past-ball__text">
						<p class="rcobeca-past-ball__kicker"><?php echo esc_html( Events::kicker( $rcobeca_id ) ); ?></p>
						<h3 class="rcobeca-past-ball__title">
							<?php if ( $rcobeca_page ) : ?>
								<a href="<?php echo esc_url( (string) get_permalink( $rcobeca_id ) ); ?>"><?php echo $rcobeca_title; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above. ?></a>
							<?php else : ?>
								<?php echo $rcobeca_title; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above. ?>
							<?php endif; ?>
						</h3>
						<p class="rcobeca-past-ball__when"><?php echo esc_html( implode( ' · ', array_filter( array( $rcobeca_when, Events::place( $rcobeca_id ) ), 'strlen' ) ) ); ?></p>
						<?php if ( $rcobeca_facts ) : ?>
							<dl class="rcobeca-past-ball__facts">
								<?php foreach ( $rcobeca_facts as $rcobeca_term => $rcobeca_value ) : ?>
									<div><dt><?php echo esc_html( $rcobeca_term ); ?></dt> <dd><?php echo wp_kses_post( $rcobeca_value ); ?></dd></div>
								<?php endforeach; ?>
							</dl>
						<?php endif; ?>
						<?php if ( '' !== $rcobeca_links || '' !== $rcobeca_doc ) : ?>
							<p class="rcobeca-past-ball__links">
								<?php
								echo wp_kses_post(
									implode(
										' · ',
										array_filter(
											array(
												$rcobeca_links,
												'' !== $rcobeca_doc ? '<a href="' . esc_url( Events::journal_url( $rcobeca_id ) ) . '">' . esc_html__( 'Souvenir Journal', 'rcobeca' ) . '</a>' : '',
											)
										)
									)
								);
								?>
							</p>
						<?php endif; ?>

					</div>
					<?php if ( $rcobeca_page && has_post_thumbnail( $rcobeca_id ) ) : ?>
						<a class="rcobeca-past-ball__image" href="<?php echo esc_url( (string) get_permalink( $rcobeca_id ) ); ?>" tabindex="-1" aria-hidden="true">
							<?php
							echo get_the_post_thumbnail(
								$rcobeca_id,
								'medium',
								array(
									'alt'     => '',
									'loading' => 'lazy',
								)
							);
							?>
						</a>
					<?php endif; ?>
				</article>
			<?php endforeach; ?>
		</section>
	<?php endforeach; ?>
</div>
