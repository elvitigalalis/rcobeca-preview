<?php
/**
 * Renders Past Presidents: Club Year and name, newest first, optionally with
 * the Club Year's major events.
 *
 * @package RCOBECA
 *
 * @var array $attributes Block attributes: showHighlights.
 */

defined( 'ABSPATH' ) || exit;

$rcobeca_presidents = rcobeca_presidents();
if ( ! $rcobeca_presidents ) {
	return;
}
$rcobeca_events = ! empty( $attributes['showHighlights'] );
$rcobeca_class  = 'rcobeca-presidents' . ( $rcobeca_events ? ' rcobeca-presidents--events' : '' );
?>
<ul <?php echo get_block_wrapper_attributes( array( 'class' => $rcobeca_class ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> role="list">
	<?php foreach ( $rcobeca_presidents as $rcobeca_term ) : ?>
		<li class="rcobeca-presidents__item">
			<span class="rcobeca-presidents__year"><?php echo esc_html( rcobeca_club_year_label( $rcobeca_term['year'] ) ); ?></span>
			<span class="rcobeca-presidents__name"><?php echo rcobeca_person_link( $rcobeca_term['person'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?></span>
			<?php if ( $rcobeca_events && '' !== $rcobeca_term['highlights'] ) : ?>
				<span class="rcobeca-presidents__events"><?php echo esc_html( $rcobeca_term['highlights'] ); ?></span>
			<?php endif; ?>
		</li>
	<?php endforeach; ?>
</ul>
