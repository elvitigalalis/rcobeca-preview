<?php
/**
 * Renders the facts line under a Person's name: "MD · Batch of 1985 ·
 * President, 2017–18 · Life Member".
 *
 * @package RCOBECA
 *
 * @var WP_Block $block Block instance (context: postId).
 */

defined( 'ABSPATH' ) || exit;

$rcobeca_person = (int) ( $block->context['postId'] ?? get_the_ID() );
if ( 'rcobeca_person' !== get_post_type( $rcobeca_person ) ) {
	return;
}
$rcobeca_terms = rcobeca_person_terms( $rcobeca_person );
$rcobeca_batch = (string) get_post_meta( $rcobeca_person, 'rcobeca_batch_year', true );
$rcobeca_facts = array_filter(
	array(
		(string) get_post_meta( $rcobeca_person, 'rcobeca_post_nominals', true ),
		/* translators: %s: Royal College batch year. */
		'' !== $rcobeca_batch ? sprintf( __( 'Royal College, batch of %s', 'rcobeca' ), $rcobeca_batch ) : '',
		$rcobeca_terms ? $rcobeca_terms[0]['role'] . ', ' . rcobeca_club_year_label( $rcobeca_terms[0]['year'] ) : '',
		function_exists( 'rcobeca_life_member_since' ) && rcobeca_life_member_since( $rcobeca_person ) ? __( 'Life Member', 'rcobeca' ) : '',
	)
);
if ( ! $rcobeca_facts ) {
	return;
}
?>
<p <?php echo get_block_wrapper_attributes( array( 'class' => 'rcobeca-person-facts' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>><?php echo esc_html( implode( ' · ', $rcobeca_facts ) ); ?></p>
