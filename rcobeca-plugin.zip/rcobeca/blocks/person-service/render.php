<?php
/**
 * Renders a Person's service: every Committee Term by Club Year (each linked
 * to that Club Year in the Committee history), and his Life Membership.
 *
 * @package RCOBECA
 *
 * @var WP_Block $block Block instance (context: postId).
 */

defined( 'ABSPATH' ) || exit;

$rcobeca_person = (int) ( $block->context['postId'] ?? get_the_ID() );
if ( 'rcobeca_person' !== get_post_type( $rcobeca_person ) ) {
	return;
}
$rcobeca_terms   = rcobeca_person_terms( $rcobeca_person );
$rcobeca_history = get_page_by_path( 'committee/history' );
$rcobeca_since   = function_exists( 'rcobeca_life_member_since' ) ? rcobeca_life_member_since( $rcobeca_person ) : '';
?>
<aside <?php echo get_block_wrapper_attributes( array( 'class' => 'rcobeca-service' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<?php if ( $rcobeca_terms ) : ?>
		<h2 class="rcobeca-service__heading"><?php esc_html_e( 'Committee service', 'rcobeca' ); ?></h2>
		<ul class="rcobeca-service__list">
			<?php foreach ( $rcobeca_terms as $rcobeca_term ) : ?>
				<?php $rcobeca_year = rcobeca_club_year_label( $rcobeca_term['year'] ); ?>
				<li>
					<?php if ( $rcobeca_history ) : ?>
						<a class="rcobeca-service__year" href="<?php echo esc_url( get_permalink( $rcobeca_history ) . '#club-year-' . $rcobeca_term['year'] ); ?>"><?php echo esc_html( $rcobeca_year ); ?></a>
					<?php else : ?>
						<span class="rcobeca-service__year"><?php echo esc_html( $rcobeca_year ); ?></span>
					<?php endif; ?>
					<span class="rcobeca-service__role"><?php echo esc_html( $rcobeca_term['role'] ); ?></span>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
	<?php if ( $rcobeca_since ) : ?>
		<h2 class="rcobeca-service__heading"><?php esc_html_e( 'Life Member', 'rcobeca' ); ?></h2>
		<p class="rcobeca-service__since">
			<?php
			/* translators: %s: date. */
			echo esc_html( sprintf( __( 'Since %s', 'rcobeca' ), $rcobeca_since ) );
			?>
		</p>
	<?php endif; ?>
</aside>
