/**
 * Editor UI for the Project listing. Plain script (no build step): the block
 * is server-rendered, so the editor previews render.php.
 */
( function ( blocks, element, blockEditor, components, ServerSideRender, i18n ) {
	const el = element.createElement;
	const __ = i18n.__;

	blocks.registerBlockType( 'rcobeca/project-list', {
		edit: function ( props ) {
			return el(
				'div',
				blockEditor.useBlockProps(),
				el(
					blockEditor.InspectorControls,
					null,
					el(
						components.PanelBody,
						{ title: __( 'Listing', 'rcobeca' ) },
						el( components.ToggleControl, {
							label: __( 'Show the status and beneficiary filters', 'rcobeca' ),
							checked: props.attributes.filters,
							onChange: function ( filters ) {
								props.setAttributes( { filters: filters } );
							},
							__nextHasNoMarginBottom: true,
						} ),
						el( components.TextControl, {
							label: __( 'Number of Projects (0 for all)', 'rcobeca' ),
							type: 'number',
							value: props.attributes.limit,
							onChange: function ( limit ) {
								props.setAttributes( { limit: parseInt( limit, 10 ) || 0 } );
							},
							__nextHasNoMarginBottom: true,
						} )
					)
				),
				el( ServerSideRender, { block: 'rcobeca/project-list', attributes: props.attributes } )
			);
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.components, window.wp.serverSideRender, window.wp.i18n );
