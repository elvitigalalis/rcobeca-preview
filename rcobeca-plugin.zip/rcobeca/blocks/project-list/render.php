<?php
/**
 * Renders the Project listing: Watsi-style photo cards with status, year and
 * place, Fundraising first, then the newest. Filters are plain links that
 * set ?status= and ?beneficiary=, so a filtered view has its own address.
 * The full listing shows 12 cards a page; "Show more" is a link to the next
 * page (?pg=2) that view.js turns into loading those cards in place.
 *
 * @package RCOBECA
 *
 * @var array $attributes Block attributes: filters, limit.
 */

defined( 'ABSPATH' ) || exit;

$rcobeca_statuses = rcobeca_project_statuses();
$rcobeca_benefits = rcobeca_project_beneficiaries();
$rcobeca_filters  = ! empty( $attributes['filters'] );
$rcobeca_limit    = (int) ( $attributes['limit'] ?? 0 );

// Public, read-only filters: validated against the known values, no nonce needed.
// phpcs:disable WordPress.Security.NonceVerification.Recommended
$rcobeca_status  = $rcobeca_filters ? sanitize_key( wp_unslash( $_GET['status'] ?? '' ) ) : '';
$rcobeca_benefit = $rcobeca_filters ? sanitize_key( wp_unslash( $_GET['beneficiary'] ?? '' ) ) : '';
$rcobeca_page    = $rcobeca_filters ? max( 1, absint( $_GET['pg'] ?? 1 ) ) : 1;
// phpcs:enable
$rcobeca_status  = isset( $rcobeca_statuses[ $rcobeca_status ] ) ? $rcobeca_status : '';
$rcobeca_benefit = isset( $rcobeca_benefits[ $rcobeca_benefit ] ) ? $rcobeca_benefit : '';

$rcobeca_meta = array();
if ( $rcobeca_status ) {
	$rcobeca_meta[] = array(
		'key'   => 'rcobeca_status',
		'value' => $rcobeca_status,
	);
}
if ( $rcobeca_benefit ) {
	$rcobeca_meta[] = array(
		'key'   => 'rcobeca_beneficiary',
		'value' => $rcobeca_benefit,
	);
}
$rcobeca_ids  = get_posts(
	array(
		'post_type'      => RCOBECA_PROJECT,
		'posts_per_page' => -1,
		'fields'         => 'ids',
		'orderby'        => 'date',
		'order'          => 'DESC',
		'meta_query'     => $rcobeca_meta, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- at most a few hundred Projects.
	)
);
$rcobeca_rank = array_flip( array_keys( $rcobeca_statuses ) );
usort( $rcobeca_ids, static fn( $a, $b ) => $rcobeca_rank[ rcobeca_project_status( $a ) ] <=> $rcobeca_rank[ rcobeca_project_status( $b ) ] );
$rcobeca_total = count( $rcobeca_ids );
$rcobeca_per   = 12;
$rcobeca_pages = 1;
if ( $rcobeca_limit > 0 ) {
	$rcobeca_ids = array_slice( $rcobeca_ids, 0, $rcobeca_limit );
} elseif ( $rcobeca_filters ) {
	$rcobeca_pages = max( 1, (int) ceil( $rcobeca_total / $rcobeca_per ) );
	$rcobeca_page  = min( $rcobeca_page, $rcobeca_pages );
	$rcobeca_ids   = array_slice( $rcobeca_ids, ( $rcobeca_page - 1 ) * $rcobeca_per, $rcobeca_per );
}
// A later listing on the same page (the home page's News) won't repeat these.
if ( function_exists( 'rcobeca_shown' ) ) {
	rcobeca_shown( $rcobeca_ids );
}

$rcobeca_base = get_post_type_archive_link( RCOBECA_PROJECT );
$rcobeca_link = static function ( string $status, string $benefit ) use ( $rcobeca_base ): string {
	return add_query_arg( array_filter( array( 'status' => $status, 'beneficiary' => $benefit ) ), $rcobeca_base ); // phpcs:ignore WordPress.Arrays.ArrayDeclarationSpacing.AssociativeArrayFound
};
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'rcobeca-project-list' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> data-wp-interactive="rcobeca/project-list" data-total="<?php echo (int) $rcobeca_total; ?>">
	<?php if ( $rcobeca_filters ) : ?>
		<nav class="rcobeca-filters" aria-label="<?php esc_attr_e( 'Filter Projects', 'rcobeca' ); ?>">
			<div class="rcobeca-filters__group">
				<p class="rcobeca-filters__label" id="rcobeca-filter-status"><?php esc_html_e( 'Status', 'rcobeca' ); ?></p>
				<ul aria-labelledby="rcobeca-filter-status">
					<?php foreach ( array( '' => __( 'All', 'rcobeca' ) ) + $rcobeca_statuses as $rcobeca_value => $rcobeca_label ) : ?>
						<li><a href="<?php echo esc_url( $rcobeca_link( $rcobeca_value, $rcobeca_benefit ) ); ?>"<?php echo $rcobeca_value === $rcobeca_status ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $rcobeca_label ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			</div>
			<div class="rcobeca-filters__group">
				<p class="rcobeca-filters__label" id="rcobeca-filter-beneficiary"><?php esc_html_e( 'For', 'rcobeca' ); ?></p>
				<ul aria-labelledby="rcobeca-filter-beneficiary">
					<?php foreach ( array( '' => __( 'Everyone', 'rcobeca' ) ) + $rcobeca_benefits as $rcobeca_value => $rcobeca_label ) : ?>
						<li><a href="<?php echo esc_url( $rcobeca_link( $rcobeca_status, $rcobeca_value ) ); ?>"<?php echo $rcobeca_value === $rcobeca_benefit ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $rcobeca_label ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			</div>
		</nav>
		<?php /* translators: %d: number of Projects. */ ?>
		<p class="rcobeca-project-list__count"><?php echo esc_html( sprintf( _n( '%d Project', '%d Projects', $rcobeca_total, 'rcobeca' ), $rcobeca_total ) ); ?></p>
	<?php endif; ?>

	<?php if ( ! $rcobeca_ids ) : ?>
		<p class="rcobeca-project-list__empty"><?php esc_html_e( 'No Projects match these filters.', 'rcobeca' ); ?> <a href="<?php echo esc_url( $rcobeca_base ); ?>"><?php esc_html_e( 'Show all Projects', 'rcobeca' ); ?></a></p>
	<?php else : ?>
		<ul class="rcobeca-project-grid">
			<?php foreach ( $rcobeca_ids as $rcobeca_index => $rcobeca_id ) : ?>
				<?php
				$rcobeca_card_status = rcobeca_project_status( $rcobeca_id );
				$rcobeca_progress    = rcobeca_project_progress( $rcobeca_id );
				$rcobeca_money       = rcobeca_project_money_line( $rcobeca_id );
				$rcobeca_where       = array_filter( array( rcobeca_project_year( $rcobeca_id ), (string) get_post_meta( $rcobeca_id, 'rcobeca_place', true ) ) );
				?>
				<li>
					<article class="rcobeca-project-card is-<?php echo esc_attr( $rcobeca_card_status ); ?>">
						<?php if ( has_post_thumbnail( $rcobeca_id ) ) : ?>
							<?php echo get_the_post_thumbnail( $rcobeca_id, 'medium_large', array( 'class' => 'rcobeca-project-card__image', 'loading' => $rcobeca_filters && 1 === $rcobeca_page && $rcobeca_index < 3 ? 'eager' : 'lazy', 'sizes' => '(max-width: 640px) 100vw, 360px' ) ); // phpcs:ignore WordPress.Arrays.ArrayDeclarationSpacing.AssociativeArrayFound ?>
						<?php else : ?>
							<div class="rcobeca-project-card__image rcobeca-project-card__panel" aria-hidden="true">
								<span class="rcobeca-project-card__panel-status"><?php echo esc_html( $rcobeca_statuses[ $rcobeca_card_status ] ); ?></span>
								<span class="rcobeca-project-card__panel-title"><?php echo esc_html( get_the_title( $rcobeca_id ) ); ?></span>
							</div>
						<?php endif; ?>
						<p class="rcobeca-project-card__meta"><span class="rcobeca-status rcobeca-status--<?php echo esc_attr( $rcobeca_card_status ); ?>"><?php echo esc_html( $rcobeca_statuses[ $rcobeca_card_status ] ); ?></span> <span><?php echo esc_html( implode( ' · ', $rcobeca_where ) ); ?></span></p>
						<h3 class="rcobeca-project-card__title"><a href="<?php echo esc_url( get_permalink( $rcobeca_id ) ); ?>"><?php echo esc_html( get_the_title( $rcobeca_id ) ); ?></a></h3>
						<p class="rcobeca-project-card__excerpt"><?php echo esc_html( (string) preg_replace( '/[\s,;:–—-]+…$/u', '…', wp_trim_words( get_the_excerpt( $rcobeca_id ), 20, '…' ) ) ); ?></p>
						<?php if ( $rcobeca_progress ) : ?>
							<?php echo rcobeca_progress_bar( $rcobeca_progress ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?>
						<?php elseif ( '' !== $rcobeca_money ) : ?>
							<p class="rcobeca-project-card__money"><?php echo esc_html( $rcobeca_money ); ?></p>
						<?php endif; ?>
					</article>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php if ( $rcobeca_pages > 1 ) : ?>
			<?php
			$rcobeca_first = ( $rcobeca_page - 1 ) * $rcobeca_per + 1;
			$rcobeca_last  = $rcobeca_first + count( $rcobeca_ids ) - 1;
			$rcobeca_shown = 1 === $rcobeca_page
				/* translators: 1: cards shown, 2: number of Projects. */
				? sprintf( __( 'Showing %1$d of %2$d Projects', 'rcobeca' ), $rcobeca_last, $rcobeca_total )
				/* translators: 1: first card shown, 2: last card shown, 3: number of Projects. */
				: sprintf( __( 'Showing %1$d–%2$d of %3$d Projects', 'rcobeca' ), $rcobeca_first, $rcobeca_last, $rcobeca_total );
			?>
			<div class="rcobeca-project-list__more">
				<p class="rcobeca-project-list__shown" role="status"><?php echo esc_html( $rcobeca_shown ); ?></p>
				<?php if ( $rcobeca_page < $rcobeca_pages ) : ?>
					<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( add_query_arg( 'pg', $rcobeca_page + 1, $rcobeca_link( $rcobeca_status, $rcobeca_benefit ) ) ); ?>" data-wp-on--click="actions.more"><?php esc_html_e( 'Show more Projects', 'rcobeca' ); ?></a></div>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	<?php endif; ?>
</div>
