/**
 * Editor UI for the Project details block. Plain script (no build step): the
 * block is server-rendered, so the editor previews render.php.
 */
( function ( blocks, element, blockEditor, components, ServerSideRender, i18n ) {
	const el = element.createElement;
	const __ = i18n.__;

	blocks.registerBlockType( 'rcobeca/project', {
		edit: function ( props ) {
			return el(
				'div',
				blockEditor.useBlockProps(),
				el(
					blockEditor.InspectorControls,
					null,
					el(
						components.PanelBody,
						{ title: __( 'Show', 'rcobeca' ) },
						el( components.SelectControl, {
							label: __( 'Part of the Project', 'rcobeca' ),
							value: props.attributes.view,
							options: [
								{ value: 'kicker', label: __( 'Status line', 'rcobeca' ) },
								{ value: 'summary', label: __( 'Summary panel', 'rcobeca' ) },
								{ value: 'timeline', label: __( 'Timeline', 'rcobeca' ) },
							],
							onChange: function ( view ) {
								props.setAttributes( { view: view } );
							},
							__nextHasNoMarginBottom: true,
						} )
					)
				),
				el( ServerSideRender, {
					block: 'rcobeca/project',
					attributes: props.attributes,
					urlQueryArgs: { post_id: props.context.postId },
				} )
			);
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.components, window.wp.serverSideRender, window.wp.i18n );
