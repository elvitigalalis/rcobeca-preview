<?php
/**
 * Renders one part of a Project page from its fields:
 * - kicker: status chip, year and place, above the title;
 * - summary: the panel beside the story. Completed shows "$X delivered";
 *   Fundraising shows the progress bar (only with a goal) and the Zeffy form,
 *   or a link to Donate when the Project has no form of its own; Ongoing
 *   says it is under way and links to Donate ("Support our Projects");
 * - timeline: the dated steps, Watsi style.
 *
 * @package RCOBECA
 *
 * @var array    $attributes Block attributes: view.
 * @var WP_Block $block      Block instance, with the post in its context.
 */

defined( 'ABSPATH' ) || exit;

$rcobeca_id = (int) ( $block->context['postId'] ?? get_the_ID() );
if ( ! $rcobeca_id || RCOBECA_PROJECT !== get_post_type( $rcobeca_id ) ) {
	return;
}

$rcobeca_status   = rcobeca_project_status( $rcobeca_id );
$rcobeca_statuses = rcobeca_project_statuses();
$rcobeca_place    = (string) get_post_meta( $rcobeca_id, 'rcobeca_place', true );
$rcobeca_benefit  = (string) get_post_meta( $rcobeca_id, 'rcobeca_beneficiary', true );
$rcobeca_benefits = rcobeca_project_beneficiaries();
$rcobeca_view     = $attributes['view'] ?? 'summary';
$rcobeca_wrapper  = get_block_wrapper_attributes( array( 'class' => "rcobeca-project rcobeca-project--$rcobeca_view is-$rcobeca_status" ) );

if ( 'kicker' === $rcobeca_view ) {
	$rcobeca_bits = array_filter( array( rcobeca_project_year( $rcobeca_id ), $rcobeca_place ) );
	printf(
		'<p %1$s><span class="rcobeca-status rcobeca-status--%2$s">%3$s</span> <span class="rcobeca-project__where">%4$s</span></p>',
		$rcobeca_wrapper, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped by get_block_wrapper_attributes().
		esc_attr( $rcobeca_status ),
		esc_html( $rcobeca_statuses[ $rcobeca_status ] ),
		esc_html( implode( ' · ', $rcobeca_bits ) )
	);
	return;
}

if ( 'timeline' === $rcobeca_view ) {
	$rcobeca_steps = rcobeca_project_timeline( $rcobeca_id );
	if ( 'fundraising' === $rcobeca_status ) {
		$rcobeca_steps[] = array(
			'date'  => __( 'Today', 'rcobeca' ),
			'label' => __( 'Fundraising', 'rcobeca' ),
			'text'  => __( 'Gifts are welcome.', 'rcobeca' ),
		);
	} elseif ( 'ongoing' === $rcobeca_status ) {
		$rcobeca_steps[] = array(
			'date'  => __( 'Today', 'rcobeca' ),
			'label' => __( 'Ongoing', 'rcobeca' ),
			'text'  => __( 'Work is under way. Updates will follow here.', 'rcobeca' ),
		);
	}
	if ( ! $rcobeca_steps ) {
		return;
	}
	$rcobeca_heading = wp_unique_id( 'rcobeca-timeline-' );
	?>
	<section <?php echo $rcobeca_wrapper; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> aria-labelledby="<?php echo esc_attr( $rcobeca_heading ); ?>">
		<h2 id="<?php echo esc_attr( $rcobeca_heading ); ?>" class="rcobeca-timeline__heading"><?php esc_html_e( 'Timeline', 'rcobeca' ); ?></h2>
		<ol class="rcobeca-timeline">
			<?php foreach ( $rcobeca_steps as $rcobeca_step ) : ?>
				<li class="rcobeca-timeline__step">
					<p class="rcobeca-timeline__when"><span class="rcobeca-timeline__date"><?php echo esc_html( rcobeca_project_date_label( $rcobeca_step['date'] ) ); ?></span> · <span class="rcobeca-timeline__label"><?php echo esc_html( $rcobeca_step['label'] ); ?></span></p>
					<?php if ( '' !== $rcobeca_step['text'] ) : ?>
						<p class="rcobeca-timeline__text"><?php echo esc_html( $rcobeca_step['text'] ); ?></p>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ol>
	</section>
	<?php
	return;
}

// Summary panel.
$rcobeca_amount   = rcobeca_project_amount( $rcobeca_id );
$rcobeca_progress = rcobeca_project_progress( $rcobeca_id );
$rcobeca_form     = (string) get_post_meta( $rcobeca_id, 'rcobeca_zeffy_form_url', true );
$rcobeca_date     = (string) get_post_meta( $rcobeca_id, 'rcobeca_date', true );
$rcobeca_listing  = get_post_type_archive_link( RCOBECA_PROJECT );
?>
<div <?php echo $rcobeca_wrapper; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<?php if ( 'completed' === $rcobeca_status && '' !== $rcobeca_amount ) : ?>
		<p class="rcobeca-project__figure"><span class="rcobeca-project__amount"><?php echo esc_html( $rcobeca_amount ); ?></span> <span class="rcobeca-project__figure-label"><?php esc_html_e( 'delivered', 'rcobeca' ); ?></span></p>
	<?php elseif ( 'fundraising' === $rcobeca_status ) : ?>
		<?php if ( $rcobeca_progress ) : ?>
			<?php echo rcobeca_progress_bar( $rcobeca_progress ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?>
		<?php endif; ?>
		<?php if ( rcobeca_zeffy_form( $rcobeca_form ) ) : ?>
			<?php echo render_block( array( 'blockName' => 'rcobeca/zeffy-card', 'attrs' => array( 'formUrl' => $rcobeca_form, 'heading' => __( 'Give to this Project', 'rcobeca' ) ), 'innerBlocks' => array(), 'innerHTML' => '', 'innerContent' => array() ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped, WordPress.Arrays.ArrayDeclarationSpacing.AssociativeArrayFound -- rendered block. ?>
		<?php else : ?>
			<div class="wp-block-buttons rcobeca-project__give">
				<div class="wp-block-button is-style-gold"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/donate/' ) ); ?>"><?php esc_html_e( 'Give to this Project', 'rcobeca' ); ?></a></div>
			</div>
			<p class="rcobeca-project__trust"><?php echo rcobeca_charity_status_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?> <?php esc_html_e( 'Gifts are tax-deductible to the extent allowed by law.', 'rcobeca' ); ?></p>
		<?php endif; ?>
	<?php elseif ( 'ongoing' === $rcobeca_status ) : ?>
		<p class="rcobeca-project__figure"><span class="rcobeca-project__amount"><?php esc_html_e( 'Under way', 'rcobeca' ); ?></span>
		<?php
		if ( '' !== $rcobeca_amount ) :
			?>
			<span class="rcobeca-project__figure-label"><?php echo esc_html( sprintf( /* translators: %s: amount. */ __( '%s so far', 'rcobeca' ), $rcobeca_amount ) ); ?></span><?php endif; ?></p>
		<div class="wp-block-buttons rcobeca-project__give">
			<div class="wp-block-button is-style-gold"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/donate/' ) ); ?>"><?php esc_html_e( 'Support our Projects', 'rcobeca' ); ?></a></div>
		</div>
	<?php endif; ?>

	<dl class="rcobeca-project__facts">
		<div><dt><?php esc_html_e( 'Status', 'rcobeca' ); ?></dt><dd><?php echo esc_html( $rcobeca_statuses[ $rcobeca_status ] ); ?></dd></div>
		<?php if ( '' !== $rcobeca_date ) : ?>
			<div><dt><?php echo esc_html( 'completed' === $rcobeca_status ? __( 'Delivered', 'rcobeca' ) : __( 'Since', 'rcobeca' ) ); ?></dt><dd><?php echo esc_html( rcobeca_project_date_label( $rcobeca_date ) ); ?></dd></div>
		<?php endif; ?>
		<?php if ( '' !== $rcobeca_place ) : ?>
			<div><dt><?php esc_html_e( 'Place', 'rcobeca' ); ?></dt><dd><?php echo esc_html( $rcobeca_place ); ?></dd></div>
		<?php endif; ?>
		<?php if ( isset( $rcobeca_benefits[ $rcobeca_benefit ] ) ) : ?>
			<div><dt><?php esc_html_e( 'For', 'rcobeca' ); ?></dt><dd><a href="<?php echo esc_url( add_query_arg( 'beneficiary', $rcobeca_benefit, $rcobeca_listing ) ); ?>"><?php echo esc_html( $rcobeca_benefits[ $rcobeca_benefit ] ); ?></a></dd></div>
		<?php endif; ?>
	</dl>
	<p class="rcobeca-project__back"><a href="<?php echo esc_url( $rcobeca_listing ); ?>"><?php esc_html_e( 'All Projects', 'rcobeca' ); ?></a></p>
</div>
