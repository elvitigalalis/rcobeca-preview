<?php
/**
 * Renders the site search's results: a count, then one hairline row per
 * result (what it is, linked title, a line of text, a photo), then pages.
 * Reads the main query, which includes/search.php points at pages, Projects,
 * Events and Persons.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

global $wp_query;

if ( ! is_search() ) {
	return;
}
$rcobeca_total = (int) $wp_query->found_posts;
$rcobeca_links = array(
	__( 'Projects', 'rcobeca' )           => '/projects/',
	__( 'Events', 'rcobeca' )             => '/events/',
	__( 'Committee History', 'rcobeca' )  => '/committee/history/',
	__( 'Royal Charity Ball', 'rcobeca' ) => '/ball/',
	__( 'News', 'rcobeca' )               => '/news/',
);
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'rcobeca-search-results' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<?php if ( ! $rcobeca_total ) : ?>
		<p class="rcobeca-search-results__none"><?php esc_html_e( 'Nothing matched. Try fewer or other words, or look in one of these:', 'rcobeca' ); ?></p>
		<ul class="rcobeca-search-results__suggest">
			<?php foreach ( $rcobeca_links as $rcobeca_label => $rcobeca_path ) : ?>
				<li><a href="<?php echo esc_url( home_url( $rcobeca_path ) ); ?>"><?php echo esc_html( $rcobeca_label ); ?></a></li>
			<?php endforeach; ?>
		</ul>
	<?php else : ?>
		<p class="rcobeca-search-results__count">
			<?php
			/* translators: %s: number of results. */
			echo esc_html( sprintf( _n( '%s result', '%s results', $rcobeca_total, 'rcobeca' ), number_format_i18n( $rcobeca_total ) ) );
			?>
		</p>
		<?php foreach ( $wp_query->posts as $rcobeca_post ) : ?>
			<?php $rcobeca_result = rcobeca_search_result( (int) $rcobeca_post->ID ); ?>
			<article class="rcobeca-search-results__item<?php echo $rcobeca_result['image'] ? ' has-image' : ''; ?>">
				<div class="rcobeca-search-results__text">
					<p class="rcobeca-search-results__meta">
						<span class="rcobeca-search-results__kind"><?php echo esc_html( $rcobeca_result['kind'] ); ?></span>
						<?php if ( '' !== $rcobeca_result['meta'] ) : ?>
							<span><?php echo esc_html( $rcobeca_result['meta'] ); ?></span>
						<?php endif; ?>
					</p>
					<h2 class="rcobeca-search-results__title">
						<?php if ( '' !== $rcobeca_result['url'] ) : ?>
							<a href="<?php echo esc_url( $rcobeca_result['url'] ); ?>"><?php echo esc_html( $rcobeca_result['title'] ); ?></a>
						<?php else : ?>
							<?php echo esc_html( $rcobeca_result['title'] ); ?>
						<?php endif; ?>
					</h2>
					<?php if ( '' !== $rcobeca_result['text'] ) : ?>
						<p class="rcobeca-search-results__excerpt"><?php echo esc_html( $rcobeca_result['text'] ); ?></p>
					<?php endif; ?>
				</div>
				<?php if ( $rcobeca_result['image'] ) : ?>
					<?php
					echo wp_get_attachment_image(
						$rcobeca_result['image'],
						'medium',
						false,
						array(
							'class'   => 'rcobeca-search-results__image',
							'alt'     => '',
							'loading' => 'lazy',
						)
					);
					?>
				<?php endif; ?>
			</article>
		<?php endforeach; ?>
		<?php
		$rcobeca_pages = paginate_links(
			array(
				'total'     => (int) $wp_query->max_num_pages,
				'current'   => max( 1, (int) get_query_var( 'paged' ) ),
				'prev_text' => __( 'Previous', 'rcobeca' ),
				'next_text' => __( 'Next', 'rcobeca' ),
			)
		);
		if ( $rcobeca_pages ) {
			echo '<nav class="rcobeca-search-results__pages" aria-label="' . esc_attr__( 'More results', 'rcobeca' ) . '">' . wp_kses_post( $rcobeca_pages ) . '</nav>';
		}
		?>
	<?php endif; ?>
</div>
