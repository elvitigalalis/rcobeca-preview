<?php
/**
 * Renders "People in this story" (PD Soros's "Featured Fellows"): the Persons
 * a story names, each with his role in the story's Club Year, linked to his
 * profile or that Club Year in the Committee history.
 *
 * @package RCOBECA
 *
 * @var WP_Block $block Block instance (context: postId).
 */

defined( 'ABSPATH' ) || exit;

$rcobeca_story  = (int) ( $block->context['postId'] ?? get_the_ID() );
$rcobeca_people = $rcobeca_story ? rcobeca_story_people( $rcobeca_story ) : array();
if ( ! $rcobeca_people ) {
	return;
}
$rcobeca_year = (int) substr( rcobeca_story_date( $rcobeca_story ), 0, 4 );
$rcobeca_year = $rcobeca_year > 0 ? $rcobeca_year : null;
?>
<section <?php echo get_block_wrapper_attributes( array( 'class' => 'rcobeca-story-people' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> aria-labelledby="rcobeca-story-people-heading">
	<h2 class="rcobeca-story-people__heading" id="rcobeca-story-people-heading"><?php esc_html_e( 'People in this story', 'rcobeca' ); ?></h2>
	<ul class="rcobeca-story-people__list">
		<?php foreach ( $rcobeca_people as $rcobeca_person ) : ?>
			<?php
			$rcobeca_url  = rcobeca_person_url( $rcobeca_person, $rcobeca_year );
			$rcobeca_term = rcobeca_person_term_at( $rcobeca_person, $rcobeca_year );
			$rcobeca_name = rcobeca_person_name( $rcobeca_person );
			?>
			<li class="rcobeca-story-people__person">
				<?php if ( '' !== $rcobeca_url ) : ?>
					<a class="rcobeca-story-people__name" href="<?php echo esc_url( $rcobeca_url ); ?>"><?php echo esc_html( $rcobeca_name ); ?></a>
				<?php else : ?>
					<span class="rcobeca-story-people__name"><?php echo esc_html( $rcobeca_name ); ?></span>
				<?php endif; ?>
				<?php if ( $rcobeca_term ) : ?>
					<span class="rcobeca-story-people__role"><?php echo esc_html( $rcobeca_term['role'] . ', ' . rcobeca_club_year_label( $rcobeca_term['year'] ) ); ?></span>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ul>
</section>
