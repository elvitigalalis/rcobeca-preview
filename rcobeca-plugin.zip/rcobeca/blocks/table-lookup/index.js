/**
 * Editor UI for Table Lookup. Plain script (no build step): the
 * block shows the current Ball's lookup (or the Ball in its eventId), and its
 * seating list is uploaded under Events → Seating lists, so the editor just
 * previews render.php.
 */
( function ( blocks, element, blockEditor, components, ServerSideRender ) {
	const el = element.createElement;

	blocks.registerBlockType( 'rcobeca/table-lookup', {
		edit: function ( props ) {
			return el(
				'div',
				blockEditor.useBlockProps(),
				el( components.Disabled, null, el( ServerSideRender, { block: 'rcobeca/table-lookup', attributes: props.attributes } ) )
			);
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.components, window.wp.serverSideRender );
