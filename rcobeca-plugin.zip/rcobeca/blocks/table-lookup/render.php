<?php
/**
 * Renders Table Lookup (Wedibox "Find your seat", Where Do I Vote's single
 * card): one labelled field, one button, one big answer. view.js asks the
 * endpoint and shows the answer in place; without JavaScript the form posts
 * to this page and the answer is rendered here.
 *
 * Only the table number a guest's own exact full name finds is ever printed;
 * nothing about the seating list is in the page. With "demo" (the style guide)
 * it always answers, from the made-up names in data/seating-demo.csv.
 *
 * @package RCOBECA
 *
 * @var array $attributes Block attributes.
 */

use RCOBECA\Events;
use RCOBECA\Seating;
use RCOBECA\Table_Lookup;

defined( 'ABSPATH' ) || exit;

$rcobeca_ball = (int) ( $attributes['eventId'] ?? 0 );
$rcobeca_ball = $rcobeca_ball ? $rcobeca_ball : Events::current_ball();
$rcobeca_demo = ! empty( $attributes['demo'] );
$rcobeca_open = $rcobeca_demo || ( $rcobeca_ball && Seating::is_open( $rcobeca_ball ) );

// The no-JavaScript answer: a lookup posted to this page. Read-only and
// public, so there is nothing for a nonce to protect.
// phpcs:disable WordPress.Security.NonceVerification.Missing
$rcobeca_name   = isset( $_POST['rcobeca_table_lookup'] ) ? sanitize_text_field( wp_unslash( $_POST['rcobeca_table_lookup'] ) ) : null;
$rcobeca_answer = $rcobeca_open && null !== $rcobeca_name ? Table_Lookup::answer( $rcobeca_ball, $rcobeca_name, Table_Lookup::client(), $rcobeca_demo ) : null;
// phpcs:enable WordPress.Security.NonceVerification.Missing

$rcobeca_wrapper = get_block_wrapper_attributes(
	array(
		'class' => 'rcobeca-table-lookup',
		'id'    => 'rcobeca-table-lookup',
	)
);

// The answer shown in the status region: the no-JavaScript answer, rendered
// here through the same directives view.js updates (Interactivity API).
$rcobeca_found   = isset( $rcobeca_answer['table'] );
$rcobeca_context = array(
	'endpoint' => rest_url( 'rcobeca/v1/table-lookup' ),
	'ball'     => $rcobeca_ball,
	'demo'     => $rcobeca_demo,
	'busy'     => false,
	'answered' => null !== $rcobeca_answer,
	'found'    => $rcobeca_found,
	'kicker'   => $rcobeca_found ? __( 'Your table', 'rcobeca' ) : '',
	'table'    => $rcobeca_found ? (string) $rcobeca_answer['table'] : '',
	'message'  => $rcobeca_answer['message'] ?? '',
	'labels'   => array(
		'kicker' => __( 'Your table', 'rcobeca' ),
		'failed' => __( 'We couldn’t reach the seating list just now. Please try again in a moment, or see the welcome desk.', 'rcobeca' ),
	),
);
?>
<div <?php echo $rcobeca_wrapper; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core escapes it. ?> data-wp-interactive="rcobeca/table-lookup" <?php echo wp_interactivity_data_wp_context( $rcobeca_context ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped by the helper. ?>>
	<?php if ( ! $rcobeca_open ) : ?>
		<p class="rcobeca-table-lookup__closed">
			<?php
			echo $rcobeca_ball && 'ball-night' === Events::get( $rcobeca_ball, 'ball_state' )
				? esc_html__( 'The seating list isn’t ready yet. Please see the welcome desk, who will show you to your table.', 'rcobeca' )
				: esc_html__( 'Table Lookup opens here on Ball night. Until then, the welcome desk will show you to your table.', 'rcobeca' );
			?>
		</p>
	<?php else : ?>
		<form class="rcobeca-table-lookup__form" method="post" action="#rcobeca-table-lookup" data-wp-on--submit="actions.lookup">
			<?php if ( $rcobeca_demo ) : ?>
				<p class="rcobeca-table-lookup__demo"><?php esc_html_e( 'Demo with made-up guests: try “Ann Example” or “Zoe Demo-Guest”.', 'rcobeca' ); ?></p>
			<?php endif; ?>
			<label class="rcobeca-table-lookup__label" for="rcobeca-table-lookup-name"><?php esc_html_e( 'Your full name', 'rcobeca' ); ?></label>
			<p class="rcobeca-table-lookup__hint" id="rcobeca-table-lookup-hint"><?php esc_html_e( 'First and last name, as on your ticket.', 'rcobeca' ); ?></p>
			<div class="rcobeca-table-lookup__row">
				<input class="rcobeca-table-lookup__input" type="text" id="rcobeca-table-lookup-name" name="rcobeca_table_lookup" value="<?php echo esc_attr( (string) $rcobeca_name ); ?>" autocomplete="name" autocapitalize="words" spellcheck="false" enterkeyhint="search" maxlength="200" required aria-describedby="rcobeca-table-lookup-hint">
				<button class="rcobeca-table-lookup__button wp-element-button" type="submit" data-wp-bind--disabled="context.busy"><?php esc_html_e( 'Find my table', 'rcobeca' ); ?></button>
			</div>
		</form>
		<div class="rcobeca-table-lookup__result" role="status" data-wp-class--has-answer="context.answered" data-wp-class--is-found="context.found" data-wp-bind--aria-busy="context.busy">
			<p class="rcobeca-table-lookup__kicker" data-wp-bind--hidden="!context.found" data-wp-text="context.kicker"></p>
			<p class="rcobeca-table-lookup__table" data-wp-bind--hidden="!context.found" data-wp-text="context.table"></p>
			<p class="rcobeca-table-lookup__message" data-wp-bind--hidden="!context.answered" data-wp-text="context.message"></p>
		</div>
	<?php endif; ?>
</div>
