<?php
/**
 * Module dependencies for Table Lookup's front end (written by hand; there is no build step).
 *
 * @package RCOBECA
 */

return array(
	'dependencies' => array( '@wordpress/interactivity' ),
	'version'      => '0.1.0',
);
