/**
 * Table Lookup in place (Interactivity API): asks the endpoint and shows the
 * answer in the status region (announced by screen readers), without
 * reloading the page. Without JavaScript the form posts to the page instead,
 * and render.php shows the same answer through the same directives.
 *
 * A failed request says so and is never sent again by submitting the form:
 * it may already have reached the server and counted against the limits.
 */
import { store, getContext, withSyncEvent } from '@wordpress/interactivity';

const show = ( context, answer ) => {
	context.answered = true;
	context.found = Boolean( answer.table );
	context.kicker = context.found ? context.labels.kicker : '';
	context.table = context.found ? String( answer.table ) : '';
	context.message = answer.message || context.labels.failed;
};

store( 'rcobeca/table-lookup', {
	actions: {
		lookup: withSyncEvent( function* ( event ) {
			event.preventDefault();
			const context = getContext();
			if ( context.busy ) {
				return;
			}
			context.busy = true;
			try {
				const response = yield fetch( context.endpoint, {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					credentials: 'omit',
					body: JSON.stringify( {
						ball: Number( context.ball ),
						name: event.target.elements.rcobeca_table_lookup.value,
						demo: Boolean( context.demo ),
					} ),
				} );
				show( context, yield response.json() );
			} catch ( error ) {
				show( context, {} );
			} finally {
				context.busy = false;
			}
		} ),
	},
} );
