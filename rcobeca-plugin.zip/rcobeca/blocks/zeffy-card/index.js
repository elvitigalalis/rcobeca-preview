/**
 * Editor UI for the Zeffy card. Plain script (no build step): the block is
 * server-rendered, so the editor previews render.php through ServerSideRender.
 */
( function ( blocks, element, blockEditor, components, ServerSideRender, i18n ) {
	const el = element.createElement;
	const __ = i18n.__;

	function urlControl( props ) {
		return el( components.TextControl, {
			label: __( 'Zeffy form link', 'rcobeca' ),
			help: __( 'In Zeffy: the campaign’s Share link, e.g. https://www.zeffy.com/en-US/donation-form/…', 'rcobeca' ),
			type: 'url',
			value: props.attributes.formUrl,
			onChange: function ( formUrl ) {
				props.setAttributes( { formUrl: formUrl } );
			},
			__nextHasNoMarginBottom: true,
		} );
	}

	blocks.registerBlockType( 'rcobeca/zeffy-card', {
		edit: function ( props ) {
			const blockProps = blockEditor.useBlockProps();
			const inspector = el(
				blockEditor.InspectorControls,
				null,
				el(
					components.PanelBody,
					{ title: __( 'Zeffy form', 'rcobeca' ) },
					urlControl( props ),
					el( components.TextControl, {
						label: __( 'Heading', 'rcobeca' ),
						help: __( 'Leave empty for the default, e.g. “Make a gift”.', 'rcobeca' ),
						value: props.attributes.heading,
						onChange: function ( heading ) {
							props.setAttributes( { heading: heading } );
						},
						__nextHasNoMarginBottom: true,
					} ),
					el( components.TextControl, {
						label: __( 'Height in pixels (optional)', 'rcobeca' ),
						help: __( 'Zeffy forms cannot size themselves. Raise this if the form is cut off.', 'rcobeca' ),
						type: 'number',
						value: props.attributes.height || '',
						onChange: function ( height ) {
							props.setAttributes( { height: height ? parseInt( height, 10 ) : undefined } );
						},
						__nextHasNoMarginBottom: true,
					} )
				)
			);

			// formSetting cards take their link from Settings → Join and newsletter.
			if ( ! props.attributes.formUrl && ! props.attributes.formSetting ) {
				return el(
					'div',
					blockProps,
					inspector,
					el(
						components.Placeholder,
						{
							icon: 'money-alt',
							label: __( 'Zeffy card', 'rcobeca' ),
							instructions: __( 'Paste the link to a Zeffy donation, membership or ticket form.', 'rcobeca' ),
						},
						urlControl( props )
					)
				);
			}

			return el(
				'div',
				blockProps,
				inspector,
				el( ServerSideRender, { block: 'rcobeca/zeffy-card', attributes: props.attributes } )
			);
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.components, window.wp.serverSideRender, window.wp.i18n );
