<?php
/**
 * Renders the Zeffy card: the form embedded inline in our own card, with the
 * RCOBEC Foundation trust copy outside the iframe. Given the organisation's
 * Zeffy page instead of a form (no form exists yet), it keeps the card and
 * trust copy and links out to that page. Renders nothing for other links.
 *
 * @package RCOBECA
 *
 * @var array $attributes Block attributes: formUrl, formSetting, heading, height.
 *
 * With formSetting (e.g. "membership" or "donation"), the link set under
 * Settings → Join and newsletter wins over formUrl. Until it is set, the card
 * links out when formUrl is the organisation's Zeffy page, and otherwise
 * offers the offline ways to pay (Zelle or cheque, through the Treasurer);
 * only people who can change settings also see where to set the link.
 */

defined( 'ABSPATH' ) || exit;

$rcobeca_setting = (string) ( $attributes['formSetting'] ?? '' );
$rcobeca_url     = (string) ( $attributes['formUrl'] ?? '' );
if ( '' !== $rcobeca_setting && '' !== rcobeca_zeffy_setting( $rcobeca_setting ) ) {
	$rcobeca_url = rcobeca_zeffy_setting( $rcobeca_setting );
}
$rcobeca_form = rcobeca_zeffy_form( $rcobeca_url );
if ( null === $rcobeca_form && rcobeca_zeffy_organization( $rcobeca_url ) ) {
	$rcobeca_form = array(
		'type'         => 'donation-form',
		'embed'        => '',
		'organization' => true,
	);
} elseif ( null === $rcobeca_form && '' !== $rcobeca_setting ) {
	$rcobeca_form = array(
		'type'  => $rcobeca_setting,
		'embed' => '',
	);
}
if ( null === $rcobeca_form ) {
	return;
}

$rcobeca_types   = rcobeca_zeffy_form_types();
$rcobeca_type    = $rcobeca_types[ $rcobeca_form['type'] ] ?? $rcobeca_types['donation-form'];
$rcobeca_heading = '' !== trim( (string) ( $attributes['heading'] ?? '' ) ) ? $attributes['heading'] : $rcobeca_type['heading'];
$rcobeca_height  = ! empty( $attributes['height'] ) ? (int) $attributes['height'] : $rcobeca_type['height'];
$rcobeca_id      = wp_unique_id( 'rcobeca-zeffy-' );
// No form link yet (and not the organisation's page): the offline ways to pay.
$rcobeca_offline = empty( $rcobeca_form['organization'] ) && '' === $rcobeca_form['embed'];

$rcobeca_deductible = array(
	'ticketing'  => __( 'Your receipt shows the tax-deductible part of each ticket.', 'rcobeca' ),
	'membership' => __( 'Your dues fund RCOBECA’s work for Royal College.', 'rcobeca' ),
);

$rcobeca_wrapper = get_block_wrapper_attributes(
	array(
		'class'           => 'rcobeca-zeffy-card rcobeca-zeffy-card--' . $rcobeca_form['type'],
		'aria-labelledby' => $rcobeca_id,
		'style'           => '--rcobeca-zeffy-height:' . $rcobeca_height . 'px',
	)
);
?>
<section <?php echo $rcobeca_wrapper; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped by get_block_wrapper_attributes(). ?>>
	<div class="rcobeca-zeffy-card__head">
		<p class="rcobeca-zeffy-card__kicker"><?php echo esc_html( $rcobeca_offline ? __( 'Ways to pay', 'rcobeca' ) : __( 'Secure payment by Zeffy', 'rcobeca' ) ); ?></p>
		<h2 class="rcobeca-zeffy-card__heading" id="<?php echo esc_attr( $rcobeca_id ); ?>"><?php echo esc_html( $rcobeca_heading ); ?></h2>
	</div>
	<?php if ( ! empty( $rcobeca_form['organization'] ) ) : ?>
		<div class="rcobeca-zeffy-card__link">
			<p><?php esc_html_e( 'Give once or monthly, by card or bank transfer, on RCOBEC Foundation’s secure page at Zeffy.', 'rcobeca' ); ?></p>
			<div class="wp-block-buttons">
				<div class="wp-block-button is-style-gold"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( $rcobeca_url ); ?>"><?php esc_html_e( 'Give securely with Zeffy', 'rcobeca' ); ?></a></div>
			</div>
		</div>
	<?php elseif ( $rcobeca_offline ) : ?>
		<div class="rcobeca-zeffy-card__link rcobeca-zeffy-card__offline">
			<?php if ( current_user_can( 'manage_options' ) ) : ?>
				<p class="rcobeca-zeffy-card__setup"><strong><?php esc_html_e( 'Only administrators see this.', 'rcobeca' ); ?></strong> <?php /* translators: %s: kind of form, e.g. "membership form". */ echo esc_html( sprintf( __( 'Set the Zeffy %s’s link under Settings → Join and newsletter, and the form replaces these offline options.', 'rcobeca' ), $rcobeca_type['noun'] ) ); ?></p>
			<?php endif; ?>
			<p><?php esc_html_e( 'Pay through the RCOBEC Foundation Treasurer:', 'rcobeca' ); ?></p>
			<ul class="rcobeca-zeffy-card__ways">
				<li><strong><?php esc_html_e( 'Zelle', 'rcobeca' ); ?></strong> <?php esc_html_e( 'to treasurer@rcobeca.org.', 'rcobeca' ); ?></li>
				<li><strong><?php esc_html_e( 'Cheque', 'rcobeca' ); ?></strong> <?php esc_html_e( 'payable to RCOBEC Foundation Inc.: email the Treasurer for the address to post it to.', 'rcobeca' ); ?></li>
			</ul>
			<div class="wp-block-buttons">
				<div class="wp-block-button is-style-gold"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( 'mailto:treasurer@rcobeca.org?subject=' . rawurlencode( $rcobeca_heading ) ); ?>"><?php esc_html_e( 'Email the Treasurer', 'rcobeca' ); ?></a></div>
			</div>
		</div>
	<?php else : ?>
		<div class="rcobeca-zeffy-card__frame">
			<iframe
				src="<?php echo esc_url( $rcobeca_form['embed'] ); ?>"
				title="<?php /* translators: %s: kind of form, e.g. "donation form". */ echo esc_attr( sprintf( __( 'RCOBECA %s, powered by Zeffy', 'rcobeca' ), $rcobeca_type['noun'] ) ); ?>"
				allow="payment"
				allowpaymentrequest
				loading="lazy"
			></iframe>
		</div>
	<?php endif; ?>
	<div class="rcobeca-zeffy-card__trust">
		<p><?php echo rcobeca_charity_status_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?></p>
		<ul>
			<li><?php echo esc_html( $rcobeca_deductible[ $rcobeca_form['type'] ] ?? __( 'Gifts are tax-deductible to the extent allowed by law.', 'rcobeca' ) ); ?></li>
			<?php if ( ! $rcobeca_offline ) : ?>
				<li><?php esc_html_e( 'Zeffy emails your receipt as soon as you pay.', 'rcobeca' ); ?></li>
				<li><?php esc_html_e( 'Zeffy charges RCOBECA no fees; the tip it suggests to support Zeffy is optional.', 'rcobeca' ); ?></li>
			<?php endif; ?>
		</ul>
		<p class="rcobeca-zeffy-card__help">
			<?php esc_html_e( 'Questions, or prefer to pay by cheque or Zelle?', 'rcobeca' ); ?>
			<a href="mailto:treasurer@rcobeca.org">treasurer@rcobeca.org</a>
		</p>
	</div>
</section>
