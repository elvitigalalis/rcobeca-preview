<?php
/**
 * Alt text for every image (spec #1, story 74).
 *
 * - The block editor will not save a post while an image in it (Image,
 *   Media & Text or Cover block, or the featured image) has no alt
 *   text (`assets/alt-text-required.js`): it says how many and where to fix
 *   them.
 * - Media → Alt text to review lists the images whose alt text the importer
 *   wrote from context (`_rcobeca_alt_needs_review`). Editing an image's alt
 *   text takes it off the list; "Alt text is right" does too.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

const RCOBECA_ALT_REVIEW = '_rcobeca_alt_needs_review';

/**
 * Loads the alt-text check into the post editor.
 */
function rcobeca_alt_text_editor_script(): void {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || 'post' !== $screen->base ) {
		return;
	}
	wp_enqueue_script(
		'rcobeca-alt-text-required',
		plugins_url( 'assets/alt-text-required.js', RCOBECA_DIR . '/rcobeca.php' ),
		array( 'wp-data', 'wp-core-data', 'wp-editor', 'wp-notices', 'wp-block-editor' ),
		RCOBECA_VERSION,
		true
	);
}
add_action( 'enqueue_block_editor_assets', 'rcobeca_alt_text_editor_script' );

/**
 * The review flag in the REST API, so editors' tools (and tests) can read
 * and set it.
 */
function rcobeca_register_alt_review_meta(): void {
	register_post_meta(
		'attachment',
		RCOBECA_ALT_REVIEW,
		array(
			'type'          => 'boolean',
			'single'        => true,
			'show_in_rest'  => array( 'name' => 'rcobeca_alt_needs_review' ),
			'auth_callback' => static fn( $allowed, $key, $id ) => current_user_can( 'edit_post', $id ),
		)
	);
}
add_action( 'init', 'rcobeca_register_alt_review_meta' );

/**
 * A person editing an image's alt text has reviewed it. (The importer
 * refreshing its own generated text has not.)
 *
 * @param int    $meta_id Meta ID.
 * @param int    $id      Attachment ID.
 * @param string $key     Meta key.
 * @param mixed  $value   New value.
 */
function rcobeca_alt_reviewed( $meta_id, $id, $key, $value ): void {
	if ( '_wp_attachment_image_alt' === $key && trim( (string) $value ) !== (string) get_post_meta( $id, '_rcobeca_generated_alt', true ) ) {
		delete_post_meta( $id, RCOBECA_ALT_REVIEW );
	}
}
add_action( 'updated_post_meta', 'rcobeca_alt_reviewed', 10, 4 );
add_action( 'added_post_meta', 'rcobeca_alt_reviewed', 10, 4 );

/**
 * How many images wait for review.
 */
function rcobeca_alt_review_count(): int {
	return count(
		get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_key'       => RCOBECA_ALT_REVIEW, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			)
		)
	);
}

/**
 * Media → Alt text to review: the Media Library's list, filtered.
 */
function rcobeca_alt_review_menu(): void {
	$count = rcobeca_alt_review_count();
	/* translators: %s: number of images. */
	$label = sprintf( __( 'Alt text to review %s', 'rcobeca' ), $count ? '<span class="awaiting-mod">' . number_format_i18n( $count ) . '</span>' : '' );
	add_submenu_page( 'upload.php', __( 'Alt text to review', 'rcobeca' ), $label, 'upload_files', 'upload.php?mode=list&rcobeca_alt_review=1' );
}
add_action( 'admin_menu', 'rcobeca_alt_review_menu' );

/**
 * Filters the Media Library list to the images awaiting review.
 *
 * @param WP_Query $query Query.
 */
function rcobeca_alt_review_filter( WP_Query $query ): void {
	if ( ! is_admin() || ! $query->is_main_query() || empty( $_GET['rcobeca_alt_review'] ) || 'attachment' !== $query->get( 'post_type' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}
	$query->set( 'meta_key', RCOBECA_ALT_REVIEW );
	$query->set( 'meta_value', '1' );
}
add_action( 'pre_get_posts', 'rcobeca_alt_review_filter' );

/**
 * Explains the filtered list above it.
 */
function rcobeca_alt_review_notice(): void {
	$screen = get_current_screen();
	if ( ! $screen || 'upload' !== $screen->id || empty( $_GET['rcobeca_alt_review'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}
	echo '<div class="notice notice-info"><p>' . esc_html__( 'Alt text to review: the importer wrote these images’ alt text from the page around them. Open each, check that “Alternative Text” describes the photo (who, what, where), and update it; or choose “Alt text is right”. Either takes it off this list.', 'rcobeca' ) . '</p></div>';
}
add_action( 'admin_notices', 'rcobeca_alt_review_notice' );

/**
 * Shows each image's alt text in the list, and the "Alt text is right" action.
 *
 * @param array $columns Columns.
 */
function rcobeca_alt_column( array $columns ): array {
	$columns['rcobeca_alt'] = __( 'Alt text', 'rcobeca' );
	return $columns;
}
add_filter( 'manage_media_columns', 'rcobeca_alt_column' );

/**
 * Prints the alt text cell.
 *
 * @param string $column Column.
 * @param int    $id     Attachment ID.
 */
function rcobeca_alt_column_value( string $column, int $id ): void {
	if ( 'rcobeca_alt' !== $column ) {
		return;
	}
	echo esc_html( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) );
	if ( get_post_meta( $id, RCOBECA_ALT_REVIEW, true ) ) {
		echo ' <em>' . esc_html__( '(to review)', 'rcobeca' ) . '</em>';
	}
}
add_action( 'manage_media_custom_column', 'rcobeca_alt_column_value', 10, 2 );

/**
 * The "Alt text is right" row action.
 *
 * @param array   $actions Row actions.
 * @param WP_Post $post    Attachment.
 */
function rcobeca_alt_row_action( array $actions, WP_Post $post ): array {
	if ( get_post_meta( $post->ID, RCOBECA_ALT_REVIEW, true ) && current_user_can( 'edit_post', $post->ID ) ) {
		$url                          = wp_nonce_url( admin_url( 'admin-post.php?action=rcobeca_alt_ok&attachment=' . $post->ID ), 'rcobeca_alt_ok_' . $post->ID );
		$actions['rcobeca_alt_right'] = '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Alt text is right', 'rcobeca' ) . '</a>';
	}
	return $actions;
}
add_filter( 'media_row_actions', 'rcobeca_alt_row_action', 10, 2 );

/**
 * Takes an image off the review list.
 */
function rcobeca_alt_ok(): void {
	$id = absint( $_GET['attachment'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- checked below.
	check_admin_referer( 'rcobeca_alt_ok_' . $id );
	if ( ! current_user_can( 'edit_post', $id ) ) {
		wp_die( esc_html__( 'Sorry, you are not allowed to edit this image.', 'rcobeca' ), 403 );
	}
	delete_post_meta( $id, RCOBECA_ALT_REVIEW );
	wp_safe_redirect( admin_url( 'upload.php?mode=list&rcobeca_alt_review=1' ) );
	exit;
}
add_action( 'admin_post_rcobeca_alt_ok', 'rcobeca_alt_ok' );
