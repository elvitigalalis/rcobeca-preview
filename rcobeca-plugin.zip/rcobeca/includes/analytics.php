<?php
/**
 * Settings → Analytics: privacy-friendly visitor counts from Cloudflare Web
 * Analytics or Umami Cloud's free tier. Neither sets cookies, so there is no
 * banner. Off until an administrator picks a service and pastes its ID; the
 * script then loads deferred on every page, except for logged-in editors,
 * whose own visits are not counted.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

/**
 * The services, by key: label, script URL, the attribute that carries the ID,
 * and where to find the ID.
 *
 * @return array<string, array{label: string, src: string, help: string}>
 */
function rcobeca_analytics_services(): array {
	return array(
		'cloudflare' => array(
			'label' => __( 'Cloudflare Web Analytics', 'rcobeca' ),
			'src'   => 'https://static.cloudflareinsights.com/beacon.min.js',
			'help'  => __( 'Cloudflare dashboard → Analytics & Logs → Web Analytics → Add a site (rcobeca.org) → copy the token from the JS snippet. Free; no DNS change needed.', 'rcobeca' ),
		),
		'umami'      => array(
			'label' => __( 'Umami', 'rcobeca' ),
			'src'   => 'https://cloud.umami.is/script.js',
			'help'  => __( 'Umami Cloud (free Hobby plan) → Settings → Websites → Add website → copy its Website ID.', 'rcobeca' ),
		),
	);
}

/**
 * The saved choice: service key ('' when off) and its ID.
 *
 * @return array{service: string, id: string}
 */
function rcobeca_analytics(): array {
	$saved = (array) get_option( 'rcobeca_analytics', array() );
	return array(
		'service' => isset( rcobeca_analytics_services()[ $saved['service'] ?? '' ] ) ? $saved['service'] : '',
		'id'      => (string) ( $saved['id'] ?? '' ),
	);
}

/**
 * Keeps a known service and an ID of letters, digits and dashes; anything
 * else is refused and the previous choice kept.
 *
 * @param mixed $value Submitted value.
 * @return array{service: string, id: string}
 */
function rcobeca_sanitize_analytics( $value ): array {
	$value   = (array) $value;
	$service = sanitize_key( (string) ( $value['service'] ?? '' ) );
	$id      = trim( (string) ( $value['id'] ?? '' ) );
	if ( '' === $service || ! isset( rcobeca_analytics_services()[ $service ] ) ) {
		return array(
			'service' => '',
			'id'      => '',
		);
	}
	if ( ! preg_match( '/^[A-Za-z0-9-]{8,64}$/', $id ) ) {
		add_settings_error( 'rcobeca_analytics', 'rcobeca_analytics', __( 'The site token or website ID should be 8 to 64 letters, numbers and dashes. Analytics were left as they were.', 'rcobeca' ) );
		return rcobeca_analytics();
	}
	return array(
		'service' => $service,
		'id'      => $id,
	);
}

/**
 * Registers the setting.
 */
function rcobeca_register_analytics_setting(): void {
	register_setting(
		'rcobeca_analytics',
		'rcobeca_analytics',
		array(
			'type'              => 'object',
			'default'           => array(),
			'sanitize_callback' => 'rcobeca_sanitize_analytics',
		)
	);
}
add_action( 'admin_init', 'rcobeca_register_analytics_setting' );

/**
 * Adds Settings → Analytics (administrators only).
 */
function rcobeca_analytics_menu(): void {
	add_options_page( __( 'Analytics', 'rcobeca' ), __( 'Analytics', 'rcobeca' ), 'manage_options', 'rcobeca-analytics', 'rcobeca_analytics_page' );
}
add_action( 'admin_menu', 'rcobeca_analytics_menu' );

/**
 * The settings screen.
 */
function rcobeca_analytics_page(): void {
	$saved = rcobeca_analytics();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Analytics', 'rcobeca' ); ?></h1>
		<p><?php esc_html_e( 'Count visitors without cookies or a consent banner. Pick one free service, paste its ID and save; the site starts counting at once. Visits by logged-in editors are not counted.', 'rcobeca' ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'rcobeca_analytics' ); ?>
			<fieldset>
				<legend class="screen-reader-text"><?php esc_html_e( 'Service', 'rcobeca' ); ?></legend>
				<p><label><input type="radio" name="rcobeca_analytics[service]" value="" <?php checked( $saved['service'], '' ); ?> /> <?php esc_html_e( 'Off', 'rcobeca' ); ?></label></p>
				<?php foreach ( rcobeca_analytics_services() as $key => $service ) : ?>
					<p>
						<label><input type="radio" name="rcobeca_analytics[service]" value="<?php echo esc_attr( $key ); ?>" <?php checked( $saved['service'], $key ); ?> /> <?php echo esc_html( $service['label'] ); ?></label>
						<br /><span class="description"><?php echo esc_html( $service['help'] ); ?></span>
					</p>
				<?php endforeach; ?>
			</fieldset>
			<p>
				<label for="rcobeca-analytics-id"><?php esc_html_e( 'Site token or website ID', 'rcobeca' ); ?></label><br />
				<input type="text" class="regular-text code" id="rcobeca-analytics-id" name="rcobeca_analytics[id]" value="<?php echo esc_attr( $saved['id'] ); ?>" autocomplete="off" />
			</p>
			<?php submit_button( __( 'Save', 'rcobeca' ) ); ?>
		</form>
	</div>
	<?php
}

/**
 * Prints the chosen service's script, deferred, for visitors.
 */
function rcobeca_analytics_script(): void {
	$saved = rcobeca_analytics();
	if ( '' === $saved['service'] || '' === $saved['id'] || current_user_can( 'edit_posts' ) ) {
		return;
	}
	$src = rcobeca_analytics_services()[ $saved['service'] ]['src'];
	if ( 'cloudflare' === $saved['service'] ) {
		printf( "<script defer src=\"%s\" data-cf-beacon='%s'></script>\n", esc_url( $src ), esc_attr( wp_json_encode( array( 'token' => $saved['id'] ) ) ) ); // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- the service's documented snippet.
	} else {
		printf( "<script defer src=\"%s\" data-website-id=\"%s\"></script>\n", esc_url( $src ), esc_attr( $saved['id'] ) ); // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- the service's documented snippet.
	}
}
add_action( 'wp_head', 'rcobeca_analytics_script', 50 );
