<?php
/**
 * Registers the plugin's blocks. Each lives in its own folder under blocks/
 * with a block.json; blocks are server-rendered (dynamic), so their saved
 * markup is only a comment with attributes and never goes invalid.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registers every block folder under blocks/.
 */
function rcobeca_register_blocks(): void {
	foreach ( glob( RCOBECA_DIR . '/blocks/*/block.json' ) as $rcobeca_block_json ) {
		register_block_type( dirname( $rcobeca_block_json ) );
	}
}
add_action( 'init', 'rcobeca_register_blocks' );
