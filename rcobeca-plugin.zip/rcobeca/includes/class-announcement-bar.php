<?php
/**
 * The announcement bar: one short line with a link, shown above the header on
 * every page, only while switched on and inside its date window. Editors set
 * it on its own admin screen (Announcement bar); it is stored in the
 * rcobeca_announcement option, readable and writable through the REST
 * settings endpoint.
 *
 * It renders on wp_body_open, outside the theme's templates, so it survives a
 * theme change.
 *
 * @package RCOBECA
 */

namespace RCOBECA;

defined( 'ABSPATH' ) || exit;

/**
 * The announcement and its window.
 */
class Announcement_Bar {

	public const OPTION = 'rcobeca_announcement';

	public const PAGE = 'rcobeca-announcement';

	/**
	 * The fields, with their defaults.
	 */
	public const DEFAULTS = array(
		'enabled'    => false,
		'text'       => '',
		'link'       => '',
		'link_label' => '',
		'start'      => '',
		'end'        => '',
	);

	/**
	 * The stored announcement.
	 *
	 * @return array{enabled: bool, text: string, link: string, link_label: string, start: string, end: string}
	 */
	public static function get(): array {
		return array_merge( self::DEFAULTS, (array) get_option( self::OPTION, array() ) );
	}

	/**
	 * Whether the bar shows now: switched on, with text, and today (site time)
	 * between its start and end dates, both inclusive; an empty date is open.
	 *
	 * @param array    $bar Announcement.
	 * @param int|null $now Timestamp; defaults to now.
	 */
	public static function is_live( array $bar, ?int $now = null ): bool {
		$today = wp_date( 'Y-m-d', $now ?? time() );
		return $bar['enabled'] && '' !== trim( $bar['text'] )
			&& ( '' === $bar['start'] || $bar['start'] <= $today )
			&& ( '' === $bar['end'] || $bar['end'] >= $today );
	}

	/**
	 * Cleans a submitted announcement.
	 *
	 * @param mixed $value Submitted value.
	 */
	public static function sanitize( $value ): array {
		$value = is_array( $value ) ? $value : array();
		$date  = static fn( $d ) => preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $d ) ? (string) $d : '';
		$link  = trim( (string) ( $value['link'] ?? '' ) );
		return array(
			'enabled'    => ! empty( $value['enabled'] ) && 'false' !== $value['enabled'],
			'text'       => sanitize_text_field( (string) ( $value['text'] ?? '' ) ),
			'link'       => str_starts_with( $link, '/' ) ? sanitize_text_field( $link ) : esc_url_raw( $link ),
			'link_label' => sanitize_text_field( (string) ( $value['link_label'] ?? '' ) ),
			'start'      => $date( $value['start'] ?? '' ),
			'end'        => $date( $value['end'] ?? '' ),
		);
	}

	/**
	 * Registers the setting, for the admin screen and the REST API.
	 */
	public static function register(): void {
		$properties = array();
		foreach ( self::DEFAULTS as $key => $default ) {
			$properties[ $key ] = array( 'type' => is_bool( $default ) ? 'boolean' : 'string' );
		}
		register_setting(
			self::PAGE,
			self::OPTION,
			array(
				'type'              => 'object',
				'description'       => __( 'The announcement bar: text, link and the dates it shows between.', 'rcobeca' ),
				'default'           => self::DEFAULTS,
				'sanitize_callback' => array( self::class, 'sanitize' ),
				'show_in_rest'      => array(
					'name'   => self::OPTION,
					'schema' => array(
						'type'       => 'object',
						'properties' => $properties,
					),
				),
			)
		);
	}

	/**
	 * Prints the bar at the top of the page when it is live.
	 */
	public static function render(): void {
		$bar = self::get();
		if ( ! self::is_live( $bar ) ) {
			return;
		}
		$href = str_starts_with( $bar['link'], '/' ) ? home_url( $bar['link'] ) : $bar['link'];
		echo '<div class="rcobeca-announcement" role="region" aria-label="' . esc_attr__( 'Announcement', 'rcobeca' ) . '"><p>';
		echo '<span class="rcobeca-announcement__text">' . esc_html( $bar['text'] ) . '</span>';
		if ( '' !== $href ) {
			$label = '' !== $bar['link_label'] ? $bar['link_label'] : __( 'Find out more', 'rcobeca' );
			echo ' <a href="' . esc_url( $href ) . '">' . esc_html( $label ) . '</a>';
		}
		echo '</p></div>';
	}

	/**
	 * The bar's styles, inline and only when it shows. Uses the theme's tokens
	 * when present.
	 */
	public static function styles(): void {
		if ( ! self::is_live( self::get() ) ) {
			return;
		}
		wp_register_style( 'rcobeca-announcement', false, array(), RCOBECA_VERSION );
		wp_enqueue_style( 'rcobeca-announcement' );
		wp_add_inline_style(
			'rcobeca-announcement',
			'.rcobeca-announcement{background:var(--wp--preset--color--primary,#1a3b85);color:#fff;font-size:.9375rem;line-height:1.45}'
			. '.rcobeca-announcement p{box-sizing:border-box;max-width:var(--wp--style--global--wide-size,1104px);margin:0 auto;padding:.7rem max(1rem,var(--wp--preset--spacing--40,2rem));text-align:center}'
			. '.rcobeca-announcement__text{font-family:var(--wp--preset--font-family--serif,Georgia,serif);font-size:1.0625rem}'
			. '.rcobeca-announcement a{margin-left:.5rem;color:var(--wp--custom--gold-on-dark,#d9b866);font-weight:600;text-decoration:underline;text-underline-offset:.18em;white-space:nowrap}'
			. '.rcobeca-announcement a::after{content:"\2192";display:inline-block;margin-left:.3em}'
			. '.rcobeca-announcement a:hover{color:#fff}'
			. '.rcobeca-announcement a:focus-visible{outline:2px solid #fff;outline-offset:2px}'
		);
	}

	/**
	 * Adds the admin screen. Editors can use it (they edit others' posts),
	 * without access to the site's settings.
	 */
	public static function admin_menu(): void {
		add_menu_page( __( 'Announcement bar', 'rcobeca' ), __( 'Announcement bar', 'rcobeca' ), 'edit_others_posts', self::PAGE, array( self::class, 'admin_page' ), 'dashicons-megaphone', 22 );
	}

	/**
	 * The capability that may save the setting.
	 */
	public static function capability(): string {
		return 'edit_others_posts';
	}

	/**
	 * Renders the admin screen.
	 */
	public static function admin_page(): void {
		$bar   = self::get();
		$name  = static fn( string $key ) => esc_attr( self::OPTION . '[' . $key . ']' );
		$state = self::is_live( $bar ) ? __( 'Showing now.', 'rcobeca' ) : __( 'Not showing now.', 'rcobeca' );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Announcement bar', 'rcobeca' ); ?></h1>
			<p><?php esc_html_e( 'One short line with a link, above the header on every page: for the next Royal Charity Ball, an appeal or a deadline. It shows only while switched on and between its dates (both included; leave a date empty for no limit).', 'rcobeca' ); ?> <strong><?php echo esc_html( $state ); ?></strong></p>
			<form method="post" action="options.php">
				<?php settings_fields( self::PAGE ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="rcobeca-announcement-enabled"><?php esc_html_e( 'Show the bar', 'rcobeca' ); ?></label></th>
						<td><input type="checkbox" id="rcobeca-announcement-enabled" name="<?php echo $name( 'enabled' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above. ?>" value="1" <?php checked( $bar['enabled'] ); ?>></td>
					</tr>
					<tr>
						<th scope="row"><label for="rcobeca-announcement-text"><?php esc_html_e( 'Text', 'rcobeca' ); ?></label></th>
						<td><input class="large-text" type="text" maxlength="160" id="rcobeca-announcement-text" name="<?php echo $name( 'text' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" value="<?php echo esc_attr( $bar['text'] ); ?>">
						<p class="description"><?php esc_html_e( 'One sentence, e.g. “Tickets for the 31st Royal Charity Ball are on sale.”', 'rcobeca' ); ?></p></td>
					</tr>
					<tr>
						<th scope="row"><label for="rcobeca-announcement-link"><?php esc_html_e( 'Link', 'rcobeca' ); ?></label></th>
						<td><input class="regular-text" type="text" id="rcobeca-announcement-link" name="<?php echo $name( 'link' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" value="<?php echo esc_attr( $bar['link'] ); ?>">
						<p class="description"><?php esc_html_e( 'A page on this site such as /ball/, or a full address.', 'rcobeca' ); ?></p></td>
					</tr>
					<tr>
						<th scope="row"><label for="rcobeca-announcement-label"><?php esc_html_e( 'Link text', 'rcobeca' ); ?></label></th>
						<td><input class="regular-text" type="text" id="rcobeca-announcement-label" name="<?php echo $name( 'link_label' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" value="<?php echo esc_attr( $bar['link_label'] ); ?>"></td>
					</tr>
					<tr>
						<th scope="row"><label for="rcobeca-announcement-start"><?php esc_html_e( 'From', 'rcobeca' ); ?></label></th>
						<td><input type="date" id="rcobeca-announcement-start" name="<?php echo $name( 'start' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" value="<?php echo esc_attr( $bar['start'] ); ?>"></td>
					</tr>
					<tr>
						<th scope="row"><label for="rcobeca-announcement-end"><?php esc_html_e( 'Until', 'rcobeca' ); ?></label></th>
						<td><input type="date" id="rcobeca-announcement-end" name="<?php echo $name( 'end' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" value="<?php echo esc_attr( $bar['end'] ); ?>"></td>
					</tr>
				</table>
				<?php submit_button( __( 'Save', 'rcobeca' ) ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Confirms a save on the screen (options.php redirects back with settings-updated).
	 */
	public static function saved_notice(): void {
		// Read-only flag set by options.php after a save.
		if ( isset( $_GET['page'], $_GET['settings-updated'] ) && self::PAGE === $_GET['page'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Settings saved.', 'rcobeca' ) . '</p></div>';
		}
	}
}

add_action( 'init', array( Announcement_Bar::class, 'register' ) );
add_action( 'wp_body_open', array( Announcement_Bar::class, 'render' ), 5 );
add_action( 'wp_enqueue_scripts', array( Announcement_Bar::class, 'styles' ) );
add_action( 'admin_menu', array( Announcement_Bar::class, 'admin_menu' ) );
add_action( 'admin_notices', array( Announcement_Bar::class, 'saved_notice' ) );
add_filter( 'option_page_capability_' . Announcement_Bar::PAGE, array( Announcement_Bar::class, 'capability' ) );
