<?php
/**
 * The one rate limiter the public forms and Table Lookup share, and the one
 * way they read who is asking.
 *
 * @package RCOBECA
 */

namespace RCOBECA;

defined( 'ABSPATH' ) || exit;

/**
 * Rolling-window counters kept in transients, one per bucket and key.
 */
class Rate_Limit {

	/**
	 * Allows a number of hits per key in a rolling window, and counts this one
	 * when it is allowed.
	 *
	 * @param string                       $bucket What is limited, e.g. "form" or "lookup-name".
	 * @param string                       $key    Who or what within it, e.g. an address.
	 * @param array{max: int, window: int} $limit  Hits, and window in seconds.
	 */
	public static function allow( string $bucket, string $key, array $limit ): bool {
		$transient = 'rcobeca_' . $bucket . '_' . md5( $key );
		$now       = time();
		$times     = array_filter( (array) get_transient( $transient ), static fn( $t ) => $t > $now - $limit['window'] );
		if ( count( $times ) >= $limit['max'] ) {
			return false;
		}
		$times[] = $now;
		set_transient( $transient, array_values( $times ), $limit['window'] );
		return true;
	}

	/**
	 * The visitor's address: REMOTE_ADDR. Behind a proxy or CDN that is the
	 * proxy's address; a host that knows its proxy can return the forwarded
	 * address through the rcobeca_client_ip filter (headers alone can be forged,
	 * so they are not trusted by default).
	 */
	public static function client_ip(): string {
		$address = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		/**
		 * Filters the visitor's address used by the rate limits.
		 *
		 * @param string $address REMOTE_ADDR.
		 */
		return (string) apply_filters( 'rcobeca_client_ip', $address );
	}
}
