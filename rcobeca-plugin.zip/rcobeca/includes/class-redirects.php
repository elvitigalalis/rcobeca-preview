<?php
/**
 * Permanent redirects from old rcobeca.org URLs to their new homes.
 *
 * @package RCOBECA
 */

namespace RCOBECA;

/**
 * The redirect map is data: importer steps record rows (old path => new
 * home) through Context::redirect(), stored in the rcobeca_redirects option
 * with the step that made them. A new home is a post ID (followed to its
 * current permalink, so renaming a page never breaks a redirect) or a path.
 */
class Redirects {

	public const OPTION = 'rcobeca_redirects';

	/**
	 * Adds or replaces a row.
	 *
	 * @param string     $from Old URL or path.
	 * @param int|string $to Post ID or path of the new home.
	 * @param string     $step Step that owns the row.
	 */
	public static function add( string $from, int|string $to, string $step ): void {
		$rows                             = self::all();
		$rows[ self::normalize( $from ) ] = array(
			'to'   => $to,
			'step' => $step,
		);
		update_option( self::OPTION, $rows, true );
	}

	/**
	 * Drops every row a step made, before it runs again.
	 *
	 * @param string $step Step name.
	 */
	public static function clear_step( string $step ): void {
		$rows = array_filter( self::all(), static fn( $row ) => $row['step'] !== $step );
		update_option( self::OPTION, $rows, true );
	}

	/**
	 * Every row: normalized old path => [to, step].
	 *
	 * @return array<string, array{to: int|string, step: string}>
	 */
	public static function all(): array {
		return (array) get_option( self::OPTION, array() );
	}

	/**
	 * Where an old URL now lives, as an absolute URL.
	 *
	 * @param string $from Old URL or path.
	 * @return string|null Null when there's no row or its target is gone.
	 */
	public static function target( string $from ): ?string {
		$row = self::all()[ self::normalize( $from ) ] ?? null;
		if ( ! $row ) {
			return null;
		}
		if ( is_int( $row['to'] ) ) {
			return 'publish' === get_post_status( $row['to'] ) ? (string) get_permalink( $row['to'] ) : null;
		}
		return home_url( $row['to'] );
	}

	/**
	 * One spelling per old URL: its path, decoded, lower-case, with a trailing
	 * slash unless it names a file (/hostel.htm, /2016RoyalBallSouvenir.pdf).
	 * The old site's /newsite/ prefix is kept; it is a path of its own.
	 *
	 * @param string $url URL or path.
	 */
	public static function normalize( string $url ): string {
		$path = rawurldecode( (string) wp_parse_url( trim( $url ), PHP_URL_PATH ) );
		$path = '/' . ltrim( strtolower( $path ), '/' );
		if ( ! preg_match( '/\.[a-z0-9]{2,5}$/', $path ) ) {
			$path = rtrim( $path, '/' ) . '/';
		}
		return $path;
	}

	/**
	 * Where an address under /newsite/ now lives. The old WordPress was
	 * installed in /newsite/, so its files and some links carried that prefix:
	 * an upload goes to the media library copy imported from it (a resized
	 * copy, such as photo-1024x768.jpg, to the image it was cut from); anything else to
	 * the same address without the prefix, which redirects onward if it moved.
	 *
	 * @param string $request Requested URL or path.
	 * @return string|null Null for addresses outside /newsite/ and uploads that were not imported.
	 */
	public static function newsite( string $request ): ?string {
		$path = (string) wp_parse_url( $request, PHP_URL_PATH );
		if ( ! preg_match( '#^/newsite(/.*)?$#i', $path, $m ) ) {
			return null;
		}
		$rest = $m[1] ?? '/';
		if ( ! str_starts_with( $rest, '/wp-content/uploads/' ) ) {
			return home_url( $rest );
		}
		$exact    = rawurldecode( $path );
		$original = (string) preg_replace( '/-\d+x\d+(\.\w+)$/', '$1', $exact );
		$sources  = array();
		foreach ( array_unique( array( $exact, $original ) ) as $file ) {
			array_push( $sources, 'https://rcobeca.org' . $file, 'http://rcobeca.org' . $file );
		}
		$ids = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'     => '_rcobeca_source_url',
						'value'   => $sources,
						'compare' => 'IN',
					),
				),
			)
		);
		return $ids ? (string) wp_get_attachment_url( $ids[0] ) : null;
	}

	/**
	 * Sends a 301 when the requested path has a row. Runs before WordPress
	 * resolves 404s or guesses canonical URLs.
	 */
	public static function handle(): void {
		// Only used as a lookup key after normalize(); sanitize_text_field() would strip %20 from old file names.
		$request = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$target  = self::target( $request ) ?? self::newsite( $request );
		if ( $target && self::normalize( $target ) !== self::normalize( $request ) ) {
			wp_safe_redirect( $target, 301, 'RCOBECA' );
			exit;
		}
	}
}

add_action( 'template_redirect', array( Redirects::class, 'handle' ), 0 );
