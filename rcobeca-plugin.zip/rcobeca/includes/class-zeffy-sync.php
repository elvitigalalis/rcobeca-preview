<?php
/**
 * Fundraising Project progress synced from Zeffy (ADR 0002,
 * docs/research/zeffy-automation.md). Re-reading Zeffy is the only way a
 * total changes: the hourly job re-reads every linked campaign, and the
 * webhook only triggers the same re-read, so duplicates and refunds can never
 * corrupt a figure.
 *
 * @package RCOBECA
 */

namespace RCOBECA;

defined( 'ABSPATH' ) || exit;

/**
 * Reads campaigns from Zeffy's API into the Project fields
 * (`rcobeca_raised_cents`, `rcobeca_raised_synced_at`, `rcobeca_goal_cents`).
 */
class Zeffy_Sync {

	public const HOOK = 'rcobeca_zeffy_sync';
	public const API  = 'https://api.zeffy.com/api/v1/';

	/**
	 * Hooks the hourly job.
	 */
	public static function init(): void {
		add_action( self::HOOK, array( self::class, 'sync_all' ) );
		add_action( 'init', array( self::class, 'schedule' ) );
		add_action( 'rest_api_init', array( self::class, 'register_webhook' ) );
	}

	/**
	 * Schedules the hourly job once. WP-Cron runs on page views, so a quiet
	 * site can run late; a real system cron hitting wp-cron.php fixes that.
	 */
	public static function schedule(): void {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time(), 'hourly', self::HOOK );
		}
	}

	/**
	 * The API key: the ZEFFY_API_KEY constant (wp-config.php) or the setting.
	 */
	public static function api_key(): string {
		return defined( 'ZEFFY_API_KEY' ) ? (string) constant( 'ZEFFY_API_KEY' ) : (string) get_option( 'rcobeca_zeffy_api_key', '' );
	}

	/**
	 * The webhook signing secret (whsec_…): the ZEFFY_WEBHOOK_SECRET constant
	 * or the setting.
	 */
	public static function webhook_secret(): string {
		return defined( 'ZEFFY_WEBHOOK_SECRET' ) ? (string) constant( 'ZEFFY_WEBHOOK_SECRET' ) : (string) get_option( 'rcobeca_zeffy_webhook_secret', '' );
	}

	/**
	 * The URL to give Zeffy for webhooks.
	 */
	public static function webhook_url(): string {
		return rest_url( 'rcobeca/v1/zeffy-webhook' );
	}

	/**
	 * Registers POST /wp-json/rcobeca/v1/zeffy-webhook. It is public (Zeffy
	 * can't log in); the signature is the authentication.
	 */
	public static function register_webhook(): void {
		register_rest_route(
			'rcobeca/v1',
			'/zeffy-webhook',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'receive_webhook' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * Handles a webhook: checks Zeffy's signature, then re-reads the affected
	 * campaign (every linked campaign when the event doesn't name one, as
	 * payment.updated and payment.deleted don't). It never changes a total
	 * itself. A failed re-read answers 503 so that Zeffy retries.
	 *
	 * @param \WP_REST_Request $request Request.
	 */
	public static function receive_webhook( \WP_REST_Request $request ): \WP_REST_Response {
		$body = $request->get_body();
		if ( ! self::signed( $body, (string) $request->get_header( 'zeffy_signature' ) ) ) {
			return new \WP_REST_Response( array( 'error' => 'invalid signature' ), 401 );
		}
		$event = json_decode( $body, true );
		$event = is_array( $event ) ? $event : array();
		$seen  = (array) get_option( 'rcobeca_zeffy_seen_events', array() );
		$key   = (string) ( $event['id'] ?? '' );
		if ( '' !== $key && in_array( $key, $seen, true ) ) {
			return new \WP_REST_Response( array( 'status' => 'duplicate' ), 200 );
		}
		$campaign = (string) ( $event['data']['campaign_id'] ?? $event['data']['object']['campaign_id'] ?? '' );
		$projects = self::linked_projects();
		if ( '' !== $campaign ) {
			$projects = array_filter( $projects, static fn( $id ) => trim( (string) get_post_meta( $id, 'rcobeca_zeffy_campaign_id', true ) ) === $campaign );
		}
		if ( '' !== self::api_key() ) {
			foreach ( $projects as $id ) {
				if ( ! self::refresh( $id ) ) {
					return new \WP_REST_Response( array( 'error' => 're-read failed' ), 503 );
				}
			}
		}
		if ( '' !== $key ) {
			$seen[] = $key;
			update_option( 'rcobeca_zeffy_seen_events', array_slice( $seen, -500 ), false );
		}
		return new \WP_REST_Response( array( 'status' => 'ok' ), 200 );
	}

	/**
	 * Whether a body carries a valid, fresh Zeffy-Signature
	 * (`t=<unix>,v1=<hex HMAC-SHA256 of "t.body">`, at most 5 minutes old).
	 *
	 * @param string $body Raw request body.
	 * @param string $header Zeffy-Signature header.
	 */
	private static function signed( string $body, string $header ): bool {
		$secret = self::webhook_secret();
		if ( '' === $secret || ! preg_match( '/(?:^|,)\s*t=(\d+)/', $header, $t ) || abs( time() - (int) $t[1] ) > 300 ) {
			return false;
		}
		$expected = hash_hmac( 'sha256', $t[1] . '.' . $body, $secret );
		preg_match_all( '/(?:^|,)\s*v1=([0-9a-f]+)/i', $header, $signatures );
		foreach ( $signatures[1] as $signature ) {
			if ( hash_equals( $expected, strtolower( $signature ) ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Re-reads every Fundraising Project linked to a Zeffy campaign.
	 */
	public static function sync_all(): void {
		if ( '' === self::api_key() ) {
			return;
		}
		foreach ( self::linked_projects() as $i => $id ) {
			if ( self::waiting() ) {
				return;
			}
			if ( $i > 0 ) {
				usleep( 60000 ); // Under Zeffy's 20 requests a second.
			}
			self::refresh( $id );
		}
	}

	/**
	 * Whether Zeffy has asked us to wait (HTTP 429) and the wait isn't over.
	 */
	public static function waiting(): bool {
		return time() < (int) get_option( 'rcobeca_zeffy_retry_at', 0 );
	}

	/**
	 * Fundraising Projects with a Zeffy campaign ID.
	 *
	 * @return int[]
	 */
	public static function linked_projects(): array {
		return get_posts(
			array(
				'post_type'      => RCOBECA_PROJECT,
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- a handful of Projects, hourly.
					array(
						'key'   => 'rcobeca_status',
						'value' => 'fundraising',
					),
					array(
						'key'     => 'rcobeca_zeffy_campaign_id',
						'value'   => '',
						'compare' => '!=',
					),
				),
			)
		);
	}

	/**
	 * Re-reads one Project's campaign and stores its totals. On any failure
	 * the last good figure and its date stay, and the problem is noted in
	 * `rcobeca_zeffy_sync_error` for the edit screen.
	 *
	 * @param int $id Project ID.
	 */
	public static function refresh( int $id ): bool {
		$campaign = trim( (string) get_post_meta( $id, 'rcobeca_zeffy_campaign_id', true ) );
		if ( '' === $campaign || '' === self::api_key() || self::waiting() ) {
			return false;
		}
		$body = self::get( 'campaigns/' . rawurlencode( $campaign ) );
		if ( is_wp_error( $body ) ) {
			return self::fail( $id, $body->get_error_message() );
		}
		if ( ! isset( $body['volume'] ) || ! is_int( $body['volume'] ) || $body['volume'] < 0 ) {
			return self::fail( $id, __( 'Zeffy’s answer had no amount raised.', 'rcobeca' ) );
		}
		if ( 0 === $body['volume'] && (int) get_post_meta( $id, 'rcobeca_raised_cents', true ) > 0 ) {
			return self::fail( $id, __( 'Zeffy reported $0 raised, so the last figure was kept. If $0 is right (every gift refunded), set the manual override.', 'rcobeca' ) );
		}
		update_post_meta( $id, 'rcobeca_raised_cents', $body['volume'] );
		$goal = $body['target'] ?? $body['goal_amount'] ?? null;
		if ( is_int( $goal ) && $goal > 0 ) {
			update_post_meta( $id, 'rcobeca_goal_cents', $goal );
		}
		update_post_meta( $id, 'rcobeca_raised_synced_at', time() );
		delete_post_meta( $id, 'rcobeca_zeffy_sync_error' );
		return true;
	}

	/**
	 * The account's campaigns, id => title, for picking one on the edit
	 * screen. Remembered for ten minutes; empty without a key or on failure.
	 *
	 * @return array<string, string>
	 */
	public static function campaigns(): array {
		if ( '' === self::api_key() || self::waiting() ) {
			return array();
		}
		$cached = get_transient( 'rcobeca_zeffy_campaigns' );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		$body      = self::get( 'campaigns?limit=100' );
		$campaigns = array();
		foreach ( is_wp_error( $body ) ? array() : (array) ( $body['data'] ?? array() ) as $campaign ) {
			if ( isset( $campaign['id'], $campaign['title'] ) ) {
				$campaigns[ (string) $campaign['id'] ] = (string) $campaign['title'];
			}
		}
		set_transient( 'rcobeca_zeffy_campaigns', $campaigns, 10 * MINUTE_IN_SECONDS );
		return $campaigns;
	}

	/**
	 * Notes why a read failed, keeping the figures as they were.
	 *
	 * @param int    $id Project ID.
	 * @param string $error What went wrong.
	 */
	private static function fail( int $id, string $error ): bool {
		/* translators: 1: date and time, 2: what went wrong. */
		update_post_meta( $id, 'rcobeca_zeffy_sync_error', sprintf( __( '%1$s: %2$s', 'rcobeca' ), wp_date( 'F j, Y g:i a' ), $error ) );
		return false;
	}

	/**
	 * GETs an API path and decodes the JSON answer.
	 *
	 * @param string $path Path under /api/v1/.
	 * @return array|\WP_Error
	 */
	private static function get( string $path ) {
		$response = wp_remote_get(
			self::API . $path,
			array(
				'timeout' => 10,
				'headers' => array(
					'Authorization' => 'Bearer ' . self::api_key(),
					'Accept'        => 'application/json',
				),
			)
		);
		if ( is_wp_error( $response ) ) {
			/* translators: %s: error from the HTTP library. */
			return new \WP_Error( 'rcobeca_zeffy_unreachable', sprintf( __( 'Couldn’t reach Zeffy (%s).', 'rcobeca' ), $response->get_error_message() ) );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 429 === $code ) {
			$wait = (int) wp_remote_retrieve_header( $response, 'retry-after' );
			update_option( 'rcobeca_zeffy_retry_at', time() + max( 1, $wait ? $wait : 60 ), false );
			return new \WP_Error( 'rcobeca_zeffy_rate_limited', __( 'Zeffy asked us to slow down; the next hourly sync will try again.', 'rcobeca' ) );
		}
		if ( 401 === $code || 403 === $code ) {
			return new \WP_Error( 'rcobeca_zeffy_key', __( 'Zeffy refused the API key. The Zeffy organisation owner may need to create a new one (Settings → Zeffy sync).', 'rcobeca' ) );
		}
		if ( 404 === $code ) {
			return new \WP_Error( 'rcobeca_zeffy_not_found', __( 'Zeffy has no campaign with this ID. Check the Zeffy campaign ID.', 'rcobeca' ) );
		}
		if ( 200 !== $code ) {
			/* translators: %d: HTTP status code. */
			return new \WP_Error( 'rcobeca_zeffy_status', sprintf( __( 'Zeffy answered with an error (HTTP %d).', 'rcobeca' ), $code ) );
		}
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		return is_array( $body ) ? $body : new \WP_Error( 'rcobeca_zeffy_json', __( 'Zeffy’s answer could not be read.', 'rcobeca' ) );
	}
}

Zeffy_Sync::init();
