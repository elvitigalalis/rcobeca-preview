<?php
/**
 * Views over Committee Terms: the current Committee, every Club Year's
 * Committee, Past Presidents and a Person's service history. Only published
 * Terms count; Terms awaiting review (conflicting sources) are kept as
 * "pending" and shown nowhere until an editor publishes them.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

/**
 * A Club Year as shown everywhere: 2025 => "2025–26", 1999 => "1999–2000".
 *
 * @param int $year Starting year.
 */
function rcobeca_club_year_label( int $year ): string {
	$next = $year + 1;
	return $year . '–' . ( intdiv( $year, 100 ) === intdiv( $next, 100 ) ? substr( (string) $next, -2 ) : $next );
}

/**
 * Every published Committee Term, newest Club Year first, then by role order.
 *
 * @return array<int, array{id: int, year: int, role: string, sort: int, person: int, email: string, highlights: string}>
 */
function rcobeca_committee_terms(): array {
	$posts = get_posts(
		array(
			'post_type'      => 'rcobeca_term',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'orderby'        => 'ID',
			'order'          => 'ASC',
		)
	);
	$terms = array();
	foreach ( $posts as $post ) {
		$meta    = static fn( string $key ) => (string) get_post_meta( $post->ID, $key, true );
		$terms[] = array(
			'id'         => $post->ID,
			'year'       => (int) $meta( 'rcobeca_club_year' ),
			'role'       => $meta( 'rcobeca_role' ),
			'sort'       => '' !== $meta( 'rcobeca_sort' ) ? (int) $meta( 'rcobeca_sort' ) : rcobeca_role_rank( $meta( 'rcobeca_role' ) ) * 100,
			'person'     => (int) $meta( 'rcobeca_person' ),
			'email'      => $meta( 'rcobeca_email' ),
			'highlights' => $meta( 'rcobeca_highlights' ),
		);
	}
	$terms = array_filter( $terms, static fn( $t ) => $t['year'] > 0 && 'publish' === get_post_status( $t['person'] ) );
	usort( $terms, static fn( $a, $b ) => array( $b['year'], $a['sort'], $a['id'] ) <=> array( $a['year'], $b['sort'], $b['id'] ) );
	return $terms;
}

/**
 * Published Terms grouped by Club Year, newest first.
 *
 * @return array<int, array[]> Starting year => Terms.
 */
function rcobeca_committees_by_year(): array {
	$years = array();
	foreach ( rcobeca_committee_terms() as $term ) {
		$years[ $term['year'] ][] = $term;
	}
	return $years;
}

/**
 * The latest Club Year with a published Term: the current Committee.
 */
function rcobeca_current_club_year(): ?int {
	$years = array_keys( rcobeca_committees_by_year() );
	return $years ? (int) $years[0] : null;
}

/**
 * Presidents by Club Year, newest first.
 *
 * @return array[] Terms.
 */
function rcobeca_presidents(): array {
	return array_values( array_filter( rcobeca_committee_terms(), static fn( $t ) => 'President' === $t['role'] ) );
}

/**
 * A Person's Terms, newest first.
 *
 * @param int $person Person ID.
 * @return array[] Terms.
 */
function rcobeca_person_terms( int $person ): array {
	return array_values( array_filter( rcobeca_committee_terms(), static fn( $t ) => $t['person'] === $person ) );
}

/**
 * A Club Year's Terms as rows of one role each, people in order:
 * [ role label, Terms ], e.g. [ "Vice Presidents", [ … ] ].
 *
 * @param array[] $terms One Club Year's Terms, sorted.
 * @return array<int, array{0: string, 1: array[]}>
 */
function rcobeca_terms_by_role( array $terms ): array {
	$plural = array(
		'Vice President'   => __( 'Vice Presidents', 'rcobeca' ),
		'Committee Member' => __( 'Committee Members', 'rcobeca' ),
	);
	$rows   = array();
	foreach ( $terms as $term ) {
		$rows[ $term['role'] ][] = $term;
	}
	$out = array();
	foreach ( $rows as $role => $members ) {
		$out[] = array( count( $members ) > 1 ? ( $plural[ $role ] ?? $role ) : $role, $members );
	}
	return $out;
}
