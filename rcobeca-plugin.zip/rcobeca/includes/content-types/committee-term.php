<?php
/**
 * Committee Term: one Person holding one committee role for one Club Year.
 * The current Committee, the Committee history, Past Presidents and each
 * Person's service history are views over published Committee Terms
 * (includes/committee.php), so adding a Term is the only edit a new Club Year
 * needs.
 *
 * Editors use a plain form (no block editor): pick a Person or type a new
 * name, a role, the Club Year's starting year and, for officers, the role's
 * email address.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registers the Committee Term content type and its fields.
 */
function rcobeca_register_committee_term(): void {
	register_post_type(
		'rcobeca_term',
		array(
			'labels'               => array(
				'name'          => __( 'Committee Terms', 'rcobeca' ),
				'singular_name' => __( 'Committee Term', 'rcobeca' ),
				'add_new'       => __( 'Add Committee Term', 'rcobeca' ),
				'add_new_item'  => __( 'Add Committee Term', 'rcobeca' ),
				'edit_item'     => __( 'Edit Committee Term', 'rcobeca' ),
				'search_items'  => __( 'Search Committee Terms', 'rcobeca' ),
				'not_found'     => __( 'No Committee Terms found.', 'rcobeca' ),
			),
			'description'          => __( 'One Person in one committee role for one Club Year.', 'rcobeca' ),
			'public'               => false,
			'show_ui'              => true,
			'show_in_rest'         => true,
			'menu_icon'            => 'dashicons-awards',
			'menu_position'        => 21,
			'supports'             => array( 'custom-fields' ),
			'register_meta_box_cb' => 'rcobeca_committee_term_meta_box',
		)
	);

	$fields = array(
		'rcobeca_person'     => array( 'integer', __( 'Person ID', 'rcobeca' ) ),
		'rcobeca_role'       => array( 'string', __( 'Role, e.g. President or Committee Member', 'rcobeca' ) ),
		'rcobeca_club_year'  => array( 'integer', __( 'Starting year of the Club Year (2025 for 2025–26)', 'rcobeca' ) ),
		'rcobeca_sort'       => array( 'integer', __( 'Order within the Club Year; lower comes first', 'rcobeca' ) ),
		'rcobeca_email'      => array( 'string', __( 'Contact email shown for officer roles', 'rcobeca' ) ),
		'rcobeca_highlights' => array( 'string', __( 'Major events of the Club Year (on the President’s Term)', 'rcobeca' ) ),

		'rcobeca_note'       => array( 'string', __( 'Why this Term awaits review (conflicting sources)', 'rcobeca' ) ),
	);
	foreach ( $fields as $key => [ $type, $description ] ) {
		register_post_meta(
			'rcobeca_term',
			$key,
			array(
				'type'         => $type,
				'description'  => $description,
				'single'       => true,
				'show_in_rest' => true,
			)
		);
	}
}
add_action( 'init', 'rcobeca_register_committee_term' );

/**
 * Committee roles in display order, with the rank used for sorting.
 *
 * @return array<string, int> Role => rank.
 */
function rcobeca_committee_roles(): array {
	return array(
		'President'        => 10,
		'President Elect'  => 20,
		'Vice President'   => 30,
		'Secretary'        => 40,
		'Treasurer'        => 50,
		'Committee Member' => 60,
	);
}

/**
 * Plain forms (no block editor) for records that are just a few fields.
 *
 * @param bool   $use_block_editor Whether to use the block editor.
 * @param string $post_type Post type.
 */
function rcobeca_plain_record_forms( bool $use_block_editor, string $post_type ): bool {
	return in_array( $post_type, array( 'rcobeca_term', 'rcobeca_life_member', 'rcobeca_document' ), true ) ? false : $use_block_editor;
}
add_filter( 'use_block_editor_for_post_type', 'rcobeca_plain_record_forms', 10, 2 );

/**
 * Adds the Committee Term form.
 */
function rcobeca_committee_term_meta_box(): void {
	add_meta_box( 'rcobeca-term', __( 'Committee Term', 'rcobeca' ), 'rcobeca_committee_term_form', 'rcobeca_term', 'normal', 'high' );
}

/**
 * The Committee Term form.
 *
 * @param WP_Post $post Term being edited.
 */
function rcobeca_committee_term_form( WP_Post $post ): void {
	$value = static fn( string $key ) => (string) get_post_meta( $post->ID, $key, true );
	$year  = $value( 'rcobeca_club_year' );
	$year  = '' !== $year ? $year : (string) ( rcobeca_current_club_year() ?? (int) gmdate( 'Y' ) );
	$note  = $value( 'rcobeca_note' );
	wp_nonce_field( 'rcobeca_term', 'rcobeca_term_nonce' );
	if ( '' !== $note ) {
		echo '<div class="notice notice-warning inline"><p>' . esc_html( $note ) . '</p></div>';
	}
	?>
	<table class="form-table" role="presentation">
		<tr>
			<th scope="row"><label for="rcobeca-person"><?php esc_html_e( 'Person', 'rcobeca' ); ?></label></th>
			<td>
				<select id="rcobeca-person" name="rcobeca_person">
					<option value="0"><?php esc_html_e( '— New Person (type the name below) —', 'rcobeca' ); ?></option>
					<?php
					foreach ( get_posts(
						array(
							'post_type'      => 'rcobeca_person',
							'posts_per_page' => -1,
							'orderby'        => 'title',
							'order'          => 'ASC',
						)
					) as $person ) {
						printf( '<option value="%d"%s>%s</option>', (int) $person->ID, selected( (int) $value( 'rcobeca_person' ), $person->ID, false ), esc_html( rcobeca_person_name( $person->ID ) ) );
					}
					?>
				</select>
				<p>
					<label for="rcobeca-new-person"><?php esc_html_e( 'or a new Person’s name', 'rcobeca' ); ?></label><br>
					<input type="text" class="regular-text" id="rcobeca-new-person" name="rcobeca_new_person" value="">
				</p>
				<p class="description"><?php esc_html_e( 'Pick the Person if he is already listed, so each Old Boy is recorded once. A new name creates a Person.', 'rcobeca' ); ?></p>
			</td>
		</tr>
		<tr>
			<th scope="row"><label for="rcobeca-role"><?php esc_html_e( 'Role', 'rcobeca' ); ?></label></th>
			<td>
				<input type="text" class="regular-text" id="rcobeca-role" name="rcobeca_role" list="rcobeca-roles" value="<?php echo esc_attr( $value( 'rcobeca_role' ) ); ?>" required>
				<datalist id="rcobeca-roles">
					<?php foreach ( array_keys( rcobeca_committee_roles() ) as $role ) : ?>
						<option value="<?php echo esc_attr( $role ); ?>"></option>
					<?php endforeach; ?>
				</datalist>
			</td>
		</tr>
		<tr>
			<th scope="row"><label for="rcobeca-club-year"><?php esc_html_e( 'Club Year (starting year)', 'rcobeca' ); ?></label></th>
			<td>
				<input type="number" id="rcobeca-club-year" name="rcobeca_club_year" min="1993" max="2100" value="<?php echo esc_attr( $year ); ?>" required>
				<p class="description"><?php esc_html_e( 'The year of the AGM that elected the Committee: 2025 for Club Year 2025–26.', 'rcobeca' ); ?></p>
			</td>
		</tr>
		<tr>
			<th scope="row"><label for="rcobeca-email"><?php esc_html_e( 'Contact email (officers)', 'rcobeca' ); ?></label></th>
			<td><input type="email" class="regular-text" id="rcobeca-email" name="rcobeca_email" value="<?php echo esc_attr( $value( 'rcobeca_email' ) ); ?>" placeholder="secretary@rcobeca.org"></td>
		</tr>
		<tr>
			<th scope="row"><label for="rcobeca-sort"><?php esc_html_e( 'Order (optional)', 'rcobeca' ); ?></label></th>
			<td>
				<input type="number" id="rcobeca-sort" name="rcobeca_sort" value="<?php echo esc_attr( $value( 'rcobeca_sort' ) ); ?>">
				<p class="description"><?php esc_html_e( 'Leave empty to list by role (President first). Set it to order people within a role.', 'rcobeca' ); ?></p>
			</td>
		</tr>
		<tr>
			<th scope="row"><label for="rcobeca-highlights"><?php esc_html_e( 'Major events (President’s Term)', 'rcobeca' ); ?></label></th>
			<td><textarea class="large-text" rows="2" id="rcobeca-highlights" name="rcobeca_highlights"><?php echo esc_textarea( $value( 'rcobeca_highlights' ) ); ?></textarea></td>
		</tr>
	</table>
	<?php
}

/**
 * Saves the form: links or creates the Person, stores the fields and names
 * the Term ("2025–26 · Secretary · Prageeth Manoratne").
 *
 * @param int $post_id Term ID.
 */
function rcobeca_save_committee_term( int $post_id ): void {
	if ( ! isset( $_POST['rcobeca_term_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['rcobeca_term_nonce'] ), 'rcobeca_term' ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$person   = absint( $_POST['rcobeca_person'] ?? 0 );
	$new_name = sanitize_text_field( wp_unslash( $_POST['rcobeca_new_person'] ?? '' ) );
	if ( '' !== $new_name ) {
		$existing = get_posts(
			array(
				'post_type'      => 'rcobeca_person',
				'title'          => $new_name,
				'posts_per_page' => 1,
				'fields'         => 'ids',
			)
		);
		$person   = $existing ? (int) $existing[0] : wp_insert_post(
			array(
				'post_type'   => 'rcobeca_person',
				'post_title'  => $new_name,
				'post_status' => 'publish',
			)
		);
	}
	$role = sanitize_text_field( wp_unslash( $_POST['rcobeca_role'] ?? '' ) );
	$sort = sanitize_text_field( wp_unslash( $_POST['rcobeca_sort'] ?? '' ) );
	update_post_meta( $post_id, 'rcobeca_person', (int) $person );
	update_post_meta( $post_id, 'rcobeca_role', $role );
	update_post_meta( $post_id, 'rcobeca_club_year', absint( $_POST['rcobeca_club_year'] ?? 0 ) );
	update_post_meta( $post_id, 'rcobeca_sort', '' !== $sort ? (int) $sort : rcobeca_role_rank( $role ) * 100 );
	update_post_meta( $post_id, 'rcobeca_email', sanitize_email( wp_unslash( $_POST['rcobeca_email'] ?? '' ) ) );
	update_post_meta( $post_id, 'rcobeca_highlights', sanitize_textarea_field( wp_unslash( $_POST['rcobeca_highlights'] ?? '' ) ) );

	remove_action( 'save_post_rcobeca_term', 'rcobeca_save_committee_term' );
	wp_update_post(
		array(
			'ID'         => $post_id,
			'post_title' => rcobeca_committee_term_title( $post_id ),
		)
	);
	add_action( 'save_post_rcobeca_term', 'rcobeca_save_committee_term' );
}
add_action( 'save_post_rcobeca_term', 'rcobeca_save_committee_term' );

/**
 * A Term's title for admin lists: "2025–26 · Secretary · Prageeth Manoratne".
 *
 * @param int $term Term ID.
 */
function rcobeca_committee_term_title( int $term ): string {
	return implode(
		' · ',
		array(
			rcobeca_club_year_label( (int) get_post_meta( $term, 'rcobeca_club_year', true ) ),
			(string) get_post_meta( $term, 'rcobeca_role', true ),
			rcobeca_person_name( (int) get_post_meta( $term, 'rcobeca_person', true ) ),
		)
	);
}

/**
 * Sort rank of a role; roles outside the usual list come after Committee Member.
 *
 * @param string $role Role.
 */
function rcobeca_role_rank( string $role ): int {
	return rcobeca_committee_roles()[ $role ] ?? 70;
}
