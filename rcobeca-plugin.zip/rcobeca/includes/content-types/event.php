<?php
/**
 * The Event content type (GLOSSARY: Event, Royal Charity Ball).
 *
 * An Event is a dated RCOBECA gathering with a type: Royal Charity Ball,
 * Cricket Festival or Other. Royal Charity Ball Events carry the Ball fields
 * too (edition, artists, prices, cause, funds raised, deductible portion,
 * Souvenir Journal, sponsors) and the Ball state the /ball/ page shows.
 * Everything is post meta registered for the REST API, so the records survive
 * a theme change and the block editor can read and write them.
 *
 * @package RCOBECA
 */

namespace RCOBECA;

defined( 'ABSPATH' ) || exit;

/**
 * Registers the post type and its fields.
 */
function register_event_type(): void {
	register_post_type(
		Events::POST_TYPE,
		array(
			'labels'        => array(
				'name'               => __( 'Events', 'rcobeca' ),
				'singular_name'      => __( 'Event', 'rcobeca' ),
				'add_new_item'       => __( 'Add New Event', 'rcobeca' ),
				'edit_item'          => __( 'Edit Event', 'rcobeca' ),
				'new_item'           => __( 'New Event', 'rcobeca' ),
				'view_item'          => __( 'View Event', 'rcobeca' ),
				'search_items'       => __( 'Search Events', 'rcobeca' ),
				'not_found'          => __( 'No Events found.', 'rcobeca' ),
				'not_found_in_trash' => __( 'No Events found in Trash.', 'rcobeca' ),
				'all_items'          => __( 'All Events', 'rcobeca' ),
				'menu_name'          => __( 'Events', 'rcobeca' ),
			),
			'description'   => __( 'Dated RCOBECA gatherings: Royal Charity Balls, Cricket Festivals and other events.', 'rcobeca' ),
			'public'        => true,
			'has_archive'   => false,
			'show_in_rest'  => true,
			'menu_icon'     => 'dashicons-calendar-alt',
			'menu_position' => 21,
			'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'revisions' ),
			'rewrite'       => array(
				'slug'       => 'events',
				'with_front' => false,
			),
		)
	);

	foreach ( Events::fields() as $key => $field ) {
		register_post_meta(
			Events::POST_TYPE,
			$key,
			array(
				'type'              => $field['type'],
				'single'            => true,
				'default'           => 'integer' === $field['type'] ? 0 : '',
				'show_in_rest'      => true,
				'sanitize_callback' => array( Events::class, 'sanitize_' . $field['type'] ),
				'auth_callback'     => static fn() => current_user_can( 'edit_posts' ),
			)
		);
	}
}
add_action( 'init', __NAMESPACE__ . '\register_event_type' );

/*
 * A Royal Charity Ball with real content lives at /ball/<year>/, under the
 * permanent Ball page; other Events at /events/<slug>/.
 */
add_action( 'init', array( Events::class, 'add_rewrite_rules' ) );
add_filter( 'query_vars', array( Events::class, 'query_vars' ) );
add_filter( 'request', array( Events::class, 'resolve_ball_year' ) );
add_filter( 'post_type_link', array( Events::class, 'permalink' ), 10, 2 );
add_action( 'template_redirect', array( Events::class, 'canonical_ball_url' ), 1 );
