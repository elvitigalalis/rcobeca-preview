<?php
/**
 * Financial document: a file RCOBECA publishes for transparency (IRS
 * determination letter, annual report, Form 990 and others), filed under a
 * Club Year and listed on the Transparency page. Documents have no page of
 * their own; the listing links straight to the file.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

const RCOBECA_DOCUMENT = 'rcobeca_document';

/**
 * Kinds of financial document: slug => label.
 *
 * @return array<string, string>
 */
function rcobeca_document_types(): array {
	return array(
		'determination-letter' => __( 'IRS determination letter', 'rcobeca' ),
		'annual-report'        => __( 'Annual report', 'rcobeca' ),
		'form-990'             => __( 'Form 990', 'rcobeca' ),
		'financial-statement'  => __( 'Financial statement', 'rcobeca' ),
		'other'                => __( 'Other', 'rcobeca' ),
	);
}

/**
 * Registers the Financial document post type and its fields.
 */
function rcobeca_register_document(): void {
	register_post_type(
		RCOBECA_DOCUMENT,
		array(
			'labels'             => array(
				'name'          => __( 'Financial documents', 'rcobeca' ),
				'singular_name' => __( 'Financial document', 'rcobeca' ),
				'add_new_item'  => __( 'Add New Financial document', 'rcobeca' ),
				'edit_item'     => __( 'Edit Financial document', 'rcobeca' ),
				'all_items'     => __( 'Financial documents', 'rcobeca' ),
				'not_found'     => __( 'No financial documents yet.', 'rcobeca' ),
			),
			'description'        => __( 'Files listed on the Transparency page by Club Year.', 'rcobeca' ),
			'public'             => false,
			'show_ui'            => true,
			'show_in_rest'       => true,
			'publicly_queryable' => false,
			'menu_icon'          => 'dashicons-media-spreadsheet',
			'supports'           => array( 'title', 'custom-fields' ),
		)
	);

	$fields = array(
		// The PDF, an attachment in the media library.
		'rcobeca_file_id'   => array( 'integer', static fn( $id ) => 'attachment' === get_post_type( absint( $id ) ) ? absint( $id ) : 0 ),
		// The Club Year's starting year: 2025 for 2025–26.
		'rcobeca_club_year' => array( 'integer', static fn( $year ) => absint( $year ) >= 1993 && absint( $year ) <= 2100 ? absint( $year ) : 0 ),
		'rcobeca_doc_type'  => array( 'string', static fn( $type ) => isset( rcobeca_document_types()[ $type ] ) ? $type : 'other' ),
	);
	foreach ( $fields as $key => [ $type, $sanitize ] ) {
		register_post_meta(
			RCOBECA_DOCUMENT,
			$key,
			array(
				'type'              => $type,
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => $sanitize,
				'auth_callback'     => static fn() => current_user_can( 'edit_posts' ),
			)
		);
	}
}
add_action( 'init', 'rcobeca_register_document' );

/**
 * Adds the document form (the type uses a plain form, not the block editor:
 * see rcobeca_plain_record_forms()).
 */
function rcobeca_document_meta_box(): void {
	add_meta_box( 'rcobeca-document', __( 'Document', 'rcobeca' ), 'rcobeca_document_form', RCOBECA_DOCUMENT, 'normal', 'high' );
	// The fields are in the form; the raw Custom Fields box would only confuse.
	remove_meta_box( 'postcustom', RCOBECA_DOCUMENT, 'normal' );
}
add_action( 'add_meta_boxes', 'rcobeca_document_meta_box' );

/**
 * The form: the PDF from the media library, its Club Year and its type.
 *
 * @param WP_Post $post Document.
 */
function rcobeca_document_form( WP_Post $post ): void {
	wp_nonce_field( 'rcobeca_document', 'rcobeca_document_nonce' );
	$file = (int) get_post_meta( $post->ID, 'rcobeca_file_id', true );
	$year = get_post_meta( $post->ID, 'rcobeca_club_year', true );
	$kind = (string) get_post_meta( $post->ID, 'rcobeca_doc_type', true );
	$pdfs = get_posts(
		array(
			'post_type'      => 'attachment',
			'post_mime_type' => 'application/pdf',
			'post_status'    => 'inherit',
			'posts_per_page' => -1,
		)
	);
	?>
	<table class="form-table" role="presentation">
		<tr>
			<th scope="row"><label for="rcobeca-file-id"><?php esc_html_e( 'File (PDF)', 'rcobeca' ); ?></label></th>
			<td>
				<select id="rcobeca-file-id" name="rcobeca_file_id" required>
					<option value=""><?php esc_html_e( '— Choose a PDF —', 'rcobeca' ); ?></option>
					<?php foreach ( $pdfs as $pdf ) : ?>
						<option value="<?php echo esc_attr( (string) $pdf->ID ); ?>"<?php selected( $file, $pdf->ID ); ?>><?php echo esc_html( get_the_title( $pdf ) . ' (' . wp_basename( (string) get_attached_file( $pdf->ID ) ) . ')' ); ?></option>
					<?php endforeach; ?>
				</select>
				<p class="description">
					<?php esc_html_e( 'Upload the PDF first under Media → Add New, then choose it here.', 'rcobeca' ); ?>
				</p>
			</td>
		</tr>
		<tr>
			<th scope="row"><label for="rcobeca-doc-club-year"><?php esc_html_e( 'Club Year (starting year)', 'rcobeca' ); ?></label></th>
			<td>
				<input type="number" id="rcobeca-doc-club-year" name="rcobeca_club_year" min="1993" max="2100" value="<?php echo esc_attr( (string) $year ); ?>" required>
				<p class="description"><?php esc_html_e( 'The year the Club Year starts: 2025 for Club Year 2025–26.', 'rcobeca' ); ?></p>
			</td>
		</tr>
		<tr>
			<th scope="row"><label for="rcobeca-doc-type"><?php esc_html_e( 'Type', 'rcobeca' ); ?></label></th>
			<td>
				<select id="rcobeca-doc-type" name="rcobeca_doc_type">
					<?php foreach ( rcobeca_document_types() as $slug => $label ) : ?>
						<option value="<?php echo esc_attr( $slug ); ?>"<?php selected( $kind, $slug ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</td>
		</tr>
	</table>
	<?php
}

/**
 * Saves the form.
 *
 * @param int $post_id Document ID.
 */
function rcobeca_save_document( int $post_id ): void {
	if ( ! isset( $_POST['rcobeca_document_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['rcobeca_document_nonce'] ), 'rcobeca_document' ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	update_post_meta( $post_id, 'rcobeca_file_id', absint( $_POST['rcobeca_file_id'] ?? 0 ) );
	update_post_meta( $post_id, 'rcobeca_club_year', absint( $_POST['rcobeca_club_year'] ?? 0 ) );
	update_post_meta( $post_id, 'rcobeca_doc_type', sanitize_key( wp_unslash( $_POST['rcobeca_doc_type'] ?? '' ) ) );
}
add_action( 'save_post_' . RCOBECA_DOCUMENT, 'rcobeca_save_document' );

/**
 * Published documents grouped by Club Year, newest year first. A document
 * without a file or a Club Year is left out.
 *
 * @return array<int, array<int, array{title: string, url: string, type: string, size: string}>>
 */
function rcobeca_documents_by_club_year(): array {
	$years = array();
	foreach ( get_posts(
		array(
			'post_type'      => RCOBECA_DOCUMENT,
			'posts_per_page' => -1,
			'orderby'        => 'title',
			'order'          => 'ASC',
		)
	) as $document ) {
		$year = (int) get_post_meta( $document->ID, 'rcobeca_club_year', true );
		$file = (int) get_post_meta( $document->ID, 'rcobeca_file_id', true );
		$url  = $file ? (string) wp_get_attachment_url( $file ) : '';
		if ( $year && '' !== $url ) {
			$path             = (string) get_attached_file( $file );
			$years[ $year ][] = array(
				'title' => get_the_title( $document ),
				'url'   => $url,
				'type'  => (string) get_post_meta( $document->ID, 'rcobeca_doc_type', true ),
				'size'  => is_file( $path ) ? (string) size_format( (int) filesize( $path ), 1 ) : '',
			);
		}
	}
	krsort( $years );
	return $years;
}
