<?php
/**
 * Life Member: a name on the honour roll, the date he became a Life Member,
 * whether he has died, and optionally the Person he is. The roll's "as of"
 * date is a setting of the Life Members block on the page.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registers the Life Member content type and its fields.
 */
function rcobeca_register_life_member(): void {
	register_post_type(
		'rcobeca_life_member',
		array(
			'labels'               => array(
				'name'          => __( 'Life Members', 'rcobeca' ),
				'singular_name' => __( 'Life Member', 'rcobeca' ),
				'add_new'       => __( 'Add Life Member', 'rcobeca' ),
				'add_new_item'  => __( 'Add Life Member', 'rcobeca' ),
				'edit_item'     => __( 'Edit Life Member', 'rcobeca' ),
				'search_items'  => __( 'Search Life Members', 'rcobeca' ),
				'not_found'     => __( 'No Life Members found.', 'rcobeca' ),
			),
			'description'          => __( 'Names on the Life Members honour roll.', 'rcobeca' ),
			'public'               => false,
			'show_ui'              => true,
			'show_in_rest'         => true,
			'menu_icon'            => 'dashicons-heart',
			'menu_position'        => 23,
			'supports'             => array( 'title', 'custom-fields' ),
			'register_meta_box_cb' => 'rcobeca_life_member_meta_box',
		)
	);
	$fields = array(
		'rcobeca_person'       => array( 'integer', __( 'Person ID, if he is recorded as a Person', 'rcobeca' ) ),
		'rcobeca_member_since' => array( 'string', __( 'Date he became a Life Member, YYYY-MM-DD', 'rcobeca' ) ),
		'rcobeca_deceased'     => array( 'string', __( '"1" if he has died', 'rcobeca' ) ),
	);
	foreach ( $fields as $key => [ $type, $description ] ) {
		register_post_meta(
			'rcobeca_life_member',
			$key,
			array(
				'type'         => $type,
				'description'  => $description,
				'single'       => true,
				'show_in_rest' => true,
			)
		);
	}
}
add_action( 'init', 'rcobeca_register_life_member' );

/**
 * The title field holds the name as the roll shows it.
 *
 * @param string  $text Placeholder.
 * @param WP_Post $post Post.
 */
function rcobeca_life_member_title_placeholder( string $text, WP_Post $post ): string {
	return 'rcobeca_life_member' === $post->post_type ? __( 'Name as shown on the roll, e.g. Dr. Miran Salgado', 'rcobeca' ) : $text;
}
add_filter( 'enter_title_here', 'rcobeca_life_member_title_placeholder', 10, 2 );

/**
 * Adds the Life Member form.
 */
function rcobeca_life_member_meta_box(): void {
	add_meta_box( 'rcobeca-life-member', __( 'Life Member', 'rcobeca' ), 'rcobeca_life_member_form', 'rcobeca_life_member', 'normal', 'high' );
}

/**
 * The Life Member form.
 *
 * @param WP_Post $post Life Member being edited.
 */
function rcobeca_life_member_form( WP_Post $post ): void {
	$person = (int) get_post_meta( $post->ID, 'rcobeca_person', true );
	wp_nonce_field( 'rcobeca_life_member', 'rcobeca_life_member_nonce' );
	?>
	<table class="form-table" role="presentation">
		<tr>
			<th scope="row"><label for="rcobeca-member-since"><?php esc_html_e( 'Life Member since', 'rcobeca' ); ?></label></th>
			<td><input type="date" id="rcobeca-member-since" name="rcobeca_member_since" value="<?php echo esc_attr( (string) get_post_meta( $post->ID, 'rcobeca_member_since', true ) ); ?>" required></td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'Deceased', 'rcobeca' ); ?></th>
			<td><label><input type="checkbox" name="rcobeca_deceased" value="1" <?php checked( '1', (string) get_post_meta( $post->ID, 'rcobeca_deceased', true ) ); ?>> <?php esc_html_e( 'He has died (the roll marks his name with an asterisk)', 'rcobeca' ); ?></label></td>
		</tr>
		<tr>
			<th scope="row"><label for="rcobeca-life-person"><?php esc_html_e( 'Person (optional)', 'rcobeca' ); ?></label></th>
			<td>
				<select id="rcobeca-life-person" name="rcobeca_person">
					<option value="0"><?php esc_html_e( '— Not linked —', 'rcobeca' ); ?></option>
					<?php
					foreach ( get_posts(
						array(
							'post_type'      => 'rcobeca_person',
							'posts_per_page' => -1,
							'orderby'        => 'title',
							'order'          => 'ASC',
						)
					) as $option ) {
						printf( '<option value="%d"%s>%s</option>', (int) $option->ID, selected( $person, $option->ID, false ), esc_html( rcobeca_person_name( $option->ID ) ) );
					}
					?>
				</select>
				<p class="description"><?php esc_html_e( 'Link him to his Person record so his profile shows his Life Membership.', 'rcobeca' ); ?></p>
			</td>
		</tr>
	</table>
	<?php
}

/**
 * Saves the form.
 *
 * @param int $post_id Life Member ID.
 */
function rcobeca_save_life_member( int $post_id ): void {
	if ( ! isset( $_POST['rcobeca_life_member_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['rcobeca_life_member_nonce'] ), 'rcobeca_life_member' ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	update_post_meta( $post_id, 'rcobeca_member_since', sanitize_text_field( wp_unslash( $_POST['rcobeca_member_since'] ?? '' ) ) );
	update_post_meta( $post_id, 'rcobeca_deceased', isset( $_POST['rcobeca_deceased'] ) ? '1' : '' );
	update_post_meta( $post_id, 'rcobeca_person', absint( $_POST['rcobeca_person'] ?? 0 ) );
}
add_action( 'save_post_rcobeca_life_member', 'rcobeca_save_life_member' );

/**
 * The published Life Members, earliest first (then in roll order).
 *
 * @return WP_Post[]
 */
function rcobeca_life_members(): array {
	$members = get_posts(
		array(
			'post_type'      => 'rcobeca_life_member',
			'posts_per_page' => -1,
			'orderby'        => array(
				'menu_order' => 'ASC',
				'ID'         => 'ASC',
			),
		)
	);
	usort( $members, static fn( $a, $b ) => (string) get_post_meta( $a->ID, 'rcobeca_member_since', true ) <=> (string) get_post_meta( $b->ID, 'rcobeca_member_since', true ) );
	return $members;
}

/**
 * When a Person became a Life Member ("18 June 2010"), or "" if he isn't one.
 *
 * @param int $person Person ID.
 */
function rcobeca_life_member_since( int $person ): string {
	foreach ( rcobeca_life_members() as $member ) {
		if ( (int) get_post_meta( $member->ID, 'rcobeca_person', true ) === $person ) {
			$date = (string) get_post_meta( $member->ID, 'rcobeca_member_since', true );
			return '' !== $date ? wp_date( 'j F Y', (int) strtotime( $date . ' 12:00 UTC' ) ) : __( 'date not recorded', 'rcobeca' );
		}
	}
	return '';
}
