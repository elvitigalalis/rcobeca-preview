<?php
/**
 * Person: an Old Boy recorded once, however many roles he has held. A Person
 * has a public profile only when he has a bio (post content) or a photo
 * (featured image); otherwise his name is shown as plain text and his URL is
 * a 404.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registers the Person content type and its fields.
 */
function rcobeca_register_person(): void {
	register_post_type(
		'rcobeca_person',
		array(
			'labels'              => array(
				'name'               => __( 'People', 'rcobeca' ),
				'singular_name'      => __( 'Person', 'rcobeca' ),
				'add_new_item'       => __( 'Add Person', 'rcobeca' ),
				'edit_item'          => __( 'Edit Person', 'rcobeca' ),
				'search_items'       => __( 'Search People', 'rcobeca' ),
				'not_found'          => __( 'No people found.', 'rcobeca' ),
				'featured_image'     => __( 'Photo', 'rcobeca' ),
				'set_featured_image' => __( 'Set photo', 'rcobeca' ),
			),
			'description'         => __( 'Old Boys, each recorded once. The bio (content) and photo (featured image) are optional; a profile page exists only when one of them is set.', 'rcobeca' ),
			'public'              => true,
			'exclude_from_search' => true,
			'show_in_rest'        => true,
			'menu_icon'           => 'dashicons-groups',
			'menu_position'       => 22,
			'supports'            => array( 'title', 'editor', 'thumbnail', 'custom-fields' ),
			'has_archive'         => false,
			'rewrite'             => array(
				'slug'       => 'people',
				'with_front' => false,
			),
		)
	);

	$fields = array(
		'rcobeca_honorific'     => __( 'Honorific shown before the name when there are no post-nominals, e.g. Dr.', 'rcobeca' ),
		'rcobeca_post_nominals' => __( 'Post-nominals, e.g. MD or PE, Ph.D.', 'rcobeca' ),
		'rcobeca_batch_year'    => __( 'Royal College batch year, e.g. 1985', 'rcobeca' ),
	);
	foreach ( $fields as $key => $description ) {
		register_post_meta(
			'rcobeca_person',
			$key,
			array(
				'type'              => 'string',
				'description'       => $description,
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_text_field',
			)
		);
	}
}
add_action( 'init', 'rcobeca_register_person' );

/**
 * Whether a Person has a public profile: a bio or a photo.
 *
 * @param int $person Person ID.
 */
function rcobeca_person_has_profile( int $person ): bool {
	return 'publish' === get_post_status( $person )
		&& ( '' !== trim( wp_strip_all_tags( (string) get_post_field( 'post_content', $person ) ) ) || has_post_thumbnail( $person ) );
}

/**
 * A Person's name as displayed: "Sudath Rannulu, MD", or "Dr. Ramesh
 * Ramanathan" when only an honorific is known.
 *
 * @param int $person Person ID.
 */
function rcobeca_person_name( int $person ): string {
	$name      = get_the_title( $person );
	$suffix    = (string) get_post_meta( $person, 'rcobeca_post_nominals', true );
	$honorific = (string) get_post_meta( $person, 'rcobeca_honorific', true );
	if ( '' !== $suffix ) {
		return "$name, $suffix";
	}
	return '' !== $honorific ? "$honorific $name" : $name;
}

/**
 * A Person's name as HTML, linked to the profile only when there is one.
 *
 * @param int $person Person ID.
 */
function rcobeca_person_link( int $person ): string {
	$name = esc_html( rcobeca_person_name( $person ) );
	return rcobeca_person_has_profile( $person )
		? '<a class="rcobeca-person-link" href="' . esc_url( get_permalink( $person ) ) . '">' . $name . '</a>'
		: $name;
}

/**
 * No empty profile pages: a Person without a bio or photo is not found.
 */
function rcobeca_person_profile_or_404(): void {
	if ( is_singular( 'rcobeca_person' ) && ! rcobeca_person_has_profile( get_queried_object_id() ) ) {
		global $wp_query;
		$wp_query->set_404();
		status_header( 404 );
		nocache_headers();
	}
}
add_action( 'template_redirect', 'rcobeca_person_profile_or_404', 5 );

/**
 * The sitemap lists only People who have a profile.
 *
 * @param array  $args Query arguments.
 * @param string $post_type Post type.
 * @return array
 */
function rcobeca_person_sitemap_args( array $args, string $post_type ): array {
	if ( 'rcobeca_person' === $post_type ) {
		$ids              = get_posts(
			array(
				'post_type'      => 'rcobeca_person',
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);
		$args['post__in'] = array_merge( array( 0 ), array_values( array_filter( $ids, 'rcobeca_person_has_profile' ) ) );
	}
	return $args;
}
add_filter( 'wp_sitemaps_posts_query_args', 'rcobeca_person_sitemap_args', 10, 2 );
