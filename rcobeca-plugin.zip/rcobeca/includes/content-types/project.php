<?php
/**
 * Project: a charitable initiative RCOBECA funds (GLOSSARY), with its status,
 * beneficiary, place, date, amount, dated status timeline and, while it is
 * Fundraising, its Zeffy campaign and progress figures.
 *
 * Fields are post meta registered for the REST API (so the editor, the
 * importer and the Zeffy sync in #5 share one definition) and edited in the
 * "Project details" box (project-details-box.php). Money is stored in US cents.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

const RCOBECA_PROJECT = 'rcobeca_project';

/**
 * Project statuses, in lifecycle order: slug => label.
 *
 * @return array<string, string>
 */
function rcobeca_project_statuses(): array {
	return array(
		'fundraising' => __( 'Fundraising', 'rcobeca' ),
		'ongoing'     => __( 'Ongoing', 'rcobeca' ),
		'completed'   => __( 'Completed', 'rcobeca' ),
	);
}

/**
 * Who a Project helps: slug => label.
 *
 * @return array<string, string>
 */
function rcobeca_project_beneficiaries(): array {
	return array(
		'royal-college'    => __( 'Royal College', 'rcobeca' ),
		'sri-lanka-relief' => __( 'Sri Lanka relief', 'rcobeca' ),
		'us-communities'   => __( 'US communities', 'rcobeca' ),
	);
}

/**
 * Every Project field: meta key => [type, label, help]. Keys are what the
 * importer, the REST API and the Zeffy sync (#5) read and write.
 *
 * @return array<string, array{type: string, label: string, help: string}>
 */
function rcobeca_project_fields(): array {
	return array(
		'rcobeca_status'                => array( 'string', __( 'Status', 'rcobeca' ), '' ),
		'rcobeca_beneficiary'           => array( 'string', __( 'Beneficiary', 'rcobeca' ), '' ),
		'rcobeca_place'                 => array( 'string', __( 'Place', 'rcobeca' ), __( 'Where the work happened, e.g. "Royal College, Colombo".', 'rcobeca' ) ),
		'rcobeca_date'                  => array( 'string', __( 'Date', 'rcobeca' ), __( 'When it was delivered (or opened for giving): YYYY, YYYY-MM or YYYY-MM-DD.', 'rcobeca' ) ),
		'rcobeca_amount_cents'          => array( 'integer', __( 'Amount delivered (US$)', 'rcobeca' ), __( 'Cost or amount delivered in dollars, if known.', 'rcobeca' ) ),
		'rcobeca_amount_text'           => array( 'string', __( 'Amount as written', 'rcobeca' ), __( 'Use instead of dollars for other currencies or wording, e.g. "Rs 15 million".', 'rcobeca' ) ),
		'rcobeca_timeline'              => array( 'string', __( 'Timeline', 'rcobeca' ), __( 'One step per line: date | label | sentence, e.g. "2017-08-01 | Completed | The bridge was opened."', 'rcobeca' ) ),
		'rcobeca_zeffy_campaign_id'     => array( 'string', __( 'Zeffy campaign ID', 'rcobeca' ), __( 'Fundraising only: the Zeffy form this Project’s progress syncs from. Once the Zeffy API key is set, pick it from the list by its title.', 'rcobeca' ) ),
		'rcobeca_zeffy_form_url'        => array( 'string', __( 'Zeffy form link', 'rcobeca' ), __( 'Fundraising only: the campaign’s Share link, embedded on the Project page.', 'rcobeca' ) ),
		'rcobeca_goal_cents'            => array( 'integer', __( 'Goal (US$)', 'rcobeca' ), __( 'The progress bar shows only when a goal is set. Each sync copies the Zeffy form’s goal here when the form has one.', 'rcobeca' ) ),
		'rcobeca_raised_cents'          => array( 'integer', __( 'Raised, synced from Zeffy (US$)', 'rcobeca' ), __( 'Written by the Zeffy sync.', 'rcobeca' ) ),
		'rcobeca_raised_synced_at'      => array( 'integer', __( 'Last synced', 'rcobeca' ), '' ),
		'rcobeca_raised_override_cents' => array( 'integer', __( 'Raised, manual override (US$)', 'rcobeca' ), __( 'Replaces the synced figure while set. Clear it to go back to Zeffy’s figure.', 'rcobeca' ) ),
		'rcobeca_raised_override_at'    => array( 'integer', __( 'Override set', 'rcobeca' ), '' ),
		'rcobeca_zeffy_sync_error'      => array( 'string', __( 'Last sync problem', 'rcobeca' ), __( 'Written by the Zeffy sync when it could not read the campaign; cleared by the next good read.', 'rcobeca' ) ),

	);
}

/**
 * Registers the Project post type and its fields.
 */
function rcobeca_register_project(): void {
	register_post_type(
		RCOBECA_PROJECT,
		array(
			'labels'       => array(
				'name'          => __( 'Projects', 'rcobeca' ),
				'singular_name' => __( 'Project', 'rcobeca' ),
				'add_new_item'  => __( 'Add New Project', 'rcobeca' ),
				'edit_item'     => __( 'Edit Project', 'rcobeca' ),
				'view_item'     => __( 'View Project', 'rcobeca' ),
				'all_items'     => __( 'All Projects', 'rcobeca' ),
				'search_items'  => __( 'Search Projects', 'rcobeca' ),
				'not_found'     => __( 'No Projects found.', 'rcobeca' ),
			),
			'description'  => __( 'Charitable initiatives RCOBECA funds, for Royal College and relief in Sri Lanka and the US.', 'rcobeca' ),
			'public'       => true,
			'show_in_rest' => true,
			'menu_icon'    => 'dashicons-heart',
			'has_archive'  => 'projects',
			'rewrite'      => array(
				'slug'       => 'projects',
				'with_front' => false,
			),
			'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'revisions' ),
		)
	);

	foreach ( rcobeca_project_fields() as $key => [ $type ] ) {
		$synced = in_array( $key, rcobeca_project_synced_fields(), true );
		register_post_meta(
			RCOBECA_PROJECT,
			$key,
			array(
				'type'              => $type,
				'single'            => true,
				'show_in_rest'      => 'rcobeca_status' === $key
					? array( 'schema' => array( 'enum' => array_keys( rcobeca_project_statuses() ) ) )
					: true,
				'sanitize_callback' => rcobeca_project_sanitizer( $key, $type ),
				// The Zeffy sync (and the Project details box) write these with
				// update_post_meta(); nobody writes them through the REST API.
				'auth_callback'     => $synced ? '__return_false' : static fn() => current_user_can( 'edit_posts' ),
			)
		);
	}
}
add_action( 'init', 'rcobeca_register_project' );

/**
 * Fields the Zeffy sync owns (with the time an override was set, which the
 * Project details box stamps): never written through the REST API, and read
 * there only by people who can edit the Project.
 *
 * @return string[]
 */
function rcobeca_project_synced_fields(): array {
	return array( 'rcobeca_raised_cents', 'rcobeca_raised_synced_at', 'rcobeca_zeffy_sync_error', 'rcobeca_zeffy_campaign_id', 'rcobeca_raised_override_at' );
}

/**
 * How a field is cleaned before it is stored (from the REST API, the Project
 * details box, the importer or the Zeffy sync alike).
 *
 * @param string $key  Meta key.
 * @param string $type string or integer.
 */
function rcobeca_project_sanitizer( string $key, string $type ): callable {
	if ( 'integer' === $type ) {
		return 'absint';
	}
	switch ( $key ) {
		case 'rcobeca_status':
			return static fn( $value ) => isset( rcobeca_project_statuses()[ $value ] ) ? $value : 'completed';
		case 'rcobeca_beneficiary':
			return static fn( $value ) => isset( rcobeca_project_beneficiaries()[ $value ] ) ? $value : '';
		case 'rcobeca_date':
			return static fn( $value ) => preg_match( '/^\d{4}(-\d{2}(-\d{2})?)?$/', trim( (string) $value ) ) ? trim( (string) $value ) : '';
		case 'rcobeca_zeffy_form_url':
			return static fn( $value ) => esc_url_raw( trim( (string) $value ), array( 'http', 'https' ) );
		case 'rcobeca_timeline':
			return static fn( $value ) => sanitize_textarea_field( (string) $value );
		default:
			return static fn( $value ) => sanitize_text_field( (string) $value );
	}
}

/**
 * Leaves the sync's fields out of a Project read over the REST API by anyone
 * who can't edit it.
 *
 * @param WP_REST_Response $response Response.
 * @param WP_Post          $post     Project.
 */
function rcobeca_project_hide_synced_fields( WP_REST_Response $response, WP_Post $post ): WP_REST_Response {
	$data = $response->get_data();
	if ( isset( $data['meta'] ) && ! current_user_can( 'edit_post', $post->ID ) ) {
		$data['meta'] = array_diff_key( $data['meta'], array_flip( rcobeca_project_synced_fields() ) );
		$response->set_data( $data );
	}
	return $response;
}
add_filter( 'rest_prepare_' . RCOBECA_PROJECT, 'rcobeca_project_hide_synced_fields', 10, 2 );

/**
 * A Project's status slug (Completed when unset).
 *
 * @param int $id Project ID.
 */
function rcobeca_project_status( int $id ): string {
	$status = (string) get_post_meta( $id, 'rcobeca_status', true );
	return isset( rcobeca_project_statuses()[ $status ] ) ? $status : 'completed';
}
