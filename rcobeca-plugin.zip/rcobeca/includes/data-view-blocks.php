<?php
/**
 * One editor script for every data-view block (a block whose block.json sets
 * "editorScript": "rcobeca-data-view-blocks"): a server-rendered preview plus
 * sidebar inputs for the attributes that carry a "label".
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registers the shared editor script before the blocks that use it.
 */
function rcobeca_register_data_view_script(): void {
	$fields = array();
	foreach ( glob( RCOBECA_DIR . '/blocks/*/block.json' ) as $file ) {
		$block = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local file.
		if ( 'rcobeca-data-view-blocks' !== ( $block['editorScript'] ?? '' ) ) {
			continue;
		}
		$fields[ $block['name'] ] = (object) array();
		foreach ( $block['attributes'] ?? array() as $key => $attribute ) {
			if ( isset( $attribute['label'] ) ) {
				$fields[ $block['name'] ]->$key = array_intersect_key( $attribute, array_flip( array( 'label', 'help', 'type' ) ) );
			}
		}
	}
	wp_register_script(
		'rcobeca-data-view-blocks',
		plugins_url( 'assets/data-view-blocks.js', RCOBECA_DIR . '/rcobeca.php' ),
		array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render' ),
		RCOBECA_VERSION,
		true
	);
	wp_add_inline_script( 'rcobeca-data-view-blocks', 'window.rcobecaDataViewBlocks = ' . wp_json_encode( $fields ) . ';', 'before' );
}
add_action( 'init', 'rcobeca_register_data_view_script', 5 );
