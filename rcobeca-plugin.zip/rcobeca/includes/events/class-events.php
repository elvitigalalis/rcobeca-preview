<?php
/**
 * Events and Royal Charity Balls: the fields, queries and rules every Events
 * view (listing, Ball page, Past Balls, per-year pages) shares.
 *
 * @package RCOBECA
 */

namespace RCOBECA;

defined( 'ABSPATH' ) || exit;

/**
 * Read access to Event records, plus the URL rules for Balls.
 */
class Events {

	public const POST_TYPE = 'rcobeca_event';

	public const BALL = 'royal-charity-ball';

	/**
	 * Event types, slug => label.
	 */
	public const TYPES = array(
		'royal-charity-ball' => 'Royal Charity Ball',
		'cricket-festival'   => 'Cricket Festival',
		'other'              => 'Other',
	);

	/**
	 * The Royal Charity Ball page's states, in cycle order.
	 */
	public const SAVE_THE_DATE = 'save-the-date';
	public const ON_SALE       = 'on-sale';
	public const SOLD_OUT      = 'sold-out';
	public const BALL_NIGHT    = 'ball-night';
	public const THANK_YOU     = 'thank-you';
	public const BETWEEN       = 'between';

	/**
	 * Each state as a volunteer picks it in the Event details box.
	 */
	public const STATES = array(
		self::SAVE_THE_DATE => 'Save the date',
		self::ON_SALE       => 'Tickets on sale',
		self::SOLD_OUT      => 'Sold out',
		self::BALL_NIGHT    => 'Ball night (Table Lookup)',
		self::THANK_YOU     => 'Thank you and recap',
		self::BETWEEN       => 'Between Balls (next Ball to be announced)',
	);

	/**
	 * States that sell or promote an evening still to come. Once the Ball's
	 * date has passed they fall back to the recap, so the page never sells
	 * last year's tickets even if nobody changes the state.
	 */
	private const BEFORE_STATES = array( self::SAVE_THE_DATE, self::ON_SALE, self::SOLD_OUT, self::BALL_NIGHT );

	/**
	 * Ball night lasts until this hour (site time) the morning after the Ball.
	 */
	private const NIGHT_ENDS_HOURS = 6;

	/**
	 * Every Event field: meta key => type, label, whether it is for Balls only, and help.
	 *
	 * @return array<string, array{type: string, label: string, ball: bool, help: string}>
	 */
	public static function fields(): array {
		$field = static fn( string $label, bool $ball = false, string $help = '', string $type = 'string' ) => array(
			'type'  => $type,
			'label' => $label,
			'ball'  => $ball,
			'help'  => $help,
		);
		return array(
			'rcobeca_event_type'     => $field( __( 'Type', 'rcobeca' ) ),
			'rcobeca_date'           => $field( __( 'Date', 'rcobeca' ), false, __( 'YYYY-MM-DD. If only the month or year is known, use the 1st and set the precision.', 'rcobeca' ) ),
			'rcobeca_date_precision' => $field( __( 'Date known to the', 'rcobeca' ), false, __( 'day, month or year', 'rcobeca' ) ),
			'rcobeca_time'           => $field( __( 'Time', 'rcobeca' ), false, __( 'e.g. 6 PM to midnight', 'rcobeca' ) ),
			'rcobeca_venue'          => $field( __( 'Venue', 'rcobeca' ) ),
			'rcobeca_address'        => $field( __( 'Address', 'rcobeca' ) ),
			'rcobeca_ticket_url'     => $field( __( 'Zeffy ticket form link', 'rcobeca' ), false, __( 'From Zeffy’s Share menu.', 'rcobeca' ) ),
			'rcobeca_ticket_prices'  => $field( __( 'Ticket prices', 'rcobeca' ), false, __( 'e.g. $150 per person; tables of 10 $1,500', 'rcobeca' ) ),
			'rcobeca_photos_url'     => $field( __( 'Photo album link', 'rcobeca' ) ),
			'rcobeca_video_url'      => $field( __( 'Video link', 'rcobeca' ) ),

			'rcobeca_ball_state'     => $field( __( 'Ball page state', 'rcobeca' ), true ),
			'rcobeca_edition'        => $field( __( 'Edition', 'rcobeca' ), true, __( 'e.g. 30 for the 30th Ball', 'rcobeca' ), 'integer' ),
			'rcobeca_artists'        => $field( __( 'Artists and entertainment', 'rcobeca' ), true ),
			'rcobeca_cause'          => $field( __( 'Beneficiary', 'rcobeca' ), true ),
			'rcobeca_funds_raised'   => $field( __( 'Funds raised', 'rcobeca' ), true, __( 'e.g. $8,000', 'rcobeca' ) ),
			'rcobeca_deductible'     => $field( __( 'Tax-deductible portion per ticket', 'rcobeca' ), true, __( 'e.g. $90 of each $150 ticket', 'rcobeca' ) ),
			'rcobeca_journal'        => $field( __( 'Souvenir Journal PDF (attachment ID)', 'rcobeca' ), true, '', 'integer' ),
			'rcobeca_ad_tiers'       => $field( __( 'Sponsorship and Souvenir Journal ad tiers', 'rcobeca' ), true, __( 'One per line: Tier name | price | the tier’s Zeffy purchase link', 'rcobeca' ) ),
			'rcobeca_ad_url'         => $field( __( 'Zeffy link for sponsorships and ads', 'rcobeca' ), true, __( 'Only for tiers without their own link above.', 'rcobeca' ) ),
			'rcobeca_ad_deadline'    => $field( __( 'Ad copy deadline', 'rcobeca' ), true, __( 'YYYY-MM-DD', 'rcobeca' ) ),
			'rcobeca_ad_specs'       => $field( __( 'Ad specifications', 'rcobeca' ), true, __( 'One per line', 'rcobeca' ) ),
			'rcobeca_sponsors'       => $field( __( 'Sponsors by tier', 'rcobeca' ), true, __( 'One tier per line: Tier: Name, Name', 'rcobeca' ) ),
			'rcobeca_sponsors_as_of' => $field( __( 'Sponsor list as of', 'rcobeca' ), true, __( 'YYYY-MM-DD', 'rcobeca' ) ),
		);
	}

	/**
	 * Sanitizes a text field, keeping line breaks.
	 *
	 * @param mixed $value Value.
	 */
	public static function sanitize_string( $value ): string {
		return sanitize_textarea_field( (string) $value );
	}

	/**
	 * Sanitizes a number field.
	 *
	 * @param mixed $value Value.
	 */
	public static function sanitize_integer( $value ): int {
		return absint( $value );
	}

	/**
	 * A field's value.
	 *
	 * @param int    $id Event ID.
	 * @param string $key Field name without the rcobeca_ prefix, e.g. "venue".
	 */
	public static function get( int $id, string $key ): string {
		return trim( (string) get_post_meta( $id, 'rcobeca_' . $key, true ) );
	}

	/**
	 * The Event's type slug (defaults to other).
	 *
	 * @param int $id Event ID.
	 */
	public static function type( int $id ): string {
		$type = self::get( $id, 'event_type' );
		return isset( self::TYPES[ $type ] ) ? $type : 'other';
	}

	/**
	 * Whether an Event is a Royal Charity Ball.
	 *
	 * @param int $id Event ID.
	 */
	public static function is_ball( int $id ): bool {
		return self::BALL === self::type( $id );
	}

	/**
	 * The Event's year.
	 *
	 * @param int $id Event ID.
	 */
	public static function year( int $id ): int {
		return (int) substr( self::get( $id, 'date' ), 0, 4 );
	}

	/**
	 * Whether an Event has its own page. Every Event does, except a Ball
	 * known only from a line of history (no details, photos or journal):
	 * those are rows on Past Balls only.
	 *
	 * @param int $id Event ID.
	 */
	public static function has_page( int $id ): bool {
		if ( ! self::is_ball( $id ) ) {
			return true;
		}
		$content = (string) get_post_field( 'post_content', $id );
		return '' !== trim( wp_strip_all_tags( preg_replace( '/<!--.*?-->/s', '', $content ) ) ) || str_contains( $content, '<img' );
	}

	/**
	 * The date as visitors read it, as precise as it is known:
	 * "Saturday, April 25, 2026", "June 2017" or "2010".
	 *
	 * @param int $id Event ID.
	 */
	public static function date_label( int $id ): string {
		$date = self::get( $id, 'date' );
		if ( '' === $date ) {
			return __( 'Date to be announced', 'rcobeca' );
		}
		$time = strtotime( $date . ' 12:00:00 UTC' );
		switch ( self::get( $id, 'date_precision' ) ) {
			case 'year':
				return gmdate( 'Y', $time );
			case 'month':
				return gmdate( 'F Y', $time );
			default:
				return gmdate( 'l, F j, Y', $time );
		}
	}

	/**
	 * The short date for listings: "Apr 25" with the year shown separately,
	 * or the month or year when that is all that is known.
	 *
	 * @param int $id Event ID.
	 */
	public static function short_date( int $id ): string {
		$date = self::get( $id, 'date' );
		if ( '' === $date ) {
			return __( 'Date TBA', 'rcobeca' );
		}
		$time = strtotime( $date . ' 12:00:00 UTC' );
		switch ( self::get( $id, 'date_precision' ) ) {
			case 'year':
				return gmdate( 'Y', $time );
			case 'month':
				return gmdate( 'F Y', $time );
			default:
				return gmdate( 'M j, Y', $time );
		}
	}

	/**
	 * "30th" for 30.
	 *
	 * @param int $number Number.
	 */
	public static function ordinal( int $number ): string {
		$suffix = 'th';
		if ( ! in_array( $number % 100, array( 11, 12, 13 ), true ) ) {
			$suffix = array(
				1 => 'st',
				2 => 'nd',
				3 => 'rd',
			)[ $number % 10 ] ?? 'th';
		}
		return $number . $suffix;
	}

	/**
	 * Published Events in date order.
	 *
	 * @param array $args {
	 *     Optional.
	 *     @type string $type  Only this type.
	 *     @type string $order ASC (oldest first, default) or DESC.
	 * }
	 * @return int[] Event IDs.
	 */
	public static function query( array $args = array() ): array {
		$query = array(
			'post_type'      => self::POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_key'       => 'rcobeca_date', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'orderby'        => array(
				'meta_value' => 'DESC' === ( $args['order'] ?? 'ASC' ) ? 'DESC' : 'ASC', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'title'      => 'ASC',
			),
		);
		if ( ! empty( $args['type'] ) ) {
			$query['meta_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				array(
					'key'   => 'rcobeca_event_type',
					'value' => $args['type'],
				),
			);
		}
		return array_map( 'intval', get_posts( $query ) );
	}

	/**
	 * Whether an Event is still to come (today counts as upcoming).
	 *
	 * @param int      $id Event ID.
	 * @param int|null $now Timestamp; defaults to now.
	 */
	public static function is_upcoming( int $id, ?int $now = null ): bool {
		$date = self::get( $id, 'date' );
		if ( '' === $date ) {
			return true;
		}
		$today = wp_date( 'Y-m-d', $now ?? time() );
		switch ( self::get( $id, 'date_precision' ) ) {
			case 'year':
				return substr( $date, 0, 4 ) >= substr( $today, 0, 4 );
			case 'month':
				return substr( $date, 0, 7 ) >= substr( $today, 0, 7 );
			default:
				return $date >= $today;
		}
	}

	/**
	 * Upcoming Events, soonest first.
	 *
	 * @param string $type Only this type.
	 * @return int[]
	 */
	public static function upcoming( string $type = '' ): array {
		return array_values( array_filter( self::query( array( 'type' => $type ) ), array( self::class, 'is_upcoming' ) ) );
	}

	/**
	 * Past Events, most recent first.
	 *
	 * @param string $type Only this type.
	 * @return int[]
	 */
	public static function past( string $type = '' ): array {
		return array_values(
			array_filter(
				self::query(
					array(
						'type'  => $type,
						'order' => 'DESC',
					)
				),
				static fn( $id ) => ! self::is_upcoming( $id )
			)
		);
	}

	/**
	 * Every Royal Charity Ball, newest first.
	 *
	 * @return int[]
	 */
	public static function balls(): array {
		return self::query(
			array(
				'type'  => self::BALL,
				'order' => 'DESC',
			)
		);
	}

	/**
	 * The Ball the /ball/ page is about: the newest one.
	 */
	public static function current_ball(): int {
		return self::balls()[0] ?? 0;
	}

	/**
	 * The Ball whose per-year page is /ball/<year>/.
	 *
	 * @param int $year Year.
	 */
	public static function ball_for_year( int $year ): int {
		foreach ( self::balls() as $id ) {
			if ( self::year( $id ) === $year ) {
				return $id;
			}
		}
		return 0;
	}

	/**
	 * The state the Ball page shows. The volunteer's choice, except that a
	 * pre-Ball state falls back to "thank-you" once the Ball's date has passed.
	 * Ball night runs past midnight, so it lasts until 06:00 the next
	 * morning, site time.
	 *
	 * @param int      $id Ball Event ID.
	 * @param int|null $now Timestamp; defaults to now.
	 */
	public static function state( int $id, ?int $now = null ): string {
		$now   = $now ?? time();
		$state = self::get( $id, 'ball_state' );
		if ( ! isset( self::STATES[ $state ] ) ) {
			$state = self::is_upcoming( $id, $now ) ? self::SAVE_THE_DATE : self::BETWEEN;
		}
		$day_of = self::BALL_NIGHT === $state ? $now - self::NIGHT_ENDS_HOURS * HOUR_IN_SECONDS : $now;
		if ( in_array( $state, self::BEFORE_STATES, true ) && ! self::is_upcoming( $id, $day_of ) ) {
			$state = self::THANK_YOU;
		}
		return $state;
	}

	/**
	 * What visitors read for a state, above the Ball's name on the Ball page
	 * and the home page's Ball band: "Tonight", "Every year since 1994".
	 *
	 * @param string $state A state.
	 */
	public static function state_label( string $state ): string {
		$first = self::first_ball_year();
		return array(
			self::SAVE_THE_DATE => __( 'Save the date', 'rcobeca' ),
			self::ON_SALE       => __( 'Tickets on sale', 'rcobeca' ),
			self::SOLD_OUT      => __( 'Sold out', 'rcobeca' ),
			self::BALL_NIGHT    => __( 'Tonight', 'rcobeca' ),
			self::THANK_YOU     => __( 'Thank you', 'rcobeca' ),
			/* translators: %d: year of the first Ball. */
			self::BETWEEN       => $first ? sprintf( __( 'Every year since %d', 'rcobeca' ), $first ) : __( 'Our flagship evening', 'rcobeca' ),
		)[ $state ] ?? '';
	}

	/**
	 * The year of the first Ball on record.
	 */
	public static function first_ball_year(): int {
		$years = array_filter( array_map( array( self::class, 'year' ), self::balls() ) );
		return $years ? min( $years ) : 0;
	}

	/**
	 * A Ball's name by its edition, "The 31st Royal Charity Ball", or "The
	 * Royal Charity Ball" when its edition isn't known.
	 *
	 * @param int $id Ball Event ID (0: none).
	 */
	public static function edition_title( int $id ): string {
		$edition = $id ? (int) self::get( $id, 'edition' ) : 0;
		/* translators: %s: ordinal edition, e.g. 31st. */
		return $edition ? sprintf( __( 'The %s Royal Charity Ball', 'rcobeca' ), self::ordinal( $edition ) ) : __( 'The Royal Charity Ball', 'rcobeca' );
	}

	/**
	 * Lines of a multi-line field, trimmed, empty ones dropped.
	 *
	 * @param int    $id Event ID.
	 * @param string $key Field name without the prefix.
	 * @return string[]
	 */
	public static function lines( int $id, string $key ): array {
		return array_values( array_filter( array_map( 'trim', explode( "\n", self::get( $id, $key ) ) ), 'strlen' ) );
	}

	/**
	 * Sponsors by tier, from "Tier: Name, Name" lines.
	 *
	 * @param int $id Ball Event ID.
	 * @return array<string, string[]> Tier => names.
	 */
	public static function sponsors( int $id ): array {
		$tiers = array();
		foreach ( self::lines( $id, 'sponsors' ) as $line ) {
			[ $tier, $names ] = array_pad( explode( ':', $line, 2 ), 2, '' );
			$names            = array_values( array_filter( array_map( 'trim', explode( ',', $names ) ), 'strlen' ) );
			if ( $names ) {
				$tiers[ trim( $tier ) ] = $names;
			}
		}
		return $tiers;
	}

	/**
	 * Ad and sponsorship tiers, from "Name | price | Zeffy link" lines. Each
	 * tier has its own Zeffy purchase link; a link that isn't Zeffy's is left
	 * out.
	 *
	 * @param int $id Ball Event ID.
	 * @return array<int, array{name: string, price: string, url: string}>
	 */
	public static function ad_tiers( int $id ): array {
		$tiers = array();
		foreach ( self::lines( $id, 'ad_tiers' ) as $line ) {
			[ $name, $price, $url ] = array_pad( array_map( 'trim', explode( '|', $line, 3 ) ), 3, '' );
			$url                    = null !== rcobeca_zeffy_link( $url ) ? $url : '';
			$tiers[]                = compact( 'name', 'price', 'url' );
		}
		return $tiers;
	}

	/**
	 * The Souvenir Journal PDF's URL, if there is one.
	 *
	 * @param int $id Ball Event ID.
	 */
	public static function journal_url( int $id ): string {
		$attachment = (int) self::get( $id, 'journal' );
		return $attachment ? (string) wp_get_attachment_url( $attachment ) : '';
	}

	/**
	 * The label above an Event's title: "30th Royal Charity Ball", or its type.
	 *
	 * @param int $id Event ID.
	 */
	public static function kicker( int $id ): string {
		$edition = (int) self::get( $id, 'edition' );
		if ( self::is_ball( $id ) && $edition ) {
			/* translators: %s: ordinal edition, e.g. 30th. */
			return sprintf( __( '%s Royal Charity Ball', 'rcobeca' ), self::ordinal( $edition ) );
		}
		return 'other' === self::type( $id ) ? __( 'Event', 'rcobeca' ) : self::TYPES[ self::type( $id ) ];
	}

	/**
	 * Where an Event was held, on one line: "The Royal Manor, Garfield, New Jersey".
	 *
	 * @param int $id Event ID.
	 */
	public static function place( int $id ): string {
		return implode( ', ', array_filter( array( self::get( $id, 'venue' ), self::get( $id, 'address' ) ), 'strlen' ) );
	}

	/**
	 * The labelled facts of an Event, for details cards: label => inline HTML.
	 * Only facts that are known are included.
	 *
	 * @param int  $id Event ID.
	 * @param bool $links Include the photo, video and journal links.
	 * @return array<string, string>
	 */
	public static function details( int $id, bool $links = true ): array {
		$rows                            = array();
		$time                            = self::get( $id, 'time' );
		$rows[ __( 'Date', 'rcobeca' ) ] = esc_html( self::date_label( $id ) ) . ( '' !== $time ? '<br>' . esc_html( $time ) : '' );
		if ( '' !== self::get( $id, 'venue' ) ) {
			$where   = esc_html( self::get( $id, 'venue' ) ) . ( '' !== self::get( $id, 'address' ) ? '<br>' . esc_html( self::get( $id, 'address' ) ) : '' );
			$address = self::get( $id, 'address' );
			if ( preg_match( '/\d/', $address ) ) {
				$where .= '<br><a href="' . esc_url( 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( self::place( $id ) ) ) . '">' . esc_html__( 'Map', 'rcobeca' ) . '</a>';
			}
			$rows[ __( 'Venue', 'rcobeca' ) ] = $where;
		}
		$plain = array(
			'artists'       => __( 'Music', 'rcobeca' ),
			'ticket_prices' => __( 'Tickets', 'rcobeca' ),
			'deductible'    => __( 'Tax-deductible', 'rcobeca' ),
			'cause'         => __( 'In aid of', 'rcobeca' ),
			'funds_raised'  => __( 'Raised', 'rcobeca' ),
		);
		if ( self::is_upcoming( $id ) ) {
			unset( $plain['funds_raised'] );
		}
		foreach ( $plain as $key => $label ) {
			if ( '' !== self::get( $id, $key ) ) {
				$rows[ $label ] = esc_html( self::get( $id, $key ) );
			}
		}
		if ( $links ) {
			$journal = self::journal_url( $id );
			if ( '' !== $journal ) {
				$size                                        = size_format( (int) filesize( (string) get_attached_file( (int) self::get( $id, 'journal' ) ) ), 0 );
				$rows[ __( 'Souvenir Journal', 'rcobeca' ) ] = '<a href="' . esc_url( $journal ) . '">' . esc_html__( 'Read the journal', 'rcobeca' ) . '</a> <span class="rcobeca-filetype">(PDF' . ( $size ? ', ' . esc_html( $size ) : '' ) . ')</span>';
			}
			$media = array();
			foreach ( array(
				'photos_url' => __( 'Photos', 'rcobeca' ),
				'video_url'  => __( 'Video', 'rcobeca' ),
			) as $key => $label ) {
				$url = '' !== self::get( $id, $key ) ? self::live_link( self::get( $id, $key ) ) : '';
				if ( '' !== $url ) {
					$media[] = '<a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
				}
			}
			if ( $media ) {
				$rows[ __( 'Photos and video', 'rcobeca' ) ] = implode( ' · ', $media );
			}
		}
		return $rows;
	}

	/**
	 * A stored external link, through the dead-link map (its Wayback snapshot
	 * when the original is gone).
	 *
	 * @param string $url URL.
	 */
	public static function live_link( string $url ): string {
		static $links = null;
		$links      ??= new Importer\Links();
		$result       = $links->rewrite( $url );
		return Importer\Links::UNAVAILABLE === $result['action'] ? '' : $result['href'];
	}

	/**
	 * Adds the /ball/<year>/ rule ahead of the page rules.
	 */
	public static function add_rewrite_rules(): void {
		add_rewrite_rule( '^ball/([0-9]{4})/?$', 'index.php?rcobeca_ball_year=$matches[1]', 'top' );
	}

	/**
	 * Allows the Ball year query variable.
	 *
	 * @param string[] $vars Public query variables.
	 * @return string[]
	 */
	public static function query_vars( array $vars ): array {
		$vars[] = 'rcobeca_ball_year';
		return $vars;
	}

	/**
	 * Turns /ball/<year>/ into that year's Ball, or a 404 when no Ball of
	 * that year has a page.
	 *
	 * @param array $vars Request query variables.
	 */
	public static function resolve_ball_year( array $vars ): array {
		if ( empty( $vars['rcobeca_ball_year'] ) ) {
			return $vars;
		}
		$id = self::ball_for_year( (int) $vars['rcobeca_ball_year'] );
		if ( ! $id || ! self::has_page( $id ) ) {
			return array( 'error' => '404' );
		}
		return array(
			'post_type'         => self::POST_TYPE,
			'p'                 => $id,
			'rcobeca_ball_year' => $vars['rcobeca_ball_year'],
		);
	}

	/**
	 * A Ball's URL is /ball/<year>/.
	 *
	 * @param string   $link Default permalink.
	 * @param \WP_Post $post Post.
	 */
	public static function permalink( string $link, \WP_Post $post ): string {
		if ( self::POST_TYPE !== $post->post_type || ! self::is_ball( $post->ID ) || ! self::year( $post->ID ) ) {
			return $link;
		}
		if ( ! self::has_page( $post->ID ) ) {
			return home_url( '/ball/past/#ball-' . self::year( $post->ID ) );
		}
		return home_url( '/ball/' . self::year( $post->ID ) . '/' );
	}

	/**
	 * Sends a Ball reached by its /events/<slug>/ address to /ball/<year>/,
	 * or to its row on Past Balls when it has no page of its own.
	 */
	public static function canonical_ball_url(): void {
		if ( ! is_singular( self::POST_TYPE ) || get_query_var( 'rcobeca_ball_year' ) ) {
			return;
		}
		$id = (int) get_queried_object_id();
		if ( ! self::is_ball( $id ) ) {
			return;
		}
		wp_safe_redirect( (string) get_permalink( $id ), 301, 'RCOBECA' );
		exit;
	}
}
