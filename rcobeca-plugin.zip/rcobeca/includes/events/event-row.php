<?php
/**
 * One Event as a listing row (Princeton's events list): date, type or Ball
 * edition, linked title, place and a thumbnail. Used by the Events listing;
 * other listings (the home page's upcoming Events) can use it too.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

use RCOBECA\Events;

/**
 * The row's HTML.
 *
 * @param int $id Event ID.
 * @param int $level Heading level of the title.
 */
function rcobeca_event_row( int $id, int $level = 3 ): string {
	$link  = (string) get_permalink( $id );
	$place = Events::place( $id );
	$thumb = has_post_thumbnail( $id ) ? get_the_post_thumbnail(
		$id,
		'medium',
		array(
			'alt'     => '',
			'loading' => 'lazy',
		)
	) : '';
	$level = max( 2, min( 6, $level ) );

	$html  = '<article class="rcobeca-event-row' . ( $thumb ? ' has-image' : '' ) . '">';
	$html .= '<p class="rcobeca-event-row__when"><time datetime="' . esc_attr( Events::get( $id, 'date' ) ) . '">' . esc_html( Events::short_date( $id ) ) . '</time></p>';
	$html .= '<div class="rcobeca-event-row__text">';
	$html .= '<p class="rcobeca-event-row__kicker">' . esc_html( Events::kicker( $id ) ) . '</p>';
	$html .= "<h$level class=\"rcobeca-event-row__title\"><a href=\"" . esc_url( $link ) . '">' . esc_html( get_the_title( $id ) ) . "</a></h$level>";
	if ( '' !== $place ) {
		$html .= '<p class="rcobeca-event-row__place">' . esc_html( $place ) . '</p>';
	}

	$html .= '</div>';
	if ( $thumb ) {
		$html .= '<a class="rcobeca-event-row__image" href="' . esc_url( $link ) . '" tabindex="-1" aria-hidden="true">' . $thumb . '</a>';
	}
	return $html . '</article>';
}
