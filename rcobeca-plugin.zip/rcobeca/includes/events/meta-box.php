<?php
/**
 * The "Event details" box on the Event edit screen: every Event field in one
 * plain form, with the Royal Charity Ball fields (including the Ball page
 * state) in their own section.
 *
 * @package RCOBECA
 */

namespace RCOBECA;

defined( 'ABSPATH' ) || exit;

/**
 * Adds the box.
 */
function add_event_meta_box(): void {
	add_meta_box( 'rcobeca-event-details', __( 'Event details', 'rcobeca' ), __NAMESPACE__ . '\render_event_meta_box', Events::POST_TYPE, 'normal', 'high' );
}
add_action( 'add_meta_boxes', __NAMESPACE__ . '\add_event_meta_box' );

/**
 * Renders the box.
 *
 * @param \WP_Post $post Event.
 */
function render_event_meta_box( \WP_Post $post ): void {
	wp_nonce_field( 'rcobeca_event_details', 'rcobeca_event_nonce' );
	$choices = array(
		'rcobeca_event_type'     => Events::TYPES,
		'rcobeca_date_precision' => array(
			'day'   => __( 'day', 'rcobeca' ),
			'month' => __( 'month', 'rcobeca' ),
			'year'  => __( 'year', 'rcobeca' ),
		),
		'rcobeca_ball_state'     => array( '' => __( 'Automatic', 'rcobeca' ) ) + Events::STATES,
	);
	$long    = array( 'rcobeca_artists', 'rcobeca_cause', 'rcobeca_ad_tiers', 'rcobeca_ad_specs', 'rcobeca_sponsors', 'rcobeca_ticket_prices' );
	$section = '';
	echo '<table class="form-table" role="presentation"><tbody>';
	foreach ( Events::fields() as $key => $field ) {
		if ( $field['ball'] && 'ball' !== $section ) {
			$section = 'ball';
			echo '<tr><th colspan="2"><h3 style="margin:1em 0 0">' . esc_html__( 'Royal Charity Ball only', 'rcobeca' ) . '</h3><p class="description" style="font-weight:400">' . esc_html__( 'The Ball page (/ball/) shows the newest Ball in the state chosen here. Sold-out and earlier states turn into the thank-you recap by themselves once the date has passed.', 'rcobeca' ) . '</p></th></tr>';
		}
		$value = (string) get_post_meta( $post->ID, $key, true );
		echo '<tr><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $field['label'] ) . '</label></th><td>';
		if ( isset( $choices[ $key ] ) ) {
			echo '<select id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '">';
			foreach ( $choices[ $key ] as $option => $label ) {
				echo '<option value="' . esc_attr( $option ) . '"' . selected( $value, (string) $option, false ) . '>' . esc_html( $label ) . '</option>';
			}
			echo '</select>';
		} elseif ( in_array( $key, $long, true ) ) {
			echo '<textarea class="large-text" rows="3" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '">' . esc_textarea( $value ) . '</textarea>';
		} else {
			echo '<input class="regular-text" type="text" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '">';
		}
		if ( 'rcobeca_journal' === $key && (int) $value ) {
			echo ' <a href="' . esc_url( (string) wp_get_attachment_url( (int) $value ) ) . '">' . esc_html( get_the_title( (int) $value ) ) . '</a>';
		}
		if ( '' !== $field['help'] ) {
			echo '<p class="description">' . esc_html( $field['help'] ) . '</p>';
		}
		echo '</td></tr>';
	}
	echo '</tbody></table>';
}

/**
 * Saves the box.
 *
 * @param int $post_id Event ID.
 */
function save_event_meta_box( int $post_id ): void {
	if ( ! isset( $_POST['rcobeca_event_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['rcobeca_event_nonce'] ), 'rcobeca_event_details' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	foreach ( Events::fields() as $key => $field ) {
		$value = isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized by the field's callback below.
		$clean = call_user_func( array( Events::class, 'sanitize_' . $field['type'] ), $value );
		if ( '' === $clean || 0 === $clean ) {
			delete_post_meta( $post_id, $key );
		} else {
			update_post_meta( $post_id, $key, $clean );
		}
	}
}
add_action( 'save_post_' . Events::POST_TYPE, __NAMESPACE__ . '\save_event_meta_box' );
