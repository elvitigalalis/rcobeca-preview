<?php
/**
 * The form handler behind the Contact and Update Your Details forms.
 *
 * @package RCOBECA
 */

namespace RCOBECA;

/**
 * Small server-side forms that email an @rcobeca.org address (the Secretary
 * by default) and store nothing. A form posts back to the page it is on; a
 * valid submission is emailed and answered with a redirect to the page's
 * thank-you state, an invalid one re-renders the page with its errors.
 *
 * Spam protection: a honeypot field people never see (filled in, the
 * submission is dropped but looks sent) and a per-visitor rate limit.
 * Rendered by the rcobeca/form block.
 */
class Forms {

	/** Name of the honeypot field. */
	public const HONEYPOT = 'website';

	/**
	 * Errors and values of the submission being re-rendered, by form.
	 *
	 * @var array<string, array{errors: array<string, string>, values: array<string, mixed>}>
	 */
	private static array $state = array();

	/**
	 * The forms, their fields and where they send.
	 *
	 * Field keys: label, type (text, email, tel, year, select, textarea,
	 * checkboxes), required, hint, autocomplete, options
	 * (select: label => recipient; checkboxes: labels), error (when empty).
	 *
	 * @return array<string, array>
	 */
	public static function definitions(): array {
		$secretary = 'secretary@rcobeca.org';
		$forms     = array(
			'contact'        => array(
				'label'   => __( 'Contact form', 'rcobeca' ),
				'submit'  => __( 'Send message', 'rcobeca' ),
				'subject' => __( 'Contact form', 'rcobeca' ),
				'to'      => $secretary,
				'thanks'  => __( 'Your message is on its way. A committee member will reply by email, usually within a few days.', 'rcobeca' ),
				'fields'  => array(
					'name'    => array(
						'label'        => __( 'Name', 'rcobeca' ),
						'required'     => true,
						'autocomplete' => 'name',
						'error'        => __( 'Enter your name', 'rcobeca' ),
					),
					'email'   => array(
						'label'        => __( 'Email', 'rcobeca' ),
						'type'         => 'email',
						'required'     => true,
						'autocomplete' => 'email',
						'error'        => __( 'Enter your email address', 'rcobeca' ),
					),
					'batch'   => array(
						'label' => __( 'Royal College batch year (optional)', 'rcobeca' ),
						'type'  => 'year',
						'hint'  => __( 'If you are an Old Boy: the year your batch goes by, for example 1989.', 'rcobeca' ),
					),
					'topic'   => array(
						'label'    => __( 'What is it about?', 'rcobeca' ),
						'type'     => 'select',
						'required' => true,
						'options'  => array(
							__( 'General question', 'rcobeca' )             => $secretary,
							__( 'Membership and Life Members', 'rcobeca' )  => $secretary,
							__( 'Donations, dues and receipts', 'rcobeca' ) => 'treasurer@rcobeca.org',
							__( 'Royal Charity Ball', 'rcobeca' )           => $secretary,
							__( 'Souvenir Journal advertising', 'rcobeca' ) => 'AdCopy@rcobeca.org',
						),
						'error'    => __( 'Choose what your message is about', 'rcobeca' ),
					),
					'message' => array(
						'label'    => __( 'Message', 'rcobeca' ),
						'type'     => 'textarea',
						'required' => true,
						'error'    => __( 'Write your message', 'rcobeca' ),
					),
				),
			),
			'update-details' => array(
				'label'   => __( 'Update your details form', 'rcobeca' ),
				'submit'  => __( 'Send my details', 'rcobeca' ),
				'subject' => __( 'Updated details', 'rcobeca' ),
				'to'      => $secretary,
				'thanks'  => __( 'Your details are on their way to the Secretary, who keeps RCOBECA’s records. Thank you for keeping in touch.', 'rcobeca' ),
				'fields'  => array(
					'name'       => array(
						'label'        => __( 'Full name', 'rcobeca' ),
						'required'     => true,
						'autocomplete' => 'name',
						'error'        => __( 'Enter your full name', 'rcobeca' ),
					),
					'batch'      => array(
						'label'    => __( 'Royal College batch year', 'rcobeca' ),
						'type'     => 'year',
						'required' => true,
						'hint'     => __( 'The year your batch goes by, for example 1989.', 'rcobeca' ),
						'error'    => __( 'Enter your Royal College batch year', 'rcobeca' ),
					),
					'email'      => array(
						'label'        => __( 'Email', 'rcobeca' ),
						'type'         => 'email',
						'required'     => true,
						'autocomplete' => 'email',
						'error'        => __( 'Enter your email address', 'rcobeca' ),
					),
					'phone'      => array(
						'label'        => __( 'Phone (optional)', 'rcobeca' ),
						'type'         => 'tel',
						'autocomplete' => 'tel',
					),
					'city'       => array(
						'label' => __( 'City and state (optional)', 'rcobeca' ),
						'hint'  => __( 'For example Edison, NJ.', 'rcobeca' ),
					),
					'activities' => array(
						'label' => __( 'Sports and activities at Royal College (optional)', 'rcobeca' ),
						'type'  => 'textarea',
					),
					'help'       => array(
						'label'   => __( 'I would like to help with (optional)', 'rcobeca' ),
						'type'    => 'checkboxes',
						'options' => array(
							__( 'Social events', 'rcobeca' ),
							__( 'The Royal Charity Ball', 'rcobeca' ),
							__( 'Sports', 'rcobeca' ),
							__( 'Fundraising and Projects', 'rcobeca' ),
							__( 'Networking', 'rcobeca' ),
						),
					),
					'changes'    => array(
						'label' => __( 'What has changed? (optional)', 'rcobeca' ),
						'type'  => 'textarea',
						'hint'  => __( 'A new address, a new email, or anything else the committee should know.', 'rcobeca' ),
					),
				),
			),
		);

		/**
		 * Filters the forms, e.g. to route a topic to a different address.
		 *
		 * @param array $forms Form definitions.
		 */
		return apply_filters( 'rcobeca_forms', $forms );
	}

	/**
	 * Handles a submission posted to any page, before the page renders.
	 */
	public static function handle(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- public forms for logged-out visitors; spam is handled by the honeypot and rate limit.
		if ( ! isset( $_SERVER['REQUEST_METHOD'] ) || 'POST' !== $_SERVER['REQUEST_METHOD'] || empty( $_POST['rcobeca_form'] ) ) {
			return;
		}
		$form  = sanitize_key( wp_unslash( $_POST['rcobeca_form'] ) );
		$input = isset( $_POST['rcobeca'] ) && is_array( $_POST['rcobeca'] ) ? map_deep( wp_unslash( $_POST['rcobeca'] ), 'sanitize_textarea_field' ) : array();
		// phpcs:enable
		$definition = self::definitions()[ $form ] ?? null;
		if ( ! $definition ) {
			return;
		}

		$result = self::submit( $form, $input, Rate_Limit::client_ip() );
		if ( true === $result ) {
			wp_safe_redirect( add_query_arg( 'sent', $form, self::current_url() ) . '#' . self::id( $form ), 303 );
			exit;
		}
		self::$state[ $form ] = array(
			'errors' => $result,
			'values' => $input,
		);
	}

	/**
	 * Validates a submission and, if it is good, emails it.
	 *
	 * @param string $form Form name.
	 * @param array  $input Submitted values, by field.
	 * @param string $visitor Who sent it, for the rate limit (an IP address).
	 * @return true|array<string, string> True when handled; else errors by field ('form' for the whole form).
	 */
	public static function submit( string $form, array $input, string $visitor ): bool|array {
		$definition = self::definitions()[ $form ];

		// A bot filled the field people never see: drop it, but look as if it was sent.
		if ( '' !== trim( (string) ( $input[ self::HONEYPOT ] ?? '' ) ) ) {
			return true;
		}

		$errors = self::validate( $definition['fields'], $input );
		if ( $errors ) {
			return $errors;
		}

		if ( ! self::within_rate_limit( $visitor ) ) {
			return array( 'form' => __( 'You have sent several messages in a short time. Please wait a while and try again, or email secretary@rcobeca.org.', 'rcobeca' ) );
		}

		$sent = wp_mail(
			self::recipient( $definition, $input ),
			self::subject( $definition, $input ),
			self::body( $definition, $input ),
			array( 'Reply-To: ' . self::header_safe( $input['name'] ) . ' <' . $input['email'] . '>' )
		);
		if ( ! $sent ) {
			return array( 'form' => __( 'Sorry, your message could not be sent. Please email secretary@rcobeca.org instead.', 'rcobeca' ) );
		}
		return true;
	}

	/**
	 * Errors and values of the submission being re-rendered, if any.
	 *
	 * @param string $form Form name.
	 * @return array{errors: array<string, string>, values: array<string, mixed>}
	 */
	public static function state( string $form ): array {
		return self::$state[ $form ] ?? array(
			'errors' => array(),
			'values' => array(),
		);
	}

	/**
	 * Whether the page is showing a form's thank-you state.
	 *
	 * @param string $form Form name.
	 */
	public static function sent( string $form ): bool {
		return isset( $_GET['sent'] ) && sanitize_key( wp_unslash( $_GET['sent'] ) ) === $form; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display state only.
	}

	/**
	 * The HTML id of a form's region, used for links and focus.
	 *
	 * @param string $form Form name.
	 */
	public static function id( string $form ): string {
		return 'rcobeca-' . $form;
	}

	/**
	 * Checks required fields and formats.
	 *
	 * @param array $fields Field definitions.
	 * @param array $input Submitted values.
	 * @return array<string, string> Errors by field, in form order.
	 */
	private static function validate( array $fields, array $input ): array {
		$errors = array();
		foreach ( $fields as $key => $field ) {
			$value = $input[ $key ] ?? '';
			$type  = $field['type'] ?? 'text';
			if ( is_array( $value ) ) {
				if ( 'checkboxes' !== $type || array_diff( $value, $field['options'] ) ) {
					$errors[ $key ] = __( 'Choose from the options shown', 'rcobeca' );
				}
				continue;
			}
			$value = trim( $value );
			if ( '' === $value ) {
				if ( ! empty( $field['required'] ) ) {
					$errors[ $key ] = $field['error'];
				}
				continue;
			}
			if ( 'email' === $type && ! is_email( $value ) ) {
				$errors[ $key ] = __( 'Enter an email address like name@example.com', 'rcobeca' );
			} elseif ( 'year' === $type && ( ! preg_match( '/^\d{4}$/', $value ) || (int) $value < 1900 || (int) $value > (int) gmdate( 'Y' ) ) ) {
				$errors[ $key ] = __( 'Enter the batch year as a four-digit year, for example 1989', 'rcobeca' );
			} elseif ( 'select' === $type && ! array_key_exists( $value, $field['options'] ) ) {
				$errors[ $key ] = $field['error'];
			} elseif ( mb_strlen( $value ) > ( 'textarea' === $type ? 5000 : 200 ) ) {
				$errors[ $key ] = __( 'This is too long; please shorten it', 'rcobeca' );
			}
		}
		return $errors;
	}

	/**
	 * Allows a few submissions per visitor in a rolling window, and counts this one.
	 *
	 * @param string $visitor Visitor key (an IP address).
	 */
	private static function within_rate_limit( string $visitor ): bool {
		/**
		 * Filters how many messages one visitor may send in a window.
		 *
		 * @param array{max: int, window: int} $limit Messages, and window in seconds.
		 */
		$limit = apply_filters(
			'rcobeca_form_rate_limit',
			array(
				'max'    => 5,
				'window' => 15 * MINUTE_IN_SECONDS,
			)
		);
		return Rate_Limit::allow( 'form', $visitor, $limit );
	}

	/**
	 * Where a submission goes: the chosen topic's address, else the form's.
	 *
	 * @param array $definition Form definition.
	 * @param array $input Submitted values.
	 */
	private static function recipient( array $definition, array $input ): string {
		return $definition['fields']['topic']['options'][ $input['topic'] ?? '' ] ?? $definition['to'];
	}

	/**
	 * The email subject: the form, the topic and who sent it.
	 *
	 * @param array $definition Form definition.
	 * @param array $input Submitted values.
	 */
	private static function subject( array $definition, array $input ): string {
		$parts = array_filter( array( $definition['subject'], $input['topic'] ?? '' ) );
		$who   = self::header_safe( $input['name'] ) . ( ! empty( $input['batch'] ) ? ' (' . $input['batch'] . ')' : '' );
		return implode( ': ', $parts ) . ' from ' . $who;
	}

	/**
	 * The email body: every answered field as "Label: value", then the page it came from.
	 *
	 * @param array $definition Form definition.
	 * @param array $input Submitted values.
	 */
	private static function body( array $definition, array $input ): string {
		$lines = array();
		foreach ( $definition['fields'] as $key => $field ) {
			$value = $input[ $key ] ?? '';
			$label = (string) preg_replace( '/ \(optional\)$/', '', $field['label'] );
			$value = is_array( $value ) ? implode( ', ', $value ) : trim( $value );
			if ( '' === $value ) {
				continue;
			}
			$lines[] = 'textarea' === ( $field['type'] ?? '' ) ? "\n$label:\n$value\n" : "$label: $value";
		}
		/* translators: %s: URL of the page with the form. */
		$lines[] = "\n--\n" . sprintf( __( 'Sent from %s. Reply to this email to answer.', 'rcobeca' ), self::current_url() );
		return implode( "\n", $lines );
	}

	/**
	 * Text safe to put in a mail header.
	 *
	 * @param string $text Text.
	 */
	private static function header_safe( string $text ): string {
		return trim( (string) preg_replace( '/[\r\n<>",]+/', ' ', $text ) );
	}

	/**
	 * The URL of the page the form is on.
	 */
	private static function current_url(): string {
		$id = get_queried_object_id();
		return $id ? (string) get_permalink( $id ) : home_url( '/' );
	}
}

add_action( 'template_redirect', array( Forms::class, 'handle' ), 1 );
