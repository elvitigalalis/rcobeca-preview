<?php
/**
 * Smaller pages: WordPress writes the resized copies of JPEG and PNG uploads
 * (the sizes listings, cards and srcset use) as WebP, typically a third to
 * two thirds lighter; the uploaded original keeps its format. A server
 * without WebP support keeps writing JPEG and PNG.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Maps JPEG and PNG to WebP for resized copies only. A resized copy is saved
 * without a file name (WordPress names it), while a save to a named file (the
 * importer's in-place recompression) keeps its format and extension.
 *
 * @param array<string, string> $formats Input MIME type => output MIME type.
 * @param string|null           $filename File being saved, if named.
 * @return array<string, string>
 */
function rcobeca_webp_sub_sizes( array $formats, $filename ): array {
	// The Playground preview turns this off: encoding WebP in the browser makes its import a minute slower.
	if ( ! empty( $filename ) || ( defined( 'RCOBECA_WEBP_SIZES' ) && ! RCOBECA_WEBP_SIZES ) ) {
		return $formats;
	}
	return array_merge(
		array(
			'image/jpeg' => 'image/webp',
			'image/png'  => 'image/webp',
		),
		$formats
	);
}
add_filter( 'image_editor_output_format', 'rcobeca_webp_sub_sizes', 10, 2 );

/**
 * WebP quality 78 (WordPress uses 86): no visible loss on photos at screen
 * sizes, a fifth smaller.
 *
 * @param int    $quality Quality, 1 to 100.
 * @param string $mime_type Output MIME type.
 */
function rcobeca_webp_quality( int $quality, string $mime_type ): int {
	return 'image/webp' === $mime_type ? 78 : $quality;
}
add_filter( 'wp_editor_set_quality', 'rcobeca_webp_quality', 10, 2 );
