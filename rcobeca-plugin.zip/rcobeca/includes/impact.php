<?php
/**
 * The impact numbers on the home page, worked out from the records so they
 * never go stale and each can be checked on the page it links to:
 *
 * - years active: since the earliest Club Year with a Committee (1993);
 *   proof: the Committee history;
 * - Projects completed: published Projects with status Completed; proof: the
 *   Projects listing filtered to Completed, which counts the same;
 * - dollars delivered: the US-dollar amounts recorded on those Projects, a
 *   "More than $X" amount counted as $X, so the total is a floor and says
 *   "or more" (amounts in rupees are left out); proof: the same listing,
 *   whose "$X delivered" lines add up to it;
 * - Royal Charity Balls: the edition of the newest Ball held; proof: Past Balls.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

use RCOBECA\Events;

/**
 * The figures, in order. A figure whose records are missing is left out.
 *
 * @return array<int, array{figure: string, label: string, link: string, url: string}>
 */
function rcobeca_impact_figures(): array {
	$figures   = array();
	$completed = home_url( '/projects/?status=completed' );

	$years = array_map( static fn( $term ) => $term['year'], rcobeca_committee_terms() );
	if ( $years ) {
		$founded   = min( $years );
		$figures[] = array(
			'figure' => (string) ( (int) wp_date( 'Y' ) - $founded ),
			/* translators: %d: founding year. */
			'label'  => sprintf( __( 'years since Old Royalists in the tri-state area founded RCOBECA in %d', 'rcobeca' ), $founded ),
			'link'   => __( 'Every Committee since then', 'rcobeca' ),
			'url'    => home_url( '/committee/history/' ),
		);
	}

	$projects = get_posts(
		array(
			'post_type'      => RCOBECA_PROJECT,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_key'       => 'rcobeca_status', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_value'     => 'completed', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
		)
	);
	if ( $projects ) {
		$figures[] = array(
			'figure' => number_format_i18n( count( $projects ) ),
			'label'  => __( 'Projects completed for Royal College, relief in Sri Lanka and causes in the US', 'rcobeca' ),
			'link'   => __( 'See the completed Projects', 'rcobeca' ),
			'url'    => $completed,
		);
	}

	$cents  = 0;
	$priced = 0;
	foreach ( $projects as $id ) {
		$amount = rcobeca_dollars_delivered_cents( $id );
		if ( $amount > 0 ) {
			$cents += $amount;
			++$priced;
		}
	}
	if ( $cents > 0 ) {
		$figures[] = array(
			'figure' => rcobeca_money( $cents ),
			/* translators: %d: number of Projects. */
			'label'  => sprintf( _n( 'or more, delivered by the %d completed Project whose cost is on record in dollars; gifts in rupees are not counted', 'or more, delivered by the %d completed Projects whose cost is on record in dollars; gifts in rupees are not counted', $priced, 'rcobeca' ), $priced ),
			'link'   => __( 'See what they funded', 'rcobeca' ),
			'url'    => $completed,
		);
	}

	foreach ( Events::past( Events::BALL ) as $ball ) {
		$edition = (int) Events::get( $ball, 'edition' );
		if ( $edition ) {
			$figures[] = array(
				'figure' => (string) $edition,
				/* translators: %s: date of the newest Ball. */
				'label'  => sprintf( __( 'Royal Charity Balls, the latest on %s', 'rcobeca' ), Events::date_label( $ball ) ),
				'link'   => __( 'Past Balls', 'rcobeca' ),
				'url'    => home_url( '/ball/past/' ),
			);
			break;
		}
	}
	return $figures;
}

/**
 * The US dollars a Project's record says it delivered, in cents: its amount,
 * or the floor of an amount written as "$8,000" or "More than $8,000".
 * Amounts in rupees, or in words, count as 0.
 *
 * @param int $id Project ID.
 */
function rcobeca_dollars_delivered_cents( int $id ): int {
	$text = trim( (string) get_post_meta( $id, 'rcobeca_amount_text', true ) );
	if ( '' === $text ) {
		return max( 0, (int) get_post_meta( $id, 'rcobeca_amount_cents', true ) );
	}
	if ( preg_match( '/^(?:more than |over |at least )?\$\s?([\d,]+)(?:\.(\d\d))?$/i', $text, $m ) ) {
		return (int) str_replace( ',', '', $m[1] ) * 100 + (int) ( $m[2] ?? 0 );
	}
	return 0;
}
