<?php
/**
 * Builders for clean core block markup, and helpers over lists of blocks.
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

/**
 * Each builder returns one block as an array: name (core/paragraph), text (its
 * plain text, for matching) and markup (serialized block HTML). Steps pick,
 * reorder and join these, then save Blocks::markup() as post content.
 */
class Blocks {

	/**
	 * A paragraph.
	 *
	 * @param string $html Inline HTML.
	 * @param string $class_name Optional extra class.
	 */
	public static function paragraph( string $html, string $class_name = '' ): array {
		$attrs = $class_name ? array( 'className' => $class_name ) : array();
		$class = $class_name ? ' class="' . esc_attr( $class_name ) . '"' : '';
		return self::make( 'paragraph', $attrs, "<p$class>$html</p>", $html );
	}

	/**
	 * A heading. Level 1 belongs to the page title, so it becomes 2.
	 *
	 * @param string $text Heading text (inline HTML allowed).
	 * @param int    $level 1 to 6.
	 */
	public static function heading( string $text, int $level = 2 ): array {
		$level = max( 2, min( 6, $level ) );
		$attrs = 2 === $level ? array() : array( 'level' => $level );
		return self::make( 'heading', $attrs, "<h$level class=\"wp-block-heading\">$text</h$level>", $text );
	}

	/**
	 * A bulleted or numbered list.
	 *
	 * @param string[] $items Inline HTML of each item.
	 * @param bool     $ordered Numbered list.
	 */
	public static function list( array $items, bool $ordered = false ): array {
		$tag   = $ordered ? 'ol' : 'ul';
		$inner = '';
		foreach ( $items as $item ) {
			$inner .= "<!-- wp:list-item -->\n<li>$item</li>\n<!-- /wp:list-item -->\n";
		}
		$attrs = $ordered ? array( 'ordered' => true ) : array();
		return self::make( 'list', $attrs, "<$tag class=\"wp-block-list\">\n$inner</$tag>", implode( "\n", $items ) );
	}

	/**
	 * A table. The first row becomes the header when $head is true.
	 *
	 * @param array<int, string[]> $rows Cells' inline HTML, row by row.
	 * @param bool                 $head First row is a header row.
	 */
	public static function table( array $rows, bool $head = false ): array {
		$html = '';
		if ( $head && $rows ) {
			$html .= '<thead><tr><th>' . implode( '</th><th>', array_shift( $rows ) ) . '</th></tr></thead>';
		}
		$html .= '<tbody>';
		foreach ( $rows as $cells ) {
			$html .= '<tr><td>' . implode( '</td><td>', $cells ) . '</td></tr>';
		}
		$html .= '</tbody>';
		$text  = implode( "\n", array_map( static fn( $r ) => implode( ' | ', $r ), $rows ) );
		return self::make( 'table', array(), "<figure class=\"wp-block-table\"><table class=\"has-fixed-layout\">$html</table></figure>", $text );
	}

	/**
	 * An image from the media library.
	 *
	 * @param int    $id Attachment ID.
	 * @param string $caption Optional caption (inline HTML).
	 */
	public static function image( int $id, string $caption = '' ): array {
		$url     = (string) wp_get_attachment_image_url( $id, 'large' );
		$alt     = (string) get_post_meta( $id, '_wp_attachment_image_alt', true );
		$figcap  = $caption ? "<figcaption class=\"wp-element-caption\">$caption</figcaption>" : '';
		$img     = '<img src="' . esc_url( $url ) . '" alt="' . esc_attr( $alt ) . '" class="wp-image-' . $id . '"/>';
		$attrs   = array(
			'id'              => $id,
			'sizeSlug'        => 'large',
			'linkDestination' => 'none',
		);
		$caption = wp_strip_all_tags( $caption );
		return self::make( 'image', $attrs, "<figure class=\"wp-block-image size-large\">$img$figcap</figure>", $caption ? $caption : $alt );
	}

	/**
	 * A Gallery of media-library images linked to their files, so the theme
	 * opens it in its lightbox.
	 *
	 * @param int[]  $ids Attachment IDs.
	 * @param string $caption Optional gallery caption (inline HTML).
	 */
	public static function gallery( array $ids, string $caption = '' ): array {
		$inner = '';
		$alts  = array();
		foreach ( $ids as $id ) {
			$alt    = (string) get_post_meta( $id, '_wp_attachment_image_alt', true );
			$alts[] = $alt;
			$attrs  = wp_json_encode(
				array(
					'id'              => $id,
					'sizeSlug'        => 'large',
					'linkDestination' => 'media',
				)
			);
			$img    = '<img src="' . esc_url( (string) wp_get_attachment_image_url( $id, 'large' ) ) . '" alt="' . esc_attr( $alt ) . '" class="wp-image-' . $id . '"/>';
			$inner .= "<!-- wp:image $attrs -->\n<figure class=\"wp-block-image size-large\"><a href=\"" . esc_url( (string) wp_get_attachment_url( $id ) ) . "\">$img</a></figure>\n<!-- /wp:image -->\n";
		}
		$figcap = $caption ? "<figcaption class=\"blocks-gallery-caption wp-element-caption\">$caption</figcaption>" : '';
		$attrs  = array(
			'linkTo'    => 'media',
			'sizeSlug'  => 'large',
			'className' => 'rcobeca-gallery',
		);
		// Four photos in three columns would leave the last one alone and stretched: two by two instead.
		$columns = 'default';
		if ( 4 === count( $ids ) ) {
			$attrs   = array( 'columns' => 2 ) + $attrs;
			$columns = '2';
		}
		return self::make( 'gallery', $attrs, "<figure class=\"wp-block-gallery has-nested-images columns-$columns is-cropped rcobeca-gallery\">\n$inner$figcap</figure>", implode( "\n", $alts ) );
	}

	/**
	 * Replaces each run of two or more uncaptioned images with a Gallery.
	 *
	 * @param array[] $blocks Blocks.
	 * @return array[]
	 */
	public static function galleries( array $blocks ): array {
		$out = array();
		$run = array();
		$end = static function () use ( &$out, &$run ): void {
			if ( count( $run ) > 1 ) {
				$out[] = self::gallery( array_column( $run, 'id' ) );
			} else {
				array_push( $out, ...array_column( $run, 'block' ) );
			}
			$run = array();
		};
		foreach ( $blocks as $block ) {
			if ( 'core/image' === $block['name'] && ! str_contains( $block['markup'], '<figcaption' ) && preg_match( '/"id":(\d+)/', $block['markup'], $m ) ) {
				$run[] = array(
					'id'    => (int) $m[1],
					'block' => $block,
				);
				continue;
			}
			$end();
			$out[] = $block;
		}
		$end();
		return $out;
	}

	/**
	 * A poem or song, line breaks kept.
	 *
	 * @param string $html Inline HTML with <br> line breaks.
	 */
	public static function verse( string $html ): array {
		return self::make( 'verse', array(), "<pre class=\"wp-block-verse\">$html</pre>", $html );
	}

	/**
	 * A quotation.
	 *
	 * @param string $html Quoted text (inline HTML).
	 * @param string $citation Optional source.
	 */
	public static function quote( string $html, string $citation = '' ): array {
		$paragraph = self::paragraph( $html )['markup'];
		$cite      = $citation ? "<cite>$citation</cite>" : '';
		return self::make( 'quote', array(), "<blockquote class=\"wp-block-quote\">\n$paragraph\n$cite</blockquote>", $html );
	}

	/**
	 * A horizontal rule.
	 */
	public static function separator(): array {
		return self::make( 'separator', array(), '<hr class="wp-block-separator has-alpha-channel-opacity"/>', '' );
	}

	/**
	 * A video or other oEmbed URL.
	 *
	 * @param string $url Video URL.
	 */
	public static function embed( string $url ): array {
		$provider = preg_match( '/youtu\.?be/', $url ) ? 'youtube' : ( str_contains( $url, 'facebook.com' ) ? 'facebook' : '' );
		$attrs    = array_filter(
			array(
				'url'              => $url,
				'type'             => 'video',
				'providerNameSlug' => $provider,
			)
		);
		$class    = 'wp-block-embed is-type-video' . ( $provider ? " is-provider-$provider wp-block-embed-$provider" : '' );
		$html     = "<figure class=\"$class\"><div class=\"wp-block-embed__wrapper\">\n" . esc_url( $url ) . "\n</div></figure>";
		return self::make( 'embed', $attrs, $html, $url );
	}

	/**
	 * A video that can't be embedded (Facebook), as a labelled link card.
	 *
	 * @param string $url   The video's page.
	 * @param string $where Where it plays, e.g. "Facebook".
	 */
	public static function video_link( string $url, string $where ): array {
		/* translators: %s: site the video is on, e.g. Facebook. */
		$label = sprintf( __( 'Watch the video on %s', 'rcobeca' ), $where );
		return self::paragraph( '<a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>', 'rcobeca-video-link' );
	}

	/**
	 * A raw HTML block (for markup no core block can hold).
	 *
	 * @param string $html Raw HTML.
	 */
	public static function html( string $html ): array {
		return array(
			'name'   => 'core/html',
			'text'   => wp_strip_all_tags( $html ),
			'markup' => "<!-- wp:html -->\n$html\n<!-- /wp:html -->",
		);
	}

	/**
	 * The inline HTML inside a single-element block (paragraph, heading,
	 * verse), for rebuilding it as another kind of block.
	 *
	 * @param array $block Block.
	 */
	public static function inner( array $block ): string {
		return preg_match( '#<(p|h\d|pre)\b[^>]*>(.*)</\1>#s', $block['markup'], $m ) ? $m[2] : '';
	}

	/**
	 * Post content from a list of blocks.
	 *
	 * @param array[] $blocks Blocks from the builders or Converter.
	 */
	public static function markup( array $blocks ): string {
		return implode( "\n\n", array_column( $blocks, 'markup' ) );
	}

	/**
	 * Splits blocks into sections at each heading. The first section holds
	 * whatever comes before the first heading and has a null title.
	 *
	 * @param array[] $blocks Blocks.
	 * @return array<int, array{title: ?string, heading: ?array, blocks: array[]}>
	 */
	public static function sections( array $blocks ): array {
		$sections = array(
			array(
				'title'   => null,
				'heading' => null,
				'blocks'  => array(),
			),
		);
		foreach ( $blocks as $block ) {
			if ( 'core/heading' === $block['name'] ) {
				$sections[] = array(
					'title'   => trim( wp_strip_all_tags( $block['text'] ) ),
					'heading' => $block,
					'blocks'  => array(),
				);
				continue;
			}
			$sections[ count( $sections ) - 1 ]['blocks'][] = $block;
		}
		return $sections;
	}

	/**
	 * The section whose heading matches a title (case-insensitive).
	 *
	 * @param array[] $blocks Blocks.
	 * @param string  $title Heading text.
	 * @return array[] The section's blocks, without the heading.
	 */
	public static function section( array $blocks, string $title ): array {
		foreach ( self::sections( $blocks ) as $section ) {
			if ( null !== $section['title'] && 0 === strcasecmp( $section['title'], $title ) ) {
				return $section['blocks'];
			}
		}
		return array();
	}

	/**
	 * Serializes one block.
	 *
	 * @param string $name Core block name without the core/ prefix.
	 * @param array  $attrs Block attributes.
	 * @param string $html Saved HTML.
	 * @param string $text Plain text for matching.
	 */
	private static function make( string $name, array $attrs, string $html, string $text ): array {
		$json = $attrs ? ' ' . wp_json_encode( $attrs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) : '';
		return array(
			'name'   => "core/$name",
			'text'   => html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ),
			'markup' => "<!-- wp:$name$json -->\n$html\n<!-- /wp:$name -->",
		);
	}
}
