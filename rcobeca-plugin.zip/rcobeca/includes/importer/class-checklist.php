<?php
/**
 * The migration checklist: every old URL and content block, and its new home.
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

use RCOBECA\Redirects;

/**
 * Generated from three sources, so nothing is provably dropped:
 * - the old URLs: every sitemap URL in the snapshot, every row of
 *   data/migration-owners.tsv (listings, legacy files, earlier sites) and
 *   every redirect a step recorded;
 * - data/migration-owners.tsv, saying which ticket owns each URL until a step
 *   imports it;
 * - what steps recorded while importing: blocks moved, handed off or dropped
 *   (Context::moved(), handoff(), dropped()) and facts to confirm before
 *   launch (Context::check());
 * - every public media file of the old site, imported or dropped with a
 *   reason (media()).
 */
class Checklist {

	public const OPTION = 'rcobeca_migration';

	/**
	 * The block name steps record an old upload under.
	 */
	public const MEDIA_FILE = 'Media file';

	/**
	 * Ownership rows: [pattern, owner, planned home, note].
	 *
	 * @var array<int, string[]>
	 */
	private array $owners = array();

	/**
	 * Entries recorded while buffering, or null when writing straight away.
	 *
	 * @var array[]|null
	 */
	private static ?array $buffer = null;

	/**
	 * Loads ownership.
	 *
	 * @param Snapshot    $snapshot Content snapshot.
	 * @param string|null $owners Ownership TSV; defaults to data/migration-owners.tsv.
	 */
	public function __construct( private Snapshot $snapshot, ?string $owners = null ) {
		foreach ( file( $owners ?? RCOBECA_DIR . '/data/migration-owners.tsv', FILE_IGNORE_NEW_LINES ) as $line ) {
			if ( '' !== trim( $line ) && '#' !== $line[0] ) {
				$this->owners[] = array_pad( explode( "\t", $line ), 4, '' );
			}
		}
	}

	/**
	 * Records something a step did with old content.
	 *
	 * @param array $entry Entry: type (block|check), step, and its fields.
	 */
	public static function record( array $entry ): void {
		if ( null !== self::$buffer ) {
			self::$buffer[] = $entry;
			return;
		}
		$entries   = (array) get_option( self::OPTION, array() );
		$entries[] = $entry;
		update_option( self::OPTION, $entries, false );
	}

	/**
	 * Holds what a step records in memory until flush(), so a step that
	 * records hundreds of rows writes the option once.
	 */
	public static function buffer(): void {
		self::$buffer = array();
	}

	/**
	 * Writes what was recorded since buffer().
	 */
	public static function flush(): void {
		if ( self::$buffer ) {
			update_option( self::OPTION, array_merge( (array) get_option( self::OPTION, array() ), self::$buffer ), false );
		}
		self::$buffer = null;
	}

	/**
	 * Forgets what a step recorded, before it runs again.
	 *
	 * @param string $step Step name.
	 */
	public static function clear_step( string $step ): void {
		$entries = array_filter( (array) get_option( self::OPTION, array() ), static fn( $e ) => $e['step'] !== $step );
		update_option( self::OPTION, array_values( $entries ), false );
	}

	/**
	 * One row per old URL.
	 *
	 * @return array<int, array{url: string, owner: string, status: string, home: string, note: string}>
	 */
	public function urls(): array {
		$keys = array();
		foreach ( $this->snapshot->sitemap_paths() as $path ) {
			$keys[ self::key( $path ) ] = true;
		}
		foreach ( $this->owners as [ $pattern ] ) {
			if ( ! str_contains( $pattern, '*' ) ) {
				$keys[ self::key( $pattern ) ] = true;
			}
		}
		foreach ( array_keys( Redirects::all() ) as $path ) {
			$keys[ $path ] = true;
		}

		$moved = array();
		foreach ( $this->blocks() as $block ) {
			if ( 'done' === $block['status'] ) {
				$moved[ $block['url'] ] = $block['home'];
			}
		}

		$rows = array();
		foreach ( array_keys( $keys ) as $url ) {
			[ , $owner, $planned, $note ] = $this->owner( $url ) ?? array( '', '#11', '', 'not yet assigned: the launch sweep' );
			$home                         = self::is_old_site( $url ) ? Redirects::target( $url ) : ( $moved[ $url ] ?? null );
			$status                       = $home ? 'done' : ( str_starts_with( $note, 'dropped' ) ? 'dropped' : 'pending' );
			$rows[]                       = array(
				'url'    => $url,
				'owner'  => $owner,
				'status' => $status,
				'home'   => (string) ( $home ?? $planned ),
				'note'   => $note,
			);
		}
		usort( $rows, static fn( $a, $b ) => array( $a['owner'], $a['url'] ) <=> array( $b['owner'], $b['url'] ) );
		return $rows;
	}

	/**
	 * One row per content block steps recorded. A block one step handed off
	 * (pending) and a later step moved or dropped shows only the later row.
	 *
	 * @return array<int, array{url: string, block: string, status: string, owner: string, home: string, step: string}>
	 */
	public function blocks(): array {
		$entries  = array_filter( (array) get_option( self::OPTION, array() ), static fn( $e ) => 'block' === $e['type'] );
		$resolved = array();
		foreach ( $entries as $entry ) {
			if ( 'pending' !== $entry['status'] ) {
				$resolved[ self::key( $entry['url'] ) . "\n" . $entry['block'] ] = true;
			}
		}
		$rows = array();
		foreach ( $entries as $entry ) {
			if ( 'pending' === $entry['status'] && isset( $resolved[ self::key( $entry['url'] ) . "\n" . $entry['block'] ] ) ) {
				continue;
			}
			$url    = self::key( $entry['url'] );
			$home   = is_int( $entry['home'] ) ? (string) get_permalink( $entry['home'] ) : (string) $entry['home'];
			$rows[] = array(
				'url'    => $url,
				'block'  => $entry['block'],
				'status' => $entry['status'],
				'owner'  => $entry['owner'] ?? ( $this->owner( $url )[1] ?? '' ),
				'home'   => $home,
				'step'   => $entry['step'],
			);
		}
		return $rows;
	}

	/**
	 * Facts RCOBECA must confirm before launch.
	 *
	 * @return array<int, array{check: string, step: string}>
	 */
	public function checks(): array {
		$rows = array();
		foreach ( (array) get_option( self::OPTION, array() ) as $entry ) {
			if ( 'check' === $entry['type'] ) {
				$rows[] = array(
					'check' => $entry['check'],
					'step'  => $entry['step'],
				);
			}
		}
		return $rows;
	}

	/**
	 * One row per public media file of the old site (Snapshot::public_media()):
	 * imported (into the media library, under any size), dropped (a step
	 * recorded a "Media file" block as dropped, with its reason) or
	 * unaccounted.
	 *
	 * @return array<int, array{file: string, status: string, note: string}>
	 */
	public function media(): array {
		$imported = array();
		foreach ( get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_key'       => '_rcobeca_source_url', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			)
		) as $id ) {
			foreach ( self::upload_keys( (string) get_post_meta( $id, '_rcobeca_source_url', true ) ) as $file ) {
				$imported[ $file ] = (string) wp_get_attachment_url( $id );
			}
		}
		$dropped = array();
		foreach ( (array) get_option( self::OPTION, array() ) as $entry ) {
			if ( 'block' === $entry['type'] && self::MEDIA_FILE === $entry['block'] && 'dropped' === $entry['status'] ) {
				foreach ( self::upload_keys( $entry['url'] ) as $file ) {
					$dropped[ $file ] = (string) $entry['home'];
				}
			}
		}
		$rows = array();
		foreach ( $this->snapshot->public_media() as $file ) {
			if ( isset( $imported[ $file ] ) ) {
				$rows[] = array(
					'file'   => $file,
					'status' => 'imported',
					'note'   => $imported[ $file ],
				);
			} else {
				$rows[] = array(
					'file'   => $file,
					'status' => isset( $dropped[ $file ] ) ? 'dropped' : 'unaccounted',
					'note'   => $dropped[ $file ] ?? 'not imported, and no step says why: import it or add it to data/media-files.tsv',
				);
			}
		}
		return $rows;
	}

	/**
	 * The media-file keys an upload URL answers to: its original
	 * (Snapshot::upload_file()) and its exact path, since a file can itself be
	 * named like a resized copy (photo-1600x1066.jpg).
	 *
	 * @param string $url Upload URL.
	 * @return string[]
	 */
	private static function upload_keys( string $url ): array {
		$exact = preg_match( '#/uploads/(.+)$#', rawurldecode( $url ), $match ) ? $match[1] : '';
		return array_unique( array_filter( array( Snapshot::upload_file( $url ), $exact ) ) );
	}

	/**
	 * The checklist as Markdown, for `wp rcobeca checklist`.
	 */
	public function markdown(): string {
		$urls   = $this->urls();
		$counts = array_count_values( array_column( $urls, 'status' ) );
		$out    = "# Migration checklist\n\nGenerated by `wp rcobeca checklist` from the snapshot, `plugin/rcobeca/data/migration-owners.tsv` and the last import. Do not edit by hand.\n\n";
		$out   .= sprintf( "%d old URLs: %d done, %d pending, %d dropped.\n\n", count( $urls ), $counts['done'] ?? 0, $counts['pending'] ?? 0, $counts['dropped'] ?? 0 );

		$out .= "## Old URLs\n\n| Old URL | Owner | Status | New home | Note |\n|---|---|---|---|---|\n";
		foreach ( $urls as $row ) {
			$out .= self::table_row( array( $row['url'], $row['owner'], $row['status'], self::path( $row['home'] ), $row['note'] ) );
		}

		$out .= "\n## Content blocks\n\n| Old URL | Block | Owner | Status | New home |\n|---|---|---|---|---|\n";
		foreach ( $this->blocks() as $row ) {
			$out .= self::table_row( array( $row['url'], $row['block'], $row['owner'], $row['status'], self::path( $row['home'] ) ) );
		}

		$media   = $this->media();
		$by_kind = array_count_values( array_column( $media, 'status' ) );
		$out    .= "\n## Media files\n\n";
		$out    .= sprintf( "%d public media files (the old media library and every upload an old page links): %d imported, %d dropped, %d unaccounted.\n\n", count( $media ), $by_kind['imported'] ?? 0, $by_kind['dropped'] ?? 0, $by_kind['unaccounted'] ?? 0 );
		$out    .= "| File (under /newsite/wp-content/uploads/) | Status | New home or reason |\n|---|---|---|\n";
		foreach ( $media as $row ) {
			$out .= self::table_row( array( $row['file'], $row['status'], self::path( $row['note'] ) ) );
		}

		$out .= "\n## Confirm before launch\n\n";
		foreach ( $this->checks() as $row ) {
			$out .= "- [ ] {$row['check']}\n";
		}

		$out .= "\n## Images with generated alt text to review\n\n| Image | Alt text | Source |\n|---|---|---|\n";
		foreach ( get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'meta_key'       => '_rcobeca_alt_needs_review', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			)
		) as $image ) {
			$out .= self::table_row( array( self::path( (string) wp_get_attachment_url( $image->ID ) ), (string) get_post_meta( $image->ID, '_wp_attachment_image_alt', true ), (string) get_post_meta( $image->ID, '_rcobeca_source_url', true ) ) );
		}
		return $out;
	}

	/**
	 * The ownership row for a URL: exact match first, then the first glob.
	 *
	 * @param string $url Checklist key.
	 * @return string[]|null [pattern, owner, planned home, note].
	 */
	private function owner( string $url ): ?array {
		foreach ( $this->owners as $row ) {
			if ( self::key( $row[0] ) === $url ) {
				return $row;
			}
		}
		foreach ( $this->owners as $row ) {
			if ( str_contains( $row[0], '*' ) && fnmatch( strtolower( $row[0] ), $url, FNM_NOESCAPE ) ) {
				return $row;
			}
		}
		return null;
	}

	/**
	 * Checklist key: a normalized path (and query) for the old site, the full
	 * URL for other sites (the Earthlink predecessor).
	 *
	 * @param string $url URL or path.
	 */
	private static function key( string $url ): string {
		if ( ! self::is_old_site( $url ) ) {
			return $url;
		}
		$query = (string) wp_parse_url( $url, PHP_URL_QUERY );
		return Redirects::normalize( $url ) . ( '' !== $query ? "?$query" : '' );
	}

	/**
	 * Whether a URL is on rcobeca.org (or a bare path).
	 *
	 * @param string $url URL or path.
	 */
	private static function is_old_site( string $url ): bool {
		$host = (string) wp_parse_url( $url, PHP_URL_HOST );
		return '' === $host || (bool) preg_match( '/(^|\.)rcobeca\.org$/i', $host );
	}

	/**
	 * A site URL shortened to its path for the table.
	 *
	 * @param string $url URL.
	 */
	private static function path( string $url ): string {
		return str_starts_with( $url, home_url() ) ? (string) substr( $url, strlen( untrailingslashit( home_url() ) ) ) : $url;
	}

	/**
	 * A Markdown table row.
	 *
	 * @param string[] $cells Cells.
	 */
	private static function table_row( array $cells ): string {
		return '| ' . implode( ' | ', array_map( static fn( $c ) => str_replace( array( '|', "\n" ), array( '\|', ' ' ), $c ), $cells ) ) . " |\n";
	}
}
