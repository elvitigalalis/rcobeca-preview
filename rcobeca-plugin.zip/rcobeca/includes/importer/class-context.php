<?php
/**
 * What an importer step gets to work with.
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

use RCOBECA\Redirects;

/**
 * Passed to every step: the snapshot, media importer and converter, plus
 * idempotent writes (upsert) and bookkeeping for redirects and the migration
 * checklist, all attributed to the running step.
 */
class Context {

	/**
	 * Sets up a step's context.
	 *
	 * @param string    $step Running step's name.
	 * @param Snapshot  $snapshot Content snapshot.
	 * @param Media     $media Media importer.
	 * @param Converter $converter WPBakery and HTML converter.
	 * @param callable  $logger Receives log lines.
	 */
	public function __construct(
		public readonly string $step,
		public readonly Snapshot $snapshot,
		public readonly Media $media,
		public readonly Converter $converter,
		private $logger
	) {}

	/**
	 * Creates or updates a post (any post type) identified by a stable import
	 * key, so re-runs update in place instead of duplicating.
	 *
	 * @param string $key Unique key, e.g. "page:our-story" or "project:rowing-boats".
	 * @param array  $postarr wp_insert_post() arguments. post_status defaults to publish.
	 * @param array  $meta Post meta to set.
	 * @return int Post ID.
	 * @throws \RuntimeException When WordPress refuses the post.
	 */
	public function upsert( string $key, array $postarr, array $meta = array() ): int {
		$postarr += array(
			'post_status' => 'publish',
			'post_type'   => 'post',
		);
		$id       = self::find( $key );
		if ( $id ) {
			$postarr['ID'] = $id;
		}
		$result = $id ? wp_update_post( wp_slash( $postarr ), true ) : wp_insert_post( wp_slash( $postarr ), true );
		if ( is_wp_error( $result ) ) {
			throw new \RuntimeException( esc_html( "Could not save $key: " . $result->get_error_message() ) );
		}
		update_post_meta( $result, '_rcobeca_import_key', $key );
		foreach ( $meta as $name => $value ) {
			update_post_meta( $result, $name, $value );
		}
		return (int) $result;
	}

	/**
	 * The post created under an import key, if any.
	 *
	 * @param string $key Import key.
	 * @return int Post ID or 0.
	 */
	public static function find( string $key ): int {
		$ids = get_posts(
			array(
				'post_type'      => array_values( get_post_types() ),
				'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future', 'trash', 'inherit' ),
				'meta_key'       => '_rcobeca_import_key', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => $key, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'fields'         => 'ids',
				'posts_per_page' => 1,
			)
		);
		return $ids ? (int) $ids[0] : 0;
	}

	/**
	 * Records a permanent redirect from an old URL to its new home.
	 *
	 * @param string     $from Old URL or path, e.g. /about-us/ or https://rcobeca.org/hostel.htm.
	 * @param int|string $to Post ID (preferred: follows renames) or path of the new home.
	 */
	public function redirect( string $from, int|string $to ): void {
		Redirects::add( $from, $to, $this->step );
	}

	/**
	 * Checklist: a block of an old page now lives in a post.
	 *
	 * @param string $old_url Old page URL or path (for a whole page from another site, its URL).
	 * @param string $block What it was, e.g. "A look back" or "HISTORY table".
	 * @param int    $post Post it moved to.
	 */
	public function moved( string $old_url, string $block, int $post ): void {
		$this->block( $old_url, $block, 'done', $post );
	}

	/**
	 * Checklist: a block of an old page is left for a later ticket to import.
	 *
	 * @param string $old_url Old page URL or path.
	 * @param string $block What it is.
	 * @param string $owner Owning ticket, e.g. "#6".
	 * @param string $planned Where it will go.
	 */
	public function handoff( string $old_url, string $block, string $owner, string $planned = '' ): void {
		$this->block( $old_url, $block, 'pending', $planned, $owner );
	}

	/**
	 * Checklist: a block of an old page is deliberately not carried over.
	 *
	 * @param string $old_url Old page URL or path.
	 * @param string $block What it is.
	 * @param string $reason Why (junk, broken, superseded by ...).
	 */
	public function dropped( string $old_url, string $block, string $reason ): void {
		$this->block( $old_url, $block, 'dropped', $reason );
	}

	/**
	 * Checklist: a fact or permission RCOBECA must confirm before launch.
	 *
	 * @param string $what What to confirm.
	 */
	public function check( string $what ): void {
		Checklist::record(
			array(
				'type'  => 'check',
				'step'  => $this->step,
				'check' => $what,
			)
		);
	}

	/**
	 * Records a block row.
	 *
	 * @param string     $old_url Old page.
	 * @param string     $block Block.
	 * @param string     $status done, pending or dropped.
	 * @param int|string $home Post ID, planned home or reason.
	 * @param string     $owner Owning ticket, when not the URL's owner.
	 */
	private function block( string $old_url, string $block, string $status, int|string $home, string $owner = '' ): void {
		Checklist::record(
			array_filter(
				array(
					'type'   => 'block',
					'step'   => $this->step,
					'url'    => $old_url,
					'block'  => $block,
					'status' => $status,
					'home'   => $home,
					'owner'  => $owner,
				),
				static fn( $value ) => '' !== $value
			)
		);
	}

	/**
	 * Writes a progress line.
	 *
	 * @param string $message Message.
	 */
	public function log( string $message ): void {
		( $this->logger )( "[{$this->step}] $message" );
	}
}
