<?php
/**
 * WPBakery shortcodes and legacy HTML to clean core blocks.
 *
 * @package RCOBECA
 */

// phpcs:disable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM API property names.

namespace RCOBECA\Importer;

use DOMDocument;
use DOMElement;
use DOMNode;
use DOMXPath;

/**
 * Turns the old site's content (REST content.rendered, where WPBakery
 * shortcodes survive as texturized text) into core blocks. Text is kept
 * verbatim; layout, inline styles, theme widgets, forms and scripts are
 * dropped; links go through Links; images and linked uploads are imported
 * through Media.
 */
class Converter {

	/**
	 * Shortcodes that wrap content and have a closing tag.
	 */
	private const CONTAINERS = array( 'vc_row', 'vc_column', 'vc_row_inner', 'vc_column_inner', 'vc_column_text', 'vc_tta_accordion', 'vc_tta_tabs', 'vc_tta_tour', 'vc_tta_section', 'vc_raw_html' );

	/**
	 * Elements dropped with everything inside them.
	 */
	private const DROP = array( 'script', 'style', 'noscript', 'form', 'input', 'select', 'textarea', 'button', 'label', 'i', 'svg', 'object', 'embed' );

	/**
	 * Inline elements kept (attributes stripped, except a href).
	 */
	private const INLINE = array( 'a', 'strong', 'b', 'em', 'cite', 'sup', 'sub', 'br', 'code', 'abbr' );

	/**
	 * Text of the nearest heading above the current block, for image alt text.
	 *
	 * @var string
	 */
	private string $heading = '';

	/**
	 * Page title, for image alt text.
	 *
	 * @var string
	 */
	private string $title = '';

	/**
	 * Sets up the converter.
	 *
	 * @param Snapshot $snapshot Snapshot, for the media index.
	 * @param Media    $media Media importer.
	 * @param Links    $links Link rewriter.
	 */
	public function __construct(
		private Snapshot $snapshot,
		private Media $media,
		private Links $links
	) {}

	/**
	 * Converts a page or post body from the REST dump.
	 *
	 * @param string $rendered content.rendered from the REST dump.
	 * @param string $title Page title, used for generated alt text.
	 * @return array[] Blocks (see Blocks).
	 */
	public function to_blocks( string $rendered, string $title = '' ): array {
		$this->title   = $title;
		$this->heading = '';
		$blocks        = array();
		foreach ( $this->parse_shortcodes( $rendered ) as $node ) {
			array_push( $blocks, ...$this->node_blocks( $node ) );
		}
		return $blocks;
	}

	/**
	 * Converts a fragment of legacy HTML.
	 *
	 * @param string $html HTML.
	 * @param string $title Page title, used for generated alt text.
	 * @return array[] Blocks.
	 */
	public function html_to_blocks( string $html, string $title = '' ): array {
		if ( '' !== $title ) {
			$this->title = $title;
		}
		$document = new DOMDocument();
		libxml_use_internal_errors( true );
		$document->loadHTML( '<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>' . $html . '</body></html>' );
		libxml_clear_errors();
		$body = $document->getElementsByTagName( 'body' )->item( 0 );
		$this->clean( $body );
		$blocks = array();
		$inline = '';
		$this->collect( $body, $blocks, $inline );
		$this->flush( $blocks, $inline );
		return $blocks;
	}

	/**
	 * Splits content into a tree of shortcode nodes and HTML text nodes.
	 *
	 * @param string $rendered Content with texturized shortcodes.
	 * @return array[] Nodes: [tag, attrs, children] or [html].
	 */
	private function parse_shortcodes( string $rendered ): array {
		$root  = array(
			'tag'      => 'root',
			'attrs'    => array(),
			'children' => array(),
		);
		$stack = array( &$root );
		$parts = preg_split( '/(\[\/?vc_\w+[^\]]*\])/', $rendered, -1, PREG_SPLIT_DELIM_CAPTURE );
		foreach ( $parts as $part ) {
			$top = &$stack[ count( $stack ) - 1 ];
			if ( preg_match( '/^\[\/(vc_\w+)\]$/', $part, $close ) ) {
				for ( $i = count( $stack ) - 1; $i > 0; $i-- ) {
					if ( $stack[ $i ]['tag'] === $close[1] ) {
						array_splice( $stack, $i );
						break;
					}
				}
			} elseif ( preg_match( '/^\[(vc_\w+)(.*)\]$/s', $part, $open ) ) {
				$node              = array(
					'tag'      => $open[1],
					'attrs'    => self::attributes( $open[2] ),
					'children' => array(),
				);
				$top['children'][] = $node;
				if ( in_array( $open[1], self::CONTAINERS, true ) ) {
					$stack[] = &$top['children'][ count( $top['children'] ) - 1 ];
				}
			} elseif ( '' !== trim( $part ) ) {
				$top['children'][] = array( 'html' => $part );
			}
			unset( $top );
		}
		return $root['children'];
	}

	/**
	 * Parses shortcode attributes whose quotes were texturized into curly
	 * quotes or primes. A value runs to the quote that is followed by the next
	 * attribute or the end, so quotes inside values survive.
	 *
	 * @param string $source Attribute text.
	 * @return array<string, string>
	 */
	private static function attributes( string $source ): array {
		$quote = '(?:&#8221;|&#8243;|&#8220;|&#8216;|&#8217;|”|″|“|")';
		preg_match_all( '/(\w+)=' . $quote . '(.*?)' . $quote . '(?=\s+\w+=|\s*$)/s', trim( $source ), $matches, PREG_SET_ORDER );
		$attrs = array();
		foreach ( $matches as $match ) {
			$attrs[ $match[1] ] = $match[2];
		}
		return $attrs;
	}

	/**
	 * Blocks for one shortcode or HTML node.
	 *
	 * @param array $node Node from parse_shortcodes().
	 * @return array[]
	 */
	private function node_blocks( array $node ): array {
		if ( isset( $node['html'] ) ) {
			return $this->html_to_blocks( $node['html'] );
		}
		$attrs = $node['attrs'];
		switch ( $node['tag'] ) {
			case 'vc_column_text':
				return $this->html_to_blocks( implode( '', array_column( $node['children'], 'html' ) ) );
			case 'vc_custom_heading':
				return $this->custom_heading( $attrs );
			case 'vc_text_separator':
				return isset( $attrs['title'] ) ? array( Blocks::paragraph( '<em>' . $this->inline( $attrs['title'] ) . '</em>' ) ) : array();
			case 'vc_separator':
				return array( Blocks::separator() );
			case 'vc_single_image':
				return $this->media_block( (int) ( $attrs['image'] ?? 0 ), $attrs['title'] ?? '' );
			case 'vc_gallery':
				$blocks = array();
				foreach ( array_filter( array_map( 'intval', explode( ',', $attrs['images'] ?? '' ) ) ) as $id ) {
					array_push( $blocks, ...$this->media_block( $id ) );
				}
				return $blocks;
			case 'vc_video':
				return isset( $attrs['link'] ) ? array( Blocks::embed( html_entity_decode( $attrs['link'] ) ) ) : array();
			case 'vc_btn':
				return $this->button( $attrs );
			case 'vc_tta_section':
				$blocks = isset( $attrs['title'] ) ? array( Blocks::heading( $this->inline( $attrs['title'] ), 3 ) ) : array();
				break;
			case 'vc_raw_html':
				$encoded = trim( wp_strip_all_tags( implode( '', array_column( $node['children'], 'html' ) ) ) );
				return $this->html_to_blocks( rawurldecode( (string) base64_decode( $encoded, true ) ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- WPBakery stores raw HTML base64-encoded.
			case 'vc_empty_space':
			case 'vc_basic_grid':
				return array();
			default:
				$blocks = array();
		}
		foreach ( $node['children'] as $child ) {
			array_push( $blocks, ...$this->node_blocks( $child ) );
		}
		return $blocks;
	}

	/**
	 * A WPBakery heading and its optional subtitle.
	 *
	 * @param array $attrs Shortcode attributes.
	 * @return array[]
	 */
	private function custom_heading( array $attrs ): array {
		$level  = preg_match( '/tag:h(\d)/', $attrs['font_container'] ?? '', $m ) ? (int) $m[1] : 2;
		$text   = trim( wp_strip_all_tags( html_entity_decode( $attrs['text'] ?? '', ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) );
		$blocks = array();
		if ( '' !== $text ) {
			$this->heading = $text;
			$blocks[]      = Blocks::heading( esc_html( $text ), $level );
		}
		if ( ! empty( $attrs['sub_title'] ) ) {
			array_push( $blocks, ...$this->html_to_blocks( '<p>' . $attrs['sub_title'] . '</p>' ) );
		}
		return $blocks;
	}

	/**
	 * A WPBakery button as a paragraph link (the theme styles calls to action).
	 *
	 * @param array $attrs Shortcode attributes.
	 * @return array[]
	 */
	private function button( array $attrs ): array {
		parse_str( str_replace( '|', '&', html_entity_decode( $attrs['link'] ?? '' ) ), $link );
		$url = isset( $link['url'] ) ? rawurldecode( $link['url'] ) : '';
		if ( '' === $url ) {
			return array();
		}
		return $this->html_to_blocks( '<p><a href="' . esc_url( $url ) . '">' . esc_html( $attrs['title'] ?? $url ) . '</a></p>' );
	}

	/**
	 * An image from the old media library, imported and placed.
	 *
	 * @param int    $old_id Attachment ID on the old site.
	 * @param string $caption Optional caption.
	 * @return array[]
	 */
	private function media_block( int $old_id, string $caption = '' ): array {
		$item = $this->snapshot->media( $old_id );
		if ( ! $item ) {
			return array();
		}
		return $this->image_block( $item['url'], $caption );
	}

	/**
	 * An image by URL, imported and placed; nothing if it can't be fetched or
	 * is theme furniture (logos, spacers, backgrounds).
	 *
	 * @param string $url Image URL.
	 * @param string $caption Optional caption.
	 * @return array[]
	 */
	private function image_block( string $url, string $caption = '' ): array {
		if ( preg_match( '/(spacer\.gif|logo|background)/i', $url ) ) {
			return array();
		}
		$item = $this->snapshot->media_by_url( $url );
		$id   = $this->media->import(
			$item['url'] ?? $url,
			array(
				'alt'   => $item['alt'] ?? '',
				'title' => $item['title'] ?? '',
				'about' => '' !== $caption ? $caption : ( '' !== $this->heading ? $this->heading : $this->title ),
			)
		);
		return $id ? array( Blocks::image( $id, $caption ? esc_html( $caption ) : '' ) ) : array();
	}

	/**
	 * Strips presentational markup and junk from a DOM tree in place.
	 *
	 * @param DOMNode $root Root element.
	 */
	private function clean( DOMNode $root ): void {
		$xpath = new DOMXPath( $root->ownerDocument );
		foreach ( iterator_to_array( $xpath->query( './/comment()', $root ) ) as $comment ) {
			$comment->parentNode->removeChild( $comment );
		}
		foreach ( self::DROP as $tag ) {
			foreach ( iterator_to_array( $root->getElementsByTagName( $tag ) ) as $element ) {
				$element->parentNode?->removeChild( $element );
			}
		}
		foreach ( iterator_to_array( $xpath->query( './/*[contains(@class, "dgt-social") or contains(@class, "screen-reader-response") or contains(@class, "wpcf7")]', $root ) ) as $element ) {
			$element->parentNode?->removeChild( $element );
		}
		foreach ( iterator_to_array( $root->getElementsByTagName( 'a' ) ) as $link ) {
			$this->rewrite_link( $link );
		}
		foreach ( iterator_to_array( $xpath->query( './/text()', $root ) ) as $text ) {
			$text->nodeValue = str_replace( 'Fill text to top bar static', '', $text->nodeValue );
		}
	}

	/**
	 * Applies Links to one anchor: keep, retarget, unwrap, mark or remove.
	 *
	 * @param DOMElement $link Anchor.
	 */
	private function rewrite_link( DOMElement $link ): void {
		$result = $this->links->rewrite( trim( $link->getAttribute( 'href' ) ) );
		switch ( $result['action'] ) {
			case Links::REMOVE:
				$link->parentNode?->removeChild( $link );
				return;
			case Links::UNWRAP:
				self::unwrap( $link );
				return;
			case Links::UNAVAILABLE:
				$link->parentNode?->insertBefore( $link->ownerDocument->createTextNode( ' (archive unavailable)' ), $link->nextSibling );
				self::unwrap( $link );
				return;
			case Links::UPLOAD:
				$id   = $this->media->import( $result['href'], array( 'about' => trim( $link->textContent ) ) );
				$href = $id ? wp_get_attachment_url( $id ) : '';
				if ( ! $href ) {
					self::unwrap( $link );
					return;
				}
				$result['href'] = $href;
				break;
		}
		foreach ( iterator_to_array( $link->attributes ) as $attribute ) {
			$link->removeAttribute( $attribute->name );
		}
		$link->setAttribute( 'href', $result['href'] );
	}

	/**
	 * Walks the cleaned tree, emitting block-level elements as blocks and
	 * gathering loose inline content into paragraphs.
	 *
	 * @param DOMNode $container Parent node.
	 * @param array[] $blocks Blocks so far.
	 * @param string  $inline Pending inline HTML.
	 */
	private function collect( DOMNode $container, array &$blocks, string &$inline ): void {
		foreach ( iterator_to_array( $container->childNodes ) as $node ) {
			if ( XML_TEXT_NODE === $node->nodeType ) {
				$inline .= esc_html( $node->nodeValue );
				continue;
			}
			if ( ! $node instanceof DOMElement ) {
				continue;
			}
			$tag = strtolower( $node->tagName );
			if ( in_array( $tag, self::INLINE, true ) || in_array( $tag, array( 'span', 'font', 'u', 'small', 'big' ), true ) ) {
				if ( $node->getElementsByTagName( 'img' )->length ) {
					$this->flush( $blocks, $inline );
					$this->collect( $node, $blocks, $inline );
					continue;
				}
				$inline .= $this->inline_html( $node );
				continue;
			}
			$this->flush( $blocks, $inline );
			switch ( $tag ) {
				case 'p':
					if ( $node->getElementsByTagName( 'img' )->length ) {
						$this->collect( $node, $blocks, $inline );
						$this->flush( $blocks, $inline );
					} else {
						$this->add_paragraph( $blocks, $this->inner_html( $node ) );
					}
					break;
				case 'h1':
				case 'h2':
				case 'h3':
				case 'h4':
				case 'h5':
				case 'h6':
					$text = trim( $node->textContent );
					if ( '' !== $text ) {
						$this->heading = $text;
						$blocks[]      = Blocks::heading( esc_html( $text ), (int) substr( $tag, 1 ) );
					}
					break;
				case 'ul':
				case 'ol':
					$items = array();
					foreach ( $node->childNodes as $item ) {
						if ( $item instanceof DOMElement && 'li' === strtolower( $item->tagName ) ) {
							$items[] = trim( $this->inner_html( $item ) );
						}
					}
					$items = array_values( array_filter( $items, static fn( $i ) => '' !== $i ) );
					if ( $items ) {
						$blocks[] = Blocks::list( $items, 'ol' === $tag );
					}
					break;
				case 'table':
					$blocks[] = $this->table( $node );
					break;
				case 'img':
					array_push( $blocks, ...$this->image_block( $node->getAttribute( 'src' ) ) );
					break;
				case 'iframe':
					$src = $node->getAttribute( 'src' );
					if ( preg_match( '#youtube\.com/embed/([\w-]+)#', $src, $m ) ) {
						$blocks[] = Blocks::embed( 'https://www.youtube.com/watch?v=' . $m[1] );
					} elseif ( preg_match( '#facebook\.com/plugins/video\.php\?(?:[^"]*&)?href=([^&"]+)#', html_entity_decode( $src ), $m ) ) {
						// Facebook's player needs its SDK and a login wall; link to the video instead.
						$blocks[] = Blocks::video_link( rawurldecode( $m[1] ), 'Facebook' );
					}
					break;
				case 'hr':
					$blocks[] = Blocks::separator();
					break;
				case 'blockquote':
					$blocks[] = Blocks::quote( trim( $this->inner_html( $node ) ) );
					break;
				default:
					$this->collect( $node, $blocks, $inline );
					$this->flush( $blocks, $inline );
			}
		}
	}

	/**
	 * Emits pending inline content as a paragraph.
	 *
	 * @param array[] $blocks Blocks so far.
	 * @param string  $inline Pending inline HTML.
	 */
	private function flush( array &$blocks, string &$inline ): void {
		$this->add_paragraph( $blocks, $inline );
		$inline = '';
	}

	/**
	 * Adds a paragraph unless it is empty.
	 *
	 * @param array[] $blocks Blocks so far.
	 * @param string  $html Inline HTML.
	 */
	private function add_paragraph( array &$blocks, string $html ): void {
		$html = trim( (string) preg_replace( '/^(\s|&nbsp;|\x{00A0}|<br\s*\/?>)+|(\s|&nbsp;|\x{00A0}|<br\s*\/?>)+$/u', '', $html ) );
		if ( '' !== trim( wp_strip_all_tags( html_entity_decode( $html ) ), " \t\n\r\0\x0B\u{00A0}" ) ) {
			$blocks[] = Blocks::paragraph( $html );
		}
	}

	/**
	 * A clean table block from a legacy table.
	 *
	 * @param DOMElement $table Table element.
	 */
	private function table( DOMElement $table ): array {
		$rows = array();
		$head = false;
		foreach ( $table->getElementsByTagName( 'tr' ) as $index => $row ) {
			$cells = array();
			foreach ( $row->childNodes as $cell ) {
				if ( $cell instanceof DOMElement && in_array( strtolower( $cell->tagName ), array( 'td', 'th' ), true ) ) {
					$head    = $head || ( 0 === $index && 'th' === strtolower( $cell->tagName ) );
					$cells[] = trim( $this->inner_html( $cell, true ) );
				}
			}
			if ( array_filter( $cells ) ) {
				$rows[] = $cells;
			}
		}
		return Blocks::table( $rows, $head );
	}

	/**
	 * Inline HTML inside an element, with block-level wrappers flattened.
	 *
	 * @param DOMElement $element Element.
	 * @param bool       $join_paragraphs Join inner paragraphs with line breaks.
	 */
	private function inner_html( DOMElement $element, bool $join_paragraphs = false ): string {
		$html = '';
		foreach ( $element->childNodes as $child ) {
			if ( XML_TEXT_NODE === $child->nodeType ) {
				$html .= esc_html( $child->nodeValue );
			} elseif ( $child instanceof DOMElement ) {
				$tag = strtolower( $child->tagName );
				if ( in_array( $tag, array( 'p', 'div' ), true ) ) {
					$inner = trim( $this->inner_html( $child, $join_paragraphs ) );
					$html .= ( '' !== $html && '' !== $inner ? '<br>' : '' ) . $inner;
				} else {
					$html .= $this->inline_html( $child );
				}
			}
		}
		return $html;
	}

	/**
	 * Clean HTML for an inline element: kept tags lose their attributes
	 * (except a href); wrappers like span are unwrapped.
	 *
	 * @param DOMElement $element Element.
	 */
	private function inline_html( DOMElement $element ): string {
		$tag   = strtolower( $element->tagName );
		$inner = $this->inner_html( $element );
		if ( 'br' === $tag ) {
			return '<br>';
		}
		if ( 'b' === $tag ) {
			$tag = 'strong';
		}
		if ( ! in_array( $tag, self::INLINE, true ) ) {
			return $inner;
		}
		if ( '' === trim( wp_strip_all_tags( $inner ) ) ) {
			return $inner;
		}
		if ( 'a' === $tag ) {
			return '<a href="' . esc_url( $element->getAttribute( 'href' ) ) . '">' . trim( $inner ) . '</a>';
		}
		return "<$tag>$inner</$tag>";
	}

	/**
	 * Inline HTML from a shortcode attribute value.
	 *
	 * @param string $value Attribute value.
	 */
	private function inline( string $value ): string {
		return esc_html( trim( wp_strip_all_tags( html_entity_decode( $value, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) ) );
	}

	/**
	 * Replaces an element with its children.
	 *
	 * @param DOMElement $element Element.
	 */
	private static function unwrap( DOMElement $element ): void {
		$parent = $element->parentNode;
		if ( ! $parent ) {
			return;
		}
		while ( $element->firstChild ) {
			$parent->insertBefore( $element->firstChild, $element );
		}
		$parent->removeChild( $element );
	}
}
