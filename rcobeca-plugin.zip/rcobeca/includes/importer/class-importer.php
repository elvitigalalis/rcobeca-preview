<?php
/**
 * Runs the importer steps.
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

use RCOBECA\Redirects;

/**
 * Builds the site from the snapshot by running every step in
 * includes/importer/steps/ in file-name order. A step is a PHP file that
 * returns a callable taking a Context; its name is the file name without the
 * order prefix and extension (20-static-pages.php is "static-pages").
 *
 * Every step must be repeatable: write through Context::upsert() and Media,
 * which find what an earlier run made. Redirects and checklist rows a step
 * recorded last time are cleared before it runs again.
 */
class Importer {

	/**
	 * Sets up a run.
	 *
	 * @param Snapshot      $snapshot Content snapshot.
	 * @param Media         $media Media importer.
	 * @param callable|null $logger Receives log lines; silent by default.
	 */
	public function __construct(
		private Snapshot $snapshot,
		private Media $media,
		private $logger = null
	) {
		$this->logger ??= static function (): void {};
	}

	/**
	 * Every step, in run order.
	 *
	 * @return array<string, string> Step name => file.
	 */
	public static function steps(): array {
		$files = glob( __DIR__ . '/steps/*.php' );
		sort( $files );
		$steps = array();
		foreach ( $files as $file ) {
			$steps[ (string) preg_replace( '/^\d+-/', '', basename( $file, '.php' ) ) ] = $file;
		}
		return $steps;
	}

	/**
	 * Runs all steps, or only the named ones.
	 *
	 * @param string[] $only Step names; empty runs everything.
	 * @throws \InvalidArgumentException For an unknown step name.
	 */
	public function run( array $only = array() ): void {
		$steps   = self::steps();
		$unknown = array_diff( $only, array_keys( $steps ) );
		if ( $unknown ) {
			throw new \InvalidArgumentException( esc_html( 'Unknown importer step: ' . implode( ', ', $unknown ) ) );
		}

		// Imported content is trusted markup; don't let kses strip it when no user is logged in (WP-CLI).
		kses_remove_filters();
		$converter = new Converter( $this->snapshot, $this->media, new Links() );
		foreach ( $steps as $name => $file ) {
			if ( $only && ! in_array( $name, $only, true ) ) {
				continue;
			}
			$context = new Context( $name, $this->snapshot, $this->media, $converter, $this->logger );
			$context->log( 'running' );
			Redirects::clear_step( $name );
			Checklist::clear_step( $name );
			$step = require $file;
			Checklist::buffer();
			try {
				$step( $context );
			} finally {
				Checklist::flush();
			}
		}
	}
}
