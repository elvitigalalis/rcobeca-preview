<?php
/**
 * Decides what happens to each link in imported content.
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

/**
 * Link rules for imported content:
 * - junk (Google+, share buttons, author bylines, theme team pages) is removed;
 * - empty and script links are unwrapped to plain text;
 * - dead external links point to their Wayback snapshot, or are unwrapped and
 *   marked "(archive unavailable)", per data/dead-links.tsv;
 * - files on the old site (uploads, legacy root PDFs) are imported as media;
 * - other old-site links become root-relative, so the redirect map takes them
 *   to their new home.
 */
class Links {

	public const KEEP        = 'keep';
	public const REMOVE      = 'remove';
	public const UNWRAP      = 'unwrap';
	public const UNAVAILABLE = 'unavailable';
	public const UPLOAD      = 'upload';

	/**
	 * Dead URL => Wayback snapshot URL or "unavailable".
	 *
	 * @var array<string, string>
	 */
	private array $dead;

	/**
	 * Loads the dead-link map.
	 *
	 * @param string|null $dead_links TSV of dead URL and snapshot; defaults to data/dead-links.tsv.
	 */
	public function __construct( ?string $dead_links = null ) {
		$this->dead = array();
		$file       = $dead_links ?? RCOBECA_DIR . '/data/dead-links.tsv';
		foreach ( file( $file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES ) as $line ) {
			if ( '#' !== $line[0] && str_contains( $line, "\t" ) ) {
				[ $url, $snapshot ]              = explode( "\t", $line, 2 );
				$this->dead[ self::key( $url ) ] = trim( $snapshot );
			}
		}
	}

	/**
	 * What to do with a link.
	 *
	 * @param string $href The link's href.
	 * @return array{action: string, href: string}
	 */
	public function rewrite( string $href ): array {
		$href = trim( $href );
		$host = strtolower( (string) wp_parse_url( $href, PHP_URL_HOST ) );
		$path = (string) wp_parse_url( $href, PHP_URL_PATH );

		if ( '' === $href || '#' === $href[0] || preg_match( '/^javascript:/i', $href ) ) {
			return self::result( self::UNWRAP );
		}
		if ( preg_match( '/^mailto:/i', $href ) ) {
			return self::result( self::KEEP, 'mailto:' . trim( substr( $href, 7 ) ) );
		}
		if ( self::is_junk( $href, $host, $path ) ) {
			return self::result( self::REMOVE );
		}
		if ( isset( $this->dead[ self::key( $href ) ] ) ) {
			$snapshot = $this->dead[ self::key( $href ) ];
			return 'unavailable' === $snapshot ? self::result( self::UNAVAILABLE ) : self::result( self::KEEP, $snapshot );
		}
		if ( '' === $host || preg_match( '/(^|\.)rcobeca\.org$/', $host ) ) {
			if ( preg_match( '/\.(pdf|jpe?g|png|gif|docx?|xlsx?|ics)$/i', $path ) ) {
				return self::result( self::UPLOAD, '' === $host ? 'https://rcobeca.org' . $path : $href );
			}
			$query = (string) wp_parse_url( $href, PHP_URL_QUERY );
			return self::result( self::KEEP, ( '' === $path ? '/' : $path ) . ( $query ? "?$query" : '' ) );
		}
		return self::result( self::KEEP, $href );
	}

	/**
	 * Whether a link is theme or plugin junk the new site drops entirely.
	 *
	 * @param string $href Link.
	 * @param string $host Its host.
	 * @param string $path Its path.
	 */
	private static function is_junk( string $href, string $host, string $path ): bool {
		if ( 'plus.google.com' === $host || str_contains( $href, '/sharer' ) || str_contains( $href, 'twitter.com/intent' ) || str_contains( $href, 'twitter.com/home?status' ) ) {
			return true;
		}
		// Author bylines were linked as http://webadmin, http://Sachith%20Gamage.
		if ( '' !== $host && ! str_contains( $host, '.' ) ) {
			return true;
		}
		return (bool) preg_match( '#^/(newsite/)?(author|dgtfw_team|dgtfw_team_category)(/|$)#', $path );
	}

	/**
	 * Lookup key for a URL: no scheme, fragment or trailing slash.
	 *
	 * @param string $url URL.
	 */
	private static function key( string $url ): string {
		return rtrim( (string) preg_replace( array( '#^https?://#i', '/#.*$/' ), '', $url ), '/' );
	}

	/**
	 * Builds a result.
	 *
	 * @param string $action One of the constants.
	 * @param string $href New href.
	 */
	private static function result( string $action, string $href = '' ): array {
		return array(
			'action' => $action,
			'href'   => $href,
		);
	}
}
