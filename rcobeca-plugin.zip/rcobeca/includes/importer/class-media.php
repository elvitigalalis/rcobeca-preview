<?php
/**
 * Imports media from the old site's public uploads.
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

/**
 * Fetches a file from rcobeca.org once (browser-like headers, or the server
 * answers 406), keeps the original in the media cache, and adds an optimised
 * copy to the media library. Re-imports find the existing attachment by its
 * source URL, so nothing is duplicated.
 *
 * Alt text: the old site's alt when it had one; otherwise text generated from
 * the context the step or converter gives ("about"), flagged for review with
 * the `_rcobeca_alt_needs_review` meta.
 */
class Media {

	/**
	 * Longest edge of an imported image, in pixels.
	 */
	public const MAX_EDGE = 1920;

	/**
	 * JPEG and WebP quality for the optimised copy.
	 */
	public const QUALITY = 82;

	/**
	 * Headers the old server needs to answer at all.
	 */
	public const BROWSER_HEADERS = array(
		'User-Agent'      => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0 Safari/537.36',
		'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/*,*/*;q=0.8',
		'Accept-Language' => 'en-US,en;q=0.9',
	);

	/**
	 * Media cache directory.
	 *
	 * @var string
	 */
	private string $cache_dir;

	/**
	 * Sets up the importer.
	 *
	 * @param string $cache_dir Where downloaded originals are kept between runs.
	 * @param bool   $offline Use the cache only; never download.
	 * @param int    $pause_ms Pause after each download, to be polite to the old server.
	 */
	public function __construct( string $cache_dir, private bool $offline = false, private int $pause_ms = 500 ) {
		$this->cache_dir = rtrim( $cache_dir, '/' );
	}

	/**
	 * The media cache unless the command says otherwise: RCOBECA_MEDIA_CACHE_DIR,
	 * else wp-content/rcobeca-media-cache (mapped to the repo's .cache/media by
	 * .wp-env.json, outside Git).
	 */
	public static function default_cache_dir(): string {
		return defined( 'RCOBECA_MEDIA_CACHE_DIR' ) ? RCOBECA_MEDIA_CACHE_DIR : WP_CONTENT_DIR . '/rcobeca-media-cache';
	}

	/**
	 * The attachment already imported from an old-site URL, without touching
	 * its alt text; 0 if there is none.
	 *
	 * @param string $url File URL on the old site.
	 */
	public function find( string $url ): int {
		$url      = self::canonical( $url );
		$existing = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'any',
				'meta_key'       => '_rcobeca_source_url', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => $url, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'fields'         => 'ids',
				'posts_per_page' => -1,
			)
		);
		// MySQL matches case-insensitively, but the old server doesn't:
		// ImageFrame.jpg and imageframe.jpg are different photos.
		$existing = array_values( array_filter( $existing, static fn( $id ) => get_post_meta( $id, '_rcobeca_source_url', true ) === $url ) );
		return $existing ? (int) $existing[0] : 0;
	}

	/**
	 * Imports a file, or returns the attachment already imported from it.
	 *
	 * @param string $url File URL on the old site.
	 * @param array  $args {
	 *     Optional.
	 *     @type string $alt   Alt text known to be right (the old site's, or written by hand).
	 *     @type string $about What the image shows or where it sat (a heading, page title,
	 *                         link text); generated alt text is built from it and flagged.
	 *     @type string $title Attachment title.
	 * }
	 * @return int Attachment ID, or 0 when the file can't be had.
	 */
	public function import( string $url, array $args = array() ): int {
		$existing = $this->find( $url );
		if ( $existing ) {
			$this->describe( $existing, $args );
			return $existing;
		}
		$url = self::canonical( $url );

		$original = $this->fetch( $url );
		if ( null === $original ) {
			return 0;
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$name = sanitize_file_name( rawurldecode( basename( (string) wp_parse_url( $url, PHP_URL_PATH ) ) ) );
		$work = get_temp_dir() . 'rcobeca-' . wp_generate_password( 8, false ) . '/';
		wp_mkdir_p( $work );
		copy( $original, $work . $name );
		$this->optimise( $work . $name );

		$title = $args['title'] ?? '';
		$id    = media_handle_sideload(
			array(
				'name'     => $name,
				'tmp_name' => $work . $name,
			),
			0,
			'' !== $title ? $title : null
		);
		array_map( 'wp_delete_file', (array) glob( $work . '*' ) );
		rmdir( $work ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir
		if ( is_wp_error( $id ) ) {
			return 0;
		}

		update_post_meta( $id, '_rcobeca_source_url', $url );
		$this->describe( (int) $id, $args );
		return (int) $id;
	}

	/**
	 * Sets an image's alt text: the given alt, else text generated from its
	 * context and flagged for review. Generated alt is refreshed on later runs
	 * until someone edits it.
	 *
	 * @param int   $id Attachment ID.
	 * @param array $args See import().
	 */
	private function describe( int $id, array $args ): void {
		if ( ! wp_attachment_is_image( $id ) ) {
			return;
		}
		$current   = (string) get_post_meta( $id, '_wp_attachment_image_alt', true );
		$generated = (string) get_post_meta( $id, '_rcobeca_generated_alt', true );
		if ( '' !== $current && $current !== $generated ) {
			return; // Written by the old site, a step or a person: keep it.
		}
		$alt = trim( (string) ( $args['alt'] ?? '' ) );
		if ( '' !== $alt ) {
			delete_post_meta( $id, '_rcobeca_alt_needs_review' );
			delete_post_meta( $id, '_rcobeca_generated_alt' );
		} else {
			$alt = self::generated_alt( (string) ( $args['about'] ?? '' ), (string) get_the_title( $id ) );
			update_post_meta( $id, '_rcobeca_alt_needs_review', '1' );
			update_post_meta( $id, '_rcobeca_generated_alt', $alt );
		}
		update_post_meta( $id, '_wp_attachment_image_alt', $alt );
	}

	/**
	 * The original file, from the cache or downloaded into it.
	 *
	 * @param string $url File URL.
	 * @return string|null Path, or null when offline and uncached, or the download failed.
	 */
	private function fetch( string $url ): ?string {
		$file = $this->cache_dir . '/' . self::cache_name( $url );
		if ( file_exists( $file ) && filesize( $file ) > 0 ) {
			return $file;
		}
		if ( $this->offline ) {
			return null;
		}
		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 120,
				'headers' => self::BROWSER_HEADERS,
			)
		);
		if ( $this->pause_ms > 0 ) {
			usleep( $this->pause_ms * 1000 );
		}
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return null;
		}
		wp_mkdir_p( $this->cache_dir );
		file_put_contents( $file, wp_remote_retrieve_body( $response ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		return $file;
	}

	/**
	 * Shrinks an image to MAX_EDGE and recompresses it, in place. Files that
	 * aren't images, and images already small, are left alone.
	 *
	 * @param string $path File path.
	 */
	private function optimise( string $path ): void {
		$editor = wp_get_image_editor( $path );
		if ( is_wp_error( $editor ) ) {
			return;
		}
		$size = $editor->get_size();
		if ( max( $size['width'], $size['height'] ) <= self::MAX_EDGE && filesize( $path ) < 500 * 1024 ) {
			return;
		}
		$editor->resize( self::MAX_EDGE, self::MAX_EDGE );
		$editor->set_quality( self::QUALITY );
		$saved = $editor->save( dirname( $path ) . '/optimised-' . basename( $path ) );
		clearstatcache();
		if ( ! is_wp_error( $saved ) && filesize( $saved['path'] ) < filesize( $path ) ) {
			rename( $saved['path'], $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
		} elseif ( ! is_wp_error( $saved ) ) {
			wp_delete_file( $saved['path'] );
		}
	}

	/**
	 * Alt text from context (the heading or caption the image sat under, or a
	 * description the step gives), else the file title.
	 *
	 * @param string $about Context.
	 * @param string $title Attachment title.
	 */
	private static function generated_alt( string $about, string $title ): string {
		$about = trim( wp_strip_all_tags( $about ) );
		return '' !== $about ? $about : trim( (string) preg_replace( '/[-_]+/', ' ', $title ) );
	}

	/**
	 * One spelling per file: https, rcobeca.org, no query or fragment.
	 *
	 * @param string $url URL.
	 */
	public static function canonical( string $url ): string {
		$url = (string) preg_replace( array( '/[?#].*$/', '#^https?://(www\.)?rcobeca\.org#i' ), array( '', 'https://rcobeca.org' ), trim( $url ) );
		return str_replace( ' ', '%20', $url );
	}

	/**
	 * Cache file name for a URL: readable, unique.
	 *
	 * @param string $url URL.
	 */
	private static function cache_name( string $url ): string {
		return substr( sha1( $url ), 0, 12 ) . '-' . sanitize_file_name( rawurldecode( basename( (string) wp_parse_url( $url, PHP_URL_PATH ) ) ) );
	}
}
