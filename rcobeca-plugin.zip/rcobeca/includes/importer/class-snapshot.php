<?php
/**
 * Read access to the committed content snapshot (docs/research/ in the repo).
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

use RuntimeException;

/**
 * The public crawl of rcobeca.org (raw/), laid out as in docs/research/.
 */
class Snapshot {

	/**
	 * Parsed JSON files, by relative path.
	 *
	 * @var array<string, array>
	 */
	private array $json = array();

	/**
	 * Snapshot root directory.
	 *
	 * @var string
	 */
	private string $dir;

	/**
	 * Opens the snapshot at a directory.
	 *
	 * @param string $dir Directory holding raw/.
	 */
	public function __construct( string $dir ) {
		$this->dir = rtrim( $dir, '/' );
	}

	/**
	 * Where the snapshot lives unless the command says otherwise: the
	 * RCOBECA_SNAPSHOT_DIR constant, else wp-content/rcobeca-snapshot (mapped by
	 * .wp-env.json and unzipped there by the Playground blueprint).
	 */
	public static function default_dir(): string {
		return defined( 'RCOBECA_SNAPSHOT_DIR' ) ? RCOBECA_SNAPSHOT_DIR : WP_CONTENT_DIR . '/rcobeca-snapshot';
	}

	/**
	 * Absolute path of a snapshot file.
	 *
	 * @param string $relative Path such as raw/api/pages_1.json.
	 * @throws RuntimeException When the file is missing.
	 */
	public function path( string $relative ): string {
		$path = $this->dir . '/' . ltrim( $relative, '/' );
		if ( ! file_exists( $path ) ) {
			throw new RuntimeException( esc_html( "Snapshot file missing: $path" ) );
		}
		return $path;
	}

	/**
	 * Contents of a snapshot file.
	 *
	 * @param string $relative Path such as raw/urls.txt.
	 */
	public function read( string $relative ): string {
		return (string) file_get_contents( $this->path( $relative ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	}

	/**
	 * A decoded JSON file.
	 *
	 * @param string $relative Path such as raw/api/posts_1.json.
	 */
	public function json( string $relative ): array {
		if ( ! isset( $this->json[ $relative ] ) ) {
			$this->json[ $relative ] = (array) json_decode( $this->read( $relative ), true );
		}
		return $this->json[ $relative ];
	}

	/**
	 * A page from the REST dump, by slug. Its content.rendered holds the
	 * WPBakery shortcodes for Converter::to_blocks().
	 *
	 * @param string $slug Page slug, e.g. about-us.
	 * @throws RuntimeException When no page has that slug.
	 */
	public function page( string $slug ): array {
		return $this->find( 'raw/api/pages_1.json', $slug );
	}

	/**
	 * A post (legacy "Project") from the REST dump, by slug.
	 *
	 * @param string $slug Post slug.
	 */
	public function post( string $slug ): array {
		return $this->find( 'raw/api/posts_1.json', $slug );
	}

	/**
	 * Every post in the REST dump.
	 *
	 * @return array[]
	 */
	public function posts(): array {
		return $this->json( 'raw/api/posts_1.json' );
	}

	/**
	 * A media-library item from the index: id, url, title, alt, mime, parent.
	 *
	 * @param int $id Attachment ID on the old site.
	 */
	public function media( int $id ): ?array {
		foreach ( $this->json( 'raw/api/media_index.json' ) as $item ) {
			if ( (int) $item['id'] === $id ) {
				return $item;
			}
		}
		return null;
	}

	/**
	 * The media-library item behind an uploads URL, including resized copies
	 * such as photo-1024x768.jpg.
	 *
	 * @param string $url Image or file URL on the old site.
	 */
	public function media_by_url( string $url ): ?array {
		$wanted = self::original_upload_path( $url );
		foreach ( $this->json( 'raw/api/media_index.json' ) as $item ) {
			if ( self::original_upload_path( $item['url'] ) === $wanted ) {
				return $item;
			}
		}
		return null;
	}

	/**
	 * Every URL in the old sitemap (raw/urls.txt), as paths such as /about-us/.
	 *
	 * @return string[]
	 */
	public function sitemap_paths(): array {
		$lines = array_filter( array_map( 'trim', explode( "\n", $this->read( 'raw/urls.txt' ) ) ) );
		return array_values( array_map( static fn( $url ) => (string) wp_parse_url( $url, PHP_URL_PATH ), $lines ) );
	}

	/**
	 * Every public media file of the old site: each item of its media library,
	 * and each upload an old page links to, as upload paths such as
	 * 2017/01/Picture3.jpg (resized and "-scaled" copies count as their
	 * original).
	 *
	 * @return string[] Upload paths, sorted.
	 */
	public function public_media(): array {
		$files = array();
		foreach ( $this->json( 'raw/api/media_index.json' ) as $item ) {
			$files[ self::upload_file( $item['url'] ) ] = true;
		}
		if ( is_dir( $this->dir . '/raw/html' ) ) {
			$pages = new \RecursiveIteratorIterator( new \RecursiveDirectoryIterator( $this->dir . '/raw/html', \FilesystemIterator::SKIP_DOTS ) );
			foreach ( $pages as $page ) {
				preg_match_all( '#https?://(?:www\.)?rcobeca\.org/newsite/wp-content/uploads/[^"\'\s)<>\\\\&?\#]+#', (string) file_get_contents( $page->getPathname() ), $links ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a snapshot file.
				foreach ( $links[0] as $link ) {
					$files[ self::upload_file( $link ) ] = true;
				}
			}
		}
		unset( $files[''] );
		$files = array_keys( $files );
		sort( $files );
		return $files;
	}

	/**
	 * An upload URL's file, as an upload path without a WordPress size or
	 * "-scaled" suffix: https://rcobeca.org/newsite/wp-content/uploads/2017/01/Picture3-300x225.jpg
	 * is 2017/01/Picture3.jpg. Case is kept (ImageFrame.jpg and imageframe.jpg
	 * are different photos). Empty for anything else.
	 *
	 * @param string $url URL.
	 */
	public static function upload_file( string $url ): string {
		$url = rawurldecode( explode( '%26', $url )[0] ); // %26: a share button's URL tacked on.
		if ( ! preg_match( '#/uploads/(.+\.(?:jpe?g|png|gif|webp|pdf|ics|docx?|mp[34]))(?=$|[^\w.-])#i', $url, $match ) ) {
			return '';
		}
		return (string) preg_replace( array( '/-\d+x\d+(?=\.\w+$)/', '/-scaled(?=\.\w+$)/' ), '', $match[1] );
	}

	/**
	 * Path of an upload without a WordPress size suffix, for matching copies.
	 *
	 * @param string $url Upload URL.
	 */
	private static function original_upload_path( string $url ): string {
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		return strtolower( (string) preg_replace( '/-(\d+x\d+|scaled)(?=\.\w+$)/', '', $path ) );
	}

	/**
	 * An item by slug from a REST dump.
	 *
	 * @param string $file REST dump.
	 * @param string $slug Slug.
	 * @throws RuntimeException When missing.
	 */
	private function find( string $file, string $slug ): array {
		foreach ( $this->json( $file ) as $item ) {
			if ( $item['slug'] === $slug ) {
				return $item;
			}
		}
		throw new RuntimeException( esc_html( "No item with slug $slug in $file" ) );
	}
}
