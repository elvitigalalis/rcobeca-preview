<?php
/**
 * WP-CLI commands: `wp rcobeca import` and `wp rcobeca checklist`.
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

use WP_CLI;

if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) {
	return;
}

/**
 * Builds the site from the committed snapshot. Safe to run again: it updates
 * what an earlier run made instead of duplicating it.
 *
 * ## OPTIONS
 *
 * [--step=<names>]
 * : Run only these steps (comma-separated), e.g. --step=static-pages.
 *
 * [--source=<dir>]
 * : Snapshot directory holding raw/. Default: wp-content/rcobeca-snapshot.
 *
 * [--media-cache=<dir>]
 * : Where downloaded originals are kept. Default: wp-content/rcobeca-media-cache.
 *
 * [--offline]
 * : Never download; use only media already in the cache.
 *
 * ## EXAMPLES
 *
 *     wp rcobeca import
 *     wp rcobeca import --step=static-pages --offline
 *
 * @param array $args Positional arguments (none).
 * @param array $assoc Options.
 */
function import_command( array $args, array $assoc ): void {
	$importer = new Importer(
		new Snapshot( $assoc['source'] ?? Snapshot::default_dir() ),
		new Media( $assoc['media-cache'] ?? Media::default_cache_dir(), (bool) ( $assoc['offline'] ?? false ) ),
		static function ( string $line ): void {
			WP_CLI::log( $line );
		}
	);
	$only     = isset( $assoc['step'] ) ? array_filter( array_map( 'trim', explode( ',', $assoc['step'] ) ) ) : array();
	$importer->run( $only );
	flush_rewrite_rules();
	WP_CLI::success( 'Import complete.' );
}

WP_CLI::add_command( 'rcobeca import', __NAMESPACE__ . '\import_command' );

/**
 * Prints the migration checklist (Markdown): every old URL and content block,
 * its new home or the ticket that owns it, facts to confirm before launch and
 * images whose generated alt text needs review. Run after `wp rcobeca import`.
 *
 * ## OPTIONS
 *
 * [--source=<dir>]
 * : Snapshot directory. Default: wp-content/rcobeca-snapshot.
 *
 * ## EXAMPLES
 *
 *     wp rcobeca checklist > migration-checklist.md
 *
 * @param array $args Positional arguments (none).
 * @param array $assoc Options.
 */
function checklist_command( array $args, array $assoc ): void {
	WP_CLI::line( ( new Checklist( new Snapshot( $assoc['source'] ?? Snapshot::default_dir() ) ) )->markdown() );
}

WP_CLI::add_command( 'rcobeca checklist', __NAMESPACE__ . '\checklist_command' );
