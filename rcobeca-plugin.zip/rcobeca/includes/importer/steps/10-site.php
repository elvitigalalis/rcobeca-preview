<?php
/**
 * Importer step: site settings every page depends on.
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

return static function ( Context $import ): void {
	global $wp_rewrite;
	// Plain /slug/ URLs, as on the old site. Set through $wp_rewrite so the
	// rules flushed after the import use it.
	$wp_rewrite->set_permalink_structure( '/%postname%/' );
	update_option( 'blogname', 'RCOBECA' );
	update_option( 'blogdescription', 'Royal College Old Boys’ East Coast Association' );
	$import->log( 'permalinks and site title set' );
};
