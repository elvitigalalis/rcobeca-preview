<?php
/**
 * Importer step: the static pages (Our Story, Royal College) and the
 * redirects from their old URLs. Contact, with its form,
 * is built by the join-and-forms step.
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

/*
 * Our Story, from the old "Who are we" page.
 */
$our_story = static function ( Context $import ): int {
	$about  = $import->snapshot->page( 'about-us' );
	$blocks = $import->converter->to_blocks( $about['content']['rendered'], 'Our Story' );

	$look_back = Blocks::section( $blocks, 'A look back' );
	foreach ( $look_back as &$block ) {
		$block['markup'] = str_replace( 'favorable manor', 'favorable manner', $block['markup'] );
	}
	unset( $block );

	// The old page's photo of the Past Presidents ends "A look back"; it opens
	// the page instead, under the lead.
	$presidents = array_values( array_filter( $look_back, static fn( $block ) => str_contains( $block['markup'], 'DSP_8411' ) ) );
	$look_back  = array_values( array_filter( $look_back, static fn( $block ) => ! str_contains( $block['markup'], 'DSP_8411' ) ) );

	// "Who are we": its founding paragraph becomes the lead, and the old site's
	// Foundation line, kept verbatim, is quoted as a statement.
	$who_we_are = Blocks::section( $blocks, 'Who are we ?' );
	$lead       = $who_we_are ? array( Blocks::paragraph( Blocks::inner( array_shift( $who_we_are ) ), 'has-large-font-size' ) ) : array();
	foreach ( $who_we_are as &$block ) {
		if ( str_starts_with( trim( $block['text'] ), 'A public non-profit 501(c)3 foundation' ) ) {
			$block = Blocks::quote( Blocks::inner( $block ), 'Who are we, rcobeca.org' );
		}
	}
	unset( $block );

	$page = $import->upsert(
		'page:our-story',
		array(
			'post_type'    => 'page',
			'post_name'    => 'our-story',
			'post_title'   => 'Our Story',
			'post_content' => Blocks::markup(
				array_merge(
					$lead,
					$presidents,
					array( Blocks::heading( 'Who we are' ) ),
					$who_we_are,
					array( Blocks::heading( 'A look back' ) ),
					$look_back,
					// The old HISTORY table, now generated from Committee Terms (#6).
					array( Blocks::heading( 'Past Presidents' ) ),
					array( array( 'markup' => '<!-- wp:rcobeca/past-presidents {"showHighlights":true} /-->' ) )
				)
			),
		)
	);
	$import->redirect( '/about-us/', $page );
	$import->moved( '/about-us/', 'Who are we', $page );
	$import->moved( '/about-us/', 'A look back', $page );
	$import->moved( '/about-us/', 'Past Presidents photo', $page );
	$import->moved( '/about-us/', 'HISTORY table', $page );
	$import->handoff( '/about-us/', 'Join Us Today button', '#9', 'Join or Renew' );
	$import->dropped( '/about-us/', 'Crest image', 'the theme draws the crest (#3)' );
	$import->dropped( '/about-us/', 'Spacer image', 'layout remnant of the pre-2017 site, already 404' );
	return $page;
};

/*
 * Royal College, from the old page of the same name.
 */
$royal_college = static function ( Context $import ): int {
	$source = $import->snapshot->page( 'royal_college' );
	$blocks = $import->converter->to_blocks( $source['content']['rendered'], 'Royal College' );

	$song = array();
	foreach ( Blocks::section( $blocks, 'School of our fathers' ) as $block ) {
		$lines  = preg_replace( array( '#\s*<br\s*/?>\s*#', '#<br>(?=(</\w+>)*$)#' ), array( '<br>', '' ), trim( Blocks::inner( $block ) ) );
		$song[] = str_contains( $block['text'], 'Words by' ) ? $block : Blocks::verse( $lines );
	}

	// Principals, their terms in one style: "(1835 – 1838)", one year once,
	// "present" for the current principal. The years are as published.
	$principals = array();
	foreach ( Blocks::section( $blocks, 'Principals of Royal College' ) as $block ) {
		foreach ( preg_split( '#<br\s*/?>#', Blocks::inner( $block ) ) as $line ) {
			$line = trim( wp_strip_all_tags( $line ) );
			if ( '' === $line ) {
				continue;
			}
			$principals[] = (string) preg_replace_callback(
				'/\s*\(\s*(\d{4})\s*[-–]\s*(\d{4}|present)\s*\)$/iu',
				static function ( array $term ): string {
					$end = strtolower( $term[2] );
					return ' (' . ( $term[1] === $end ? $term[1] : $term[1] . ' – ' . $end ) . ')';
				},
				$line
			);
		}
	}

	$photo = $import->media->import(
		'https://rcobeca.org/newsite/wp-content/uploads/2016/06/8372270-1.jpg',
		array(
			'about' => 'Royal College, Colombo: the main building seen through the trees',
			'title' => 'Royal College, Colombo',
		)
	);

	$page = $import->upsert(
		'page:royal-college',
		array(
			'post_type'    => 'page',
			'post_name'    => 'royal-college',
			'post_title'   => 'Royal College',
			'post_content' => Blocks::markup(
				array_merge(
					array( Blocks::quote( 'School where our fathers learned the way before us', 'College Song' ) ),
					Blocks::section( $blocks, 'Royal College' ),
					array(
						Blocks::heading( 'College Song' ),
						Blocks::heading( 'School of our fathers', 3 ),
					),
					$song,
					array( Blocks::heading( 'A look back' ) ),
					Blocks::section( $blocks, 'A look back' ),
					array(
						Blocks::heading( 'Principals of Royal College' ),
						Blocks::list( $principals ),
					)
				)
			),
		),
		$photo ? array( '_thumbnail_id' => $photo ) : array()
	);
	return $page;
};

return static function ( Context $import ) use ( $our_story, $royal_college ): void {
	$story   = $our_story( $import );
	$college = $royal_college( $import );
	$import->redirect( '/royal_college/', $college );
	foreach ( array( 'Royal College (Since 1835)', 'College Song', 'A look back', 'Principals of Royal College' ) as $block ) {
		$import->moved( '/royal_college/', $block, $college );
	}
	$import->handoff( '/royal_college/', 'Online Destinations', '#9', 'Royal College Worldwide' );
	$import->dropped( '/royal_college/', 'Background images', 'decorative; the building photo is kept as the featured image' );
	$import->check( 'Royal College page: the student population is given as both "over 7500" and "close to 7,000", and the school as "over 150 years" old (founded 1835). Confirm the figures to show.' );

	// Pages of the 2004–2016 sites (docs/research/wayback-recovery.md).
	$legacy = array(
		'/history.htm'               => $story,
		'/index-1.html'              => $story,
		'/profile.htm'               => $college,
		'/school_of_our_fathers.htm' => $college,
		'/index-4.html'              => $college,
		'/hostel.htm'                => $college,
	);
	foreach ( $legacy as $from => $to ) {
		$import->redirect( $from, $to );
	}
	$import->dropped( '/hostel.htm', 'Article "Needed: a new hostel for Royal" (Carl Muller)', 'not on the current rcobeca.org: the new site carries only the live site’s content' );
};
