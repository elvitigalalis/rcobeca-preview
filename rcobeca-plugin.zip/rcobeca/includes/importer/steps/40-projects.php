<?php
/**
 * Importer step: Projects. The old site's 54 posts and 4 "causes" become
 * Projects with their final status and figures (data/projects.json), and
 * their old URLs redirect to them.
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

/*
 * The curated fields the old content doesn't hold as data.
 */
$data = static function (): array {
	return (array) json_decode( (string) file_get_contents( RCOBECA_DIR . '/data/projects.json' ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
};

/*
 * Applies typo fixes, drops a block that repeats the one before it, and
 * gathers runs of photos into galleries.
 */
$tidy = static function ( array $blocks, array $fixes ): array {
	$out = array();
	foreach ( $blocks as $block ) {
		foreach ( $fixes as [ $from, $to ] ) {
			$block['markup'] = str_replace( $from, $to, $block['markup'] );
			$block['text']   = str_replace( $from, $to, $block['text'] );
		}
		if ( $out && 'core/image' !== $block['name'] && end( $out )['markup'] === $block['markup'] ) {
			continue;
		}
		$out[] = $block;
	}
	return Blocks::galleries( $out );
};

/*
 * A card summary: the given one, else the story's first paragraph, shortened.
 */
$summary = static function ( array $blocks, string $given ): string {
	if ( '' !== $given ) {
		return $given;
	}
	foreach ( $blocks as $block ) {
		$text = trim( preg_replace( '/\s+/u', ' ', $block['text'] ) );
		if ( 'core/paragraph' === $block['name'] && str_word_count( $text ) >= 4 ) {
			return wp_trim_words( $text, 32, '…' );
		}
	}
	return '';
};

/*
 * The Project fields as post meta.
 */
$meta = static function ( array $fields ): array {
	$timeline = array();
	foreach ( $fields['timeline'] ?? array() as [ $date, $label, $text ] ) {
		$timeline[] = "$date | $label | $text";
	}
	return array_filter(
		array(
			'rcobeca_status'       => $fields['status'] ?? 'completed',
			'rcobeca_beneficiary'  => $fields['beneficiary'] ?? '',
			'rcobeca_place'        => $fields['place'] ?? '',
			'rcobeca_date'         => $fields['date'] ?? '',
			'rcobeca_amount_cents' => $fields['amount_cents'] ?? '',
			'rcobeca_amount_text'  => $fields['amount_text'] ?? '',
			'rcobeca_goal_cents'   => $fields['goal_cents'] ?? '',
			'rcobeca_timeline'     => implode( "\n", $timeline ),
		),
		static fn( $value ) => '' !== $value
	);
};

/*
 * The card photo (featured image) chosen in projects.json, which overrides the
 * default: one of the Project's own clear photos, or none (false) for a
 * type-only card. Returns $fallback when no choice is recorded.
 */
$card_photo = static function ( Context $import, array $fields, int $fallback ): int {
	if ( ! array_key_exists( 'card_photo', $fields ) ) {
		return $fallback;
	}
	if ( ! $fields['card_photo'] ) {
		return 0;
	}
	// Usually a photo the story already imported: found as is, so its alt text stays.
	$url = (string) $fields['card_photo'];
	return $import->media->find( $url ) ? $import->media->find( $url ) : $import->media->import( $url, array( 'about' => (string) ( $fields['title'] ?? '' ) ) );
};

/*
 * Sets or clears a Project's featured image, so a re-import drops one a
 * card no longer uses.
 */
$set_photo = static function ( int $id, int $photo ): void {
	if ( $photo ) {
		set_post_thumbnail( $id, $photo );
	} else {
		delete_post_thumbnail( $id );
	}
};

/*
 * The 54 posts.
 */
$legacy_posts = static function ( Context $import, array $curated ) use ( $tidy, $summary, $meta, $card_photo, $set_photo ): void {
	foreach ( $import->snapshot->posts() as $post ) {
		$old    = $post['slug'];
		$fields = $curated[ $old ] ?? array();
		$title  = $fields['title'] ?? html_entity_decode( $post['title']['rendered'], ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$blocks = $tidy( $import->converter->to_blocks( $post['content']['rendered'], $title ), $fields['fixes'] ?? array() );

		// Files from the old web root that the post linked from cover images.
		$files = array();
		$items = array();
		foreach ( $fields['documents'] ?? array() as [ $path, $label ] ) {
			$file           = $import->media->import( 'https://rcobeca.org' . $path, array( 'title' => $label ) );
			$files[ $path ] = $file ? (string) wp_parse_url( (string) wp_get_attachment_url( $file ), PHP_URL_PATH ) : '';
			if ( $file ) {
				$items[] = '<a href="' . esc_url( (string) wp_get_attachment_url( $file ) ) . '">' . esc_html( $label ) . '</a> (PDF)';
			}
		}
		if ( $items ) {
			array_push( $blocks, Blocks::heading( 'Documents' ), Blocks::list( $items ) );
		}

		$photo = 0;
		$item  = $post['featured_media'] ? $import->snapshot->media( (int) $post['featured_media'] ) : null;
		if ( $item ) {
			$photo = $import->media->import( $item['url'], array( 'about' => $title ) );
		}
		if ( ! $photo && preg_match( '/"id":(\d+)/', Blocks::markup( $blocks ), $m ) ) {
			$photo = (int) $m[1];
		}
		$photo = $card_photo( $import, $fields, $photo );

		$id = $import->upsert(
			"project:$old",
			array(
				'post_type'    => 'rcobeca_project',
				'post_name'    => $fields['slug'] ?? $old,
				'post_title'   => $title,
				'post_date'    => str_replace( 'T', ' ', $post['date'] ),
				'post_excerpt' => $summary( $blocks, $fields['summary'] ?? '' ),
				'post_content' => Blocks::markup( $blocks ),
			),
			$meta( $fields )
		);
		$set_photo( $id, $photo );
		$import->redirect( "/$old/", $id );
		$import->moved( "/$old/", 'Story and photos', $id );
		foreach ( $files as $path => $url ) {
			$import->redirect( $path, '' !== $url ? $url : $id );
		}
		if ( isset( $fields['check'] ) ) {
			$import->check( $fields['check'] );
		}
	}
};

/*
 * The old listings (Projects, Fundraisers, categories, tags, cause
 * categories) go to the matching view of the new listing.
 */
$listings = static function ( Context $import ): void {
	$import->redirect( '/projects/', '/projects/' );
	$import->redirect( '/projects/causes/', '/projects/?status=fundraising' );
	$import->redirect( '/cause/', '/projects/' );
	$import->redirect( '/cause_category/srilanka/', '/projects/?beneficiary=sri-lanka-relief' );
	$import->redirect( '/cause_category/usa/', '/projects/?beneficiary=us-communities' );
	foreach ( range( 2, 6 ) as $page ) {
		$import->redirect( "/projects/page/$page/", '/projects/' );
	}
	// Only the Cyclone Ditwah story was tagged; its own tags lead back to it.
	$ditwah = Context::find( 'project:rcobec-foundation-delivers-immediate-relief-to-cyclone-ditwah-victims' );
	foreach ( $import->snapshot->sitemap_paths() as $path ) {
		if ( preg_match( '#^/(category|tag)/#', $path ) ) {
			$import->redirect( $path, preg_match( '#^/tag/(cyclone|ditwah)/#', $path ) && $ditwah ? $ditwah : '/projects/' );
		}
	}
};

/*
 * The story of a cause page: its entry-content, with the theme's lists of
 * linked thumbnails turned into full-size images the converter can place.
 */
$cause_html = static function ( Context $import, string $slug ): string {
	$html = $import->snapshot->read( "raw/html/cause__$slug.html" );
	if ( ! preg_match( '#<div class="entry-content">(.*?)<div class="single-post-action#s', $html, $m ) ) {
		return '';
	}
	$story = preg_replace( '#<a[^>]*href="([^"]+\.(?:jpe?g|png))"[^>]*>\s*<img[^>]*>\s*</a>#i', '<img src="$1">', $m[1] );
	return (string) preg_replace( array( '#<li[^>]*>\s*(<img[^>]*>)\s*</li>#', '#<ul[^>]*>(\s*<img[^>]*>)#', '#(<img[^>]*>\s*)</ul>#' ), array( '$1', '$1', '$1' ), $story );
};

/*
 * The four causes (fundraisers). Three are over and carry their final
 * figures; the general fund, whose page crashed with an HTTP 500, is the
 * one still open.
 */
$causes = static function ( Context $import, array $curated ) use ( $tidy, $summary, $meta, $cause_html, $card_photo, $set_photo ): array {
	$ids = array();
	foreach ( $curated as $old => $fields ) {
		$title  = $fields['title'];
		$blocks = $import->converter->html_to_blocks( $cause_html( $import, $old ), $title );
		if ( 'donate-towards-rcobeca-projects' === $old ) {
			$blocks = array(
				Blocks::paragraph( 'Please donate towards future RCOBECA Projects. Gifts to the General Project Fund go to the Projects the Committee chooses next, for Royal College and for relief in Sri Lanka and the US.' ),
				Blocks::paragraph( 'The fund opened on February 24, 2017. By October 2026 the old website showed $7,940 raised for it.' ),
			);
		}
		$blocks = $tidy( $blocks, $fields['fixes'] ?? array() );
		$photo  = preg_match( '/"id":(\d+)/', Blocks::markup( $blocks ), $m ) ? (int) $m[1] : 0;
		if ( ! $photo && isset( $fields['photo'] ) ) {
			$photo = $import->media->import( $fields['photo'], array( 'about' => 'Royal College, Colombo: the main building seen through the trees' ) );
		}
		$photo = $card_photo( $import, $fields, $photo );

		$ids[ $old ] = $import->upsert(
			"project:cause:$old",
			array(
				'post_type'    => 'rcobeca_project',
				'post_name'    => $fields['slug'] ?? $old,
				'post_title'   => $title,
				'post_date'    => $fields['timeline'][0][0] . ' 12:00:00',
				'post_excerpt' => $summary( $blocks, $fields['summary'] ?? '' ),
				'post_content' => Blocks::markup( $blocks ),
			),
			$meta( $fields )
		);
		$set_photo( $ids[ $old ], $photo );
		$import->redirect( "/cause/$old/", $ids[ $old ] );
		$import->moved( "/cause/$old/", 'Appeal, updates and figures', $ids[ $old ] );
		if ( isset( $fields['check'] ) ) {
			$import->check( $fields['check'] );
		}
	}
	return $ids;
};

/*
 * Two Projects the Our Story history names that never had a page of their own.
 */
$from_history = static function ( Context $import ) use ( $meta ): void {
	$import->upsert(
		'project:history:flood-relief-2003',
		array(
			'post_type'    => 'rcobeca_project',
			'post_name'    => 'flood-relief-2003',
			'post_title'   => 'Flood Relief for Sri Lanka, 2003',
			'post_date'    => '2003-08-01 12:00:00',
			'post_excerpt' => 'At the request of Ambassador Mahendran, RCOBECA gave $1,000 to help families who lost everything in the 2003 floods in Sri Lanka.',
			'post_content' => Blocks::markup( array( Blocks::paragraph( 'In August 2003 we received a plea of support from Ambassador Mahendran for assistance to flood victims in Sri Lanka. RCOBECA responded with a donation of $1,000 towards helping the families that suffered losses from the catastrophe.' ) ) ),
		),
		$meta(
			array(
				'beneficiary'  => 'sri-lanka-relief',
				'place'        => 'Sri Lanka',
				'date'         => '2003-08',
				'amount_cents' => 100000,
				'timeline'     => array( array( '2003-08', 'Delivered', 'Donation sent at the request of Ambassador Mahendran.' ) ),
			)
		)
	);

	$import->upsert(
		'project:history:tsunami-school-reconstruction',
		array(
			'post_type'    => 'rcobeca_project',
			'post_name'    => 'tsunami-school-reconstruction',
			'post_title'   => 'Rebuilding Schools after the 2004 Tsunami',
			'post_date'    => '2005-01-01 12:00:00',
			'post_excerpt' => 'RCOBECA gave $4,900, the net profit of its Dinner-Dance, towards rebuilding schools in Sri Lanka damaged by the 2004 Tsunami.',
			'post_content' => Blocks::markup( array( Blocks::paragraph( 'RCOBECA contributed $4,900 (the net profit from the dinner dance) towards reconstruction of schools affected by the Tsunami in 2004.' ) ) ),
		),
		$meta(
			array(
				'beneficiary'  => 'sri-lanka-relief',
				'place'        => 'Sri Lanka',
				'date'         => '2005',
				'amount_cents' => 490000,
				'timeline'     => array( array( '2005', 'Delivered', '$4,900 net profit from the Dinner-Dance given towards rebuilding schools.' ) ),
			)
		)
	);
};

return static function ( Context $import ) use ( $data, $legacy_posts, $causes, $from_history, $listings ): void {
	$curated = $data();
	$legacy_posts( $import, $curated['posts'] );
	$causes( $import, $curated['causes'] );
	$from_history( $import );
	$listings( $import );

	// The 2008–2016 site's news page, about the 2013 Piyarathana Vidyalaya toilets.
	$import->redirect( '/index-90.html', '/projects/' );
	$import->dropped( '/index-90.html', 'EXCO Vice President Continues to Make RCOBECA Proud (Piyarathana Vidyalaya toilets, 2013)', 'not on the current rcobeca.org: the new site carries only the live site’s content' );
};
