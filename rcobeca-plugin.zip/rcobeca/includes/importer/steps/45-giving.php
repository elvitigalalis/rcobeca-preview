<?php
/**
 * Importer step: the giving pages. Donate (Khan Academy model: appeal beside
 * the branded Zeffy card, where gifts go, other ways to give, trust copy and
 * a FAQ) replaces the old PayPal donation pages; Transparency (Wikimedia
 * model) lists Financial documents by Club Year. Runs after the Projects so
 * Donate can show their photos.
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

/*
 * RCOBEC Foundation’s page on Zeffy. The Donate card links to it until a
 * general donation form's link is set under Settings → Join and newsletter
 * (see the launch check below).
 */
$zeffy_organization = 'https://www.zeffy.com/en-US/organizations/rcobec-foundation';

/*
 * One "where your gift goes" card: a Project's photo, a meta line, its title
 * and one sentence.
 */
$card = static function ( string $key, string $meta, string $title, string $text, string $link ): string {
	$id    = Context::find( $key );
	$photo = $id ? (int) get_post_thumbnail_id( $id ) : 0;
	$image = '';
	if ( $photo ) {
		$image = sprintf(
			"<!-- wp:image {\"id\":%1\$d,\"aspectRatio\":\"3/2\",\"scale\":\"cover\",\"sizeSlug\":\"medium_large\",\"className\":\"rcobeca-card__image\"} -->\n<figure class=\"wp-block-image size-medium_large rcobeca-card__image\"><img src=\"%2\$s\" alt=\"%3\$s\" class=\"wp-image-%1\$d\" style=\"aspect-ratio:3/2;object-fit:cover\"/></figure>\n<!-- /wp:image -->\n",
			$photo,
			esc_url( (string) wp_get_attachment_image_url( $photo, 'medium_large' ) ),
			esc_attr( (string) get_post_meta( $photo, '_wp_attachment_image_alt', true ) )
		);
	}
	return "<!-- wp:group {\"tagName\":\"article\",\"className\":\"rcobeca-card\",\"layout\":{\"type\":\"default\"}} -->\n<article class=\"wp-block-group rcobeca-card\">\n$image"
		. "<!-- wp:paragraph {\"className\":\"rcobeca-card__meta\"} -->\n<p class=\"rcobeca-card__meta\">" . esc_html( $meta ) . "</p>\n<!-- /wp:paragraph -->\n"
		. "<!-- wp:heading {\"level\":3,\"className\":\"rcobeca-card__title\"} -->\n<h3 class=\"wp-block-heading rcobeca-card__title\"><a href=\"" . esc_url( $link ) . '">' . esc_html( $title ) . "</a></h3>\n<!-- /wp:heading -->\n"
		. "<!-- wp:paragraph -->\n<p>" . esc_html( $text ) . "</p>\n<!-- /wp:paragraph -->\n</article>\n<!-- /wp:group -->\n";
};

/*
 * A FAQ row: a native disclosure (core Details block).
 */
$faq = static function ( string $question, string $answer ): string {
	return "<!-- wp:details {\"className\":\"rcobeca-faq__item\"} -->\n<details class=\"wp-block-details rcobeca-faq__item\"><summary>" . esc_html( $question ) . "</summary><!-- wp:paragraph -->\n<p>$answer</p>\n<!-- /wp:paragraph --></details>\n<!-- /wp:details -->\n";
};

/*
 * Donate, from the old /donations/ page's appeal and the trust answers the
 * old Hurricane Harvey appeal gave.
 */
$donate = static function ( Context $import ) use ( $card, $faq, $zeffy_organization ): int {
	$projects = home_url( '/projects/' );
	$join     = esc_url( home_url( '/join/' ) );
	$ball     = esc_url( home_url( '/ball/' ) );
	$cards    = $card( 'project:donation-of-the-smart-conference-room', 'Royal College', 'Classrooms, labs and scholarships', 'Most gifts go to Royal College: a smart conference room, computer labs, Scout gear, scholarships for students in need.', add_query_arg( 'beneficiary', 'royal-college', $projects ) )
		. $card( 'project:rcobec-foundation-delivers-immediate-relief-to-cyclone-ditwah-victims', 'Sri Lanka relief', 'Relief when disaster strikes', 'After Cyclone Ditwah in 2025, gear for rescue teams and supplies for displaced families within days.', add_query_arg( 'beneficiary', 'sri-lanka-relief', $projects ) )
		. $card( 'project:covid-19-providing-a-meal-to-frontline-workers-in-nyc', 'US communities', 'Neighbours in the US', 'Meals for New York’s front-line healthcare workers in 2020, and Hurricane Harvey relief in 2017.', add_query_arg( 'beneficiary', 'us-communities', $projects ) );

	$questions = $faq( 'Is my gift tax-deductible?', 'Yes. RCOBEC Foundation Inc. is a federally tax-exempt 501(c)(3) public charity, EIN 81-4203477. Because your donation is a gift without the return of any goods or services, it may be tax-deductible to the extent allowed by law.' )
		. $faq( 'Will I get a receipt?', 'Zeffy emails your tax receipt as soon as your gift goes through. For a gift by Zelle or cheque, the Treasurer sends one; write to <a href="mailto:treasurer@rcobeca.org">treasurer@rcobeca.org</a> if it hasn’t arrived.' )
		. $faq( 'Can I give monthly?', 'Yes. Choose monthly in the form. You can change or stop a monthly gift at any time from the link in Zeffy’s receipt, or by writing to the Treasurer.' )
		. $faq( 'Does Zeffy keep part of my gift?', 'No. Zeffy charges RCOBECA no fees. At checkout it suggests an optional tip to support Zeffy itself; you can set it to zero.' )
		. $faq( 'Can I give to a particular Project?', 'Yes. A Project that is raising money has its own form on its page; see the <a href="' . esc_url( add_query_arg( 'status', 'fundraising', $projects ) ) . '">Projects now fundraising</a>. Gifts made here go to the General Project Fund, which pays for the Projects the Committee chooses next.' )
		. $faq( 'Can my employer match my gift?', 'Many employers match their employees’ gifts, and some match a spouse’s, so you could double or even triple your gift. Ask your HR team, or look your employer up on <a href="https://www.charitynavigator.org/index.cfm?bay=content.view&amp;cpid=1799">Charity Navigator’s matching gifts page</a>.' )
		. $faq( 'How do I give by cheque or Zelle?', 'By Zelle, send your gift to <a href="mailto:treasurer@rcobeca.org">treasurer@rcobeca.org</a>. For a cheque, make it payable to RCOBEC Foundation Inc. and email the Treasurer for the address to post it to.' )
		. $faq( 'How do I know my gift was used well?', 'Every Project is listed with what it delivered and its photos, and our financial documents are on the <a href="' . esc_url( home_url( '/transparency/' ) ) . '">Transparency</a> page. Questions are welcome at <a href="mailto:treasurer@rcobeca.org">treasurer@rcobeca.org</a>.' );

	$zeffy = wp_json_encode(
		array(
			'formUrl'     => $zeffy_organization,
			'formSetting' => 'donation',
			'heading'     => 'Make a gift',
		),
		JSON_UNESCAPED_SLASHES
	);

	$content = <<<HTML
<!-- wp:group {"align":"full","className":"rcobeca-donate-hero","backgroundColor":"primary-deep","textColor":"base","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1104px"}} -->
<div class="wp-block-group alignfull rcobeca-donate-hero has-base-color has-primary-deep-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:columns {"verticalAlignment":"top","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns are-vertically-aligned-top">
<!-- wp:column {"verticalAlignment":"top","width":"52%","className":"rcobeca-donate-hero__appeal"} -->
<div class="wp-block-column is-vertically-aligned-top rcobeca-donate-hero__appeal" style="flex-basis:52%">
<!-- wp:paragraph {"className":"is-style-kicker"} -->
<p class="is-style-kicker">Donate</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":1,"fontSize":"xxx-large"} -->
<h1 class="wp-block-heading has-xxx-large-font-size">Give back to Royal College, from the East Coast</h1>
<!-- /wp:heading -->
<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">Please make a tax-deductible gift to the RCOBEC Foundation Inc. Since 1993, Old Boys here have paid for classrooms, labs and scholarships at Royal College, and sent relief to Sri Lanka and neighbours in the US.</p>
<!-- /wp:paragraph -->
<!-- wp:list {"className":"rcobeca-donate-hero__points"} -->
<ul class="wp-block-list rcobeca-donate-hero__points"><!-- wp:list-item -->
<li>Give once, or monthly.</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Your tax receipt arrives by email straight away.</li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li>Volunteers run RCOBECA; every Project is reported with its photos.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->
<!-- wp:paragraph {"className":"rcobeca-donate-hero__legal"} -->
<p class="rcobeca-donate-hero__legal">The RCOBEC Foundation Inc is a 501(c)3 non-profit organization. All donations are tax-deductible as allowable by law.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"top","width":"48%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:48%">
<!-- wp:rcobeca/zeffy-card $zeffy /-->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1104px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:paragraph {"className":"is-style-kicker"} -->
<p class="is-style-kicker">Where your gift goes</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Three places your gift does its work</h2>
<!-- /wp:heading -->
<!-- wp:group {"className":"rcobeca-card-grid","style":{"spacing":{"blockGap":"var:preset|spacing|40","margin":{"top":"var:preset|spacing|40"}}},"layout":{"type":"grid","columnCount":3,"minimumColumnWidth":"17rem"}} -->
<div class="wp-block-group rcobeca-card-grid" style="margin-top:var(--wp--preset--spacing--40)">
$cards</div>
<!-- /wp:group -->
<!-- wp:paragraph {"className":"rcobeca-more"} -->
<p class="rcobeca-more"><a href="$projects">See every Project since 2002</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"cream","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1104px"}} -->
<div class="wp-block-group alignfull has-cream-background-color has-background" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:paragraph {"className":"is-style-kicker"} -->
<p class="is-style-kicker">Other ways to give</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">No card? No problem.</h2>
<!-- /wp:heading -->
<!-- wp:columns {"className":"rcobeca-ways","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|50"},"margin":{"top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-columns rcobeca-ways" style="margin-top:var(--wp--preset--spacing--40)">
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Zelle</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Send your gift by Zelle to <a href="mailto:treasurer@rcobeca.org">treasurer@rcobeca.org</a>, the RCOBEC Foundation Treasurer. Add a note if it is for a particular Project.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Cheque</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Make your cheque payable to RCOBEC Foundation Inc. and email <a href="mailto:treasurer@rcobeca.org">treasurer@rcobeca.org</a> for the address to post it to.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Employer matching</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Remember to check with your employer, as many provide a matching gift. You can even triple your gift if your spouse’s company matches donations too.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
<!-- wp:paragraph {"className":"rcobeca-ways__more"} -->
<p class="rcobeca-ways__more">You can also support RCOBECA by becoming a Member (<a href="$join">Join or renew</a>) or at the <a href="$ball">Royal Charity Ball</a>.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"816px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:paragraph {"className":"is-style-kicker"} -->
<p class="is-style-kicker">Questions</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Giving, answered</h2>
<!-- /wp:heading -->
<!-- wp:group {"className":"rcobeca-faq","layout":{"type":"default"}} -->
<div class="wp-block-group rcobeca-faq">
$questions</div>
<!-- /wp:group -->
<!-- wp:paragraph {"className":"rcobeca-faq__contact"} -->
<p class="rcobeca-faq__contact">Anything else? Write to the Treasurer at <a href="mailto:treasurer@rcobeca.org">treasurer@rcobeca.org</a>.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
HTML;

	$page = $import->upsert(
		'page:donate',
		array(
			'post_type'     => 'page',
			'post_name'     => 'donate',
			'post_title'    => 'Donate',
			'post_excerpt'  => 'Give once or monthly to RCOBEC Foundation Inc., a 501(c)(3) charity (EIN 81-4203477), for Royal College and relief in Sri Lanka and the US.',
			'post_content'  => $content,
			// WordPress re-checks a stored template against the active theme on
			// every update; "default" always passes, and the meta below then
			// picks the theme's "Full width, no title" template.
			'page_template' => 'default',
		),
		array( '_wp_page_template' => 'full-width' )
	);
	foreach ( array( '/donations/', '/donation-thank-you/', '/your-donation-was-cancelled/' ) as $old ) {
		$import->redirect( $old, $page );
	}
	$import->moved( '/donations/', 'Tax-deductible appeal and employer matching', $page );
	$import->dropped( '/donations/', 'PayPal Donate button', 'payments moved to Zeffy (ADR 0002)' );
	$import->dropped( '/donation-thank-you/', 'PayPal thank-you message', 'Zeffy thanks and receipts the donor itself' );
	$import->dropped( '/your-donation-was-cancelled/', 'PayPal cancellation message', 'Zeffy handles cancelled payments itself' );
	$import->check( 'Donate: create a general donation form in Zeffy (once or monthly) and paste its Share link under Settings → Join and newsletter. Until then the Donate card links to RCOBEC Foundation’s Zeffy page.' );
	$import->check( 'Donate: confirm the cheque instructions (no mailing address is published) and that monthly gifts can be changed from Zeffy’s receipt.' );
	return $page;
};

/*
 * Transparency: status and EIN up front, Financial documents by Club Year.
 */
$transparency = static function ( Context $import ): int {
	// Key facts at a glance, as a list the theme lays out as a strip.
	$items = '';
	foreach ( array(
		'Legal name' => 'RCOBEC Foundation Inc.',
		'Status'     => '501(c)(3) public charity',
		'EIN'        => '81-4203477',
		'Since'      => 'RCOBECA 1993 · Foundation 2017',
	) as $label => $value ) {
		$items .= "<!-- wp:list-item -->\n<li><strong>$label</strong> $value</li>\n<!-- /wp:list-item -->\n";
	}
	$facts = array(
		'name'   => 'core/list',
		'text'   => '',
		'markup' => "<!-- wp:list {\"className\":\"rcobeca-key-facts\"} -->\n<ul class=\"wp-block-list rcobeca-key-facts\">\n$items</ul>\n<!-- /wp:list -->",
	);

	$content = Blocks::markup(
		array(
			Blocks::paragraph( 'RCOBECA, the Royal College Old Boys’ East Coast Association, was established in 1993. In 2017, a public non-profit 501(c)(3) organization by the name of Royal College Old Boys’ East Coast Foundation (RCOBEC Foundation) was created, and all of RCOBECA’s activities are handled by it.', 'has-large-font-size' ),
			Blocks::paragraph( '<strong>RCOBEC Foundation Inc.</strong> is a federally tax-exempt 501(c)(3) public charity. Its EIN (federal tax ID) is <strong>81-4203477</strong>.' ),
			$facts,
			Blocks::heading( 'Financial documents' ),
			array(
				'name'   => 'rcobeca/financial-documents',
				'text'   => '',
				'markup' => '<!-- wp:rcobeca/financial-documents /-->',
			),
			Blocks::heading( 'Where the money goes' ),
			Blocks::paragraph( 'Gifts pay for Projects for Royal College, Colombo, and for relief in Sri Lanka and the United States. Every Project since 2002 is listed with its status, place and, where we know it, the amount delivered: <a href="' . esc_url( home_url( '/projects/' ) ) . '">see all Projects</a>.' ),
			Blocks::heading( 'Tax deductibility' ),
			Blocks::paragraph( 'The RCOBEC Foundation is a federally tax-exempt 501(c)(3) public charity. Because a donation is a gift without the return of any goods or services, it may be tax deductible. All donations are tax-deductible as allowable by law. For a Royal Charity Ball ticket, only the part above the value of the evening is deductible; the receipt shows it.' ),
			Blocks::heading( 'How RCOBECA is run' ),
			Blocks::paragraph( 'RCOBECA is run by volunteers. Members elect a Committee at each Annual General Meeting to serve for one Club Year. See the <a href="' . esc_url( home_url( '/committee/' ) ) . '">current Committee</a> and the <a href="' . esc_url( home_url( '/committee/history/' ) ) . '">Committee history</a> back to 1993.' ),
			Blocks::heading( 'Questions' ),
			Blocks::paragraph( 'For any financial question, or a document not listed here, write to the Treasurer at <a href="mailto:treasurer@rcobeca.org">treasurer@rcobeca.org</a>.' ),
		)
	);

	$page = $import->upsert(
		'page:transparency',
		array(
			'post_type'    => 'page',
			'post_name'    => 'transparency',
			'post_title'   => 'Transparency',
			'post_excerpt' => 'RCOBEC Foundation Inc. is a 501(c)(3) public charity, EIN 81-4203477. Its financial documents, by Club Year.',
			'post_content' => $content,
		)
	);
	$import->redirect( '/ack.html', $page );
	$import->dropped( '/ack.html', 'List of appreciation letters and their six PDFs', 'not on the current rcobeca.org (the PDFs were never archived): the new site carries only the live site’s content' );
	$import->check( 'Transparency: upload the IRS determination letter and each Club Year’s financial documents (Financial documents in the admin), and confirm the Ball-ticket deductibility sentence.' );
	return $page;
};

return static function ( Context $import ) use ( $donate, $transparency ): void {
	$donate( $import );
	$transparency( $import );
};
