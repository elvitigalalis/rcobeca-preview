<?php
/**
 * Importer step: Committee, People and Life Members.
 *
 * Persons and Committee Terms come from three sources:
 * - the old Committee page's "2025/2026" list (the current Committee);
 * - its "Past Committees" tables, one per year from 2025 back to 2001;
 * - the About page's HISTORY table: Presidents and major events, 1993-94 to 2023.
 * Each Old Boy becomes one Person (spellings joined through data/people.tsv).
 * Where sources contradict each other, the current Committee list is
 * published and the other rows are kept as Terms awaiting review ("pending"),
 * listed under "Confirm before launch" and in docs/pre-launch.md.
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

/*
 * Splits a name as written into the name, its post-nominals and an
 * honorific: "Arjuna Ranasinghe, PE, Ph.D" gives Arjuna Ranasinghe with PE and
 * Ph.D.; "Dr. Sudath Rannulu" gives Sudath Rannulu with the honorific Dr.
 */
$parse_name = static function ( string $raw ): array {
	$name      = trim( (string) preg_replace( '/\s+/u', ' ', html_entity_decode( wp_strip_all_tags( $raw ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) );
	$honorific = '';
	if ( preg_match( '/^(Mr|Dr)\.?\s+/', $name, $m ) ) {
		$honorific = 'Dr' === $m[1] ? 'Dr.' : '';
		$name      = substr( $name, strlen( $m[0] ) );
	}
	$tokens = array(
		'MD'    => 'M\.?\s?D\.?',
		'PE'    => 'P\.?\s?E\.?',
		'LS'    => 'LS',
		'Ph.D.' => 'Ph\.?\s?D\.?|P\.hD\.?',
		'CPA'   => 'C\.?P\.?A\.?',
		'Esq.'  => 'Esq\.?',
	);
	$found  = array();
	do {
		$hit = false;
		foreach ( $tokens as $token => $pattern ) {
			if ( preg_match( "/[\s,]+(?:$pattern)$/", $name, $m ) ) {
				$found[ $token ] = true;
				$name            = substr( $name, 0, -strlen( $m[0] ) );
				$hit             = true;
			}
		}
	} while ( $hit );
	if ( strtoupper( $name ) === $name ) {
		$name = ucwords( strtolower( $name ) );
	}
	return array( trim( $name, ' ,' ), array_keys( array_intersect_key( $tokens, $found ) ), $honorific );
};

/*
 * Spellings => the name used, and the notes of judgement calls.
 */
$aliases = static function (): array {
	$names = array();
	$notes = array();
	foreach ( file( RCOBECA_DIR . '/data/people.tsv', FILE_IGNORE_NEW_LINES ) as $line ) {
		if ( '' === trim( $line ) || '#' === $line[0] ) {
			continue;
		}
		[ $from, $to, $note ] = array_pad( explode( "\t", $line ), 3, '' );
		$names[ $from ]       = $to;
		if ( str_starts_with( $note, 'Verify' ) ) {
			$notes[] = "People: $note.";
		}
	}
	return array( $names, $notes );
};

/*
 * The roles as the tables write them => Committee Term roles.
 */
$role_of = static function ( string $label ): string {
	$label = trim( wp_strip_all_tags( $label ) );
	$map   = array(
		'Presidents'      => 'President',
		'Vice Presidents' => 'Vice President',
		'Committee'       => 'Committee Member',
	);
	return $map[ $label ] ?? $label;
};

/*
 * The rows of a <table>, each a list of cell texts.
 */
$table_rows = static function ( string $html ): array {
	$dom = new \DOMDocument();
	libxml_use_internal_errors( true );
	// Lines a cell breaks with <br> or paragraphs are joined with a comma unless they end in punctuation.
	$dom->loadHTML( '<?xml encoding="utf-8"?><body>' . preg_replace( '#<br\s*/?>|</p>#i', "\n", $html ) . '</body>' );
	libxml_clear_errors();
	$rows = array();
	foreach ( $dom->getElementsByTagName( 'tr' ) as $tr ) {
		$cells = array();
		foreach ( $tr->getElementsByTagName( 'td' ) as $td ) {
			$text = '';
			foreach ( explode( "\n", $td->textContent ) as $line ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				$line = trim( (string) preg_replace( '/\s+/u', ' ', $line ) );
				if ( '' !== $line ) {
					$text .= ( '' === $text || preg_match( '/[,;&–-]$/u', $text ) ? ' ' : ', ' ) . $line;
				}
			}
			$cells[] = rtrim( trim( $text ), '.' );
		}
		$rows[] = $cells;
	}
	return $rows;
};

/*
 * Every Committee Term the sources state, as [ year, role, name as written,
 * source, extras ], in source order.
 */
$sources = static function ( Context $import ) use ( $role_of, $table_rows ): array {
	$rows    = array();
	$content = $import->snapshot->page( 'committee' )['content']['rendered'];

	// The current Committee: person cards inside a base64-encoded raw HTML block.
	preg_match( '#\[vc_raw_html[^\]]*\]([^\[]+)\[/vc_raw_html\]#', $content, $m );
	$cards = rawurldecode( (string) base64_decode( trim( $m[1] ), true ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- the old page stored its HTML base64-encoded.
	preg_match( '#(\d{4})/\d{4}#', $cards, $year );
	preg_match_all( '#<h3 class="person-name">(.*?)</h3>\s*<p class="person-title">(.*?)</p>\s*(?:<a href="mailto:([^"]+)")?#s', $cards, $people, PREG_SET_ORDER );
	foreach ( $people as $person ) {
		$email  = str_replace( '@rcobeca.com', '@rcobeca.org', $person[3] ?? '' );
		$rows[] = array( (int) $year[1], $role_of( $person[2] ), $person[1], 'current', array( 'email' => $email ) );
	}
	$current = (int) $year[1];

	// Past Committees: one accordion section and table per year.
	preg_match_all( '#\[vc_tta_section title=&\#8221;(\d{4})&\#8243;.*?(<table.*?</table>)#s', $content, $sections, PREG_SET_ORDER );
	foreach ( $sections as [ , $year, $table ] ) {
		$label = '';
		foreach ( $table_rows( $table ) as $cells ) {
			$label = '' !== ( $cells[0] ?? '' ) ? $cells[0] : $label;
			if ( '' !== ( $cells[1] ?? '' ) ) {
				$rows[] = array( (int) $year, $role_of( $label ), $cells[1], 'past', array() );
			}
		}
	}

	// The About page's HISTORY table: Year | President | Major Events.
	$about = $import->snapshot->page( 'about-us' )['content']['rendered'];
	foreach ( $table_rows( substr( $about, (int) strpos( $about, '<table' ) ) ) as $cells ) {
		if ( ! preg_match( '/^(\d{4})/', $cells[0] ?? '', $start ) ) {
			continue;
		}
		foreach ( array_map( 'trim', explode( '&', $cells[1] ) ) as $i => $name ) {
			$rows[] = array( (int) $start[1] + $i, 'President', $name, 'history', array( 'highlights' => str_replace( 'at the The Villa', 'at The Villa', $cells[2] ?? '' ) ) );
		}
	}
	return array( $rows, $current );
};

/*
 * Persons and Committee Terms.
 */
$committee_terms = static function ( Context $import ) use ( $sources, $parse_name, $aliases ): array {
	[ $rows, $current ] = $sources( $import );
	[ $names, $notes ]  = $aliases();
	$people             = array();
	$terms              = array();
	$current_keys       = array();
	$position           = array();
	foreach ( $rows as [ $year, $role, $written, $source, $extra ] ) {
		[ $name, $suffixes, $honorific ] = $parse_name( $written );
		$name                            = $names[ $name ] ?? $name;
		$people[ $name ]               ??= array(
			'suffixes'  => array(),
			'honorific' => '',
		);
		$people[ $name ]['suffixes']     = array_unique( array_merge( $people[ $name ]['suffixes'], $suffixes ) );
		$people[ $name ]['honorific']    = $honorific ? $honorific : $people[ $name ]['honorific'];

		$key = "$year|$role|$name";
		if ( 'current' === $source ) {
			$current_keys[ $key ] = true;
		}
		$pending = $year === $current && 'current' !== $source && ! isset( $current_keys[ $key ] );
		if ( isset( $terms[ $key ] ) ) {
			// The same Term from another source: keep what it adds.
			$terms[ $key ]['highlights'] = $terms[ $key ]['highlights'] ? $terms[ $key ]['highlights'] : ( $extra['highlights'] ?? '' );
			continue;
		}
		$position[ "$year|$role" ] = ( $position[ "$year|$role" ] ?? 0 ) + 1;
		$terms[ $key ]             = array(
			'year'       => $year,
			'role'       => $role,
			'name'       => $name,
			'sort'       => rcobeca_role_rank( $role ) * 100 + $position[ "$year|$role" ],
			'email'      => $extra['email'] ?? '',
			'highlights' => $extra['highlights'] ?? '',
			'pending'    => $pending,
		);
	}

	// Persons, suffixes in a fixed order.
	$order = array( 'MD', 'PE', 'LS', 'Ph.D.', 'CPA', 'Esq.' );
	$ids   = array();
	foreach ( $people as $name => $person ) {
		$suffixes     = array_values( array_intersect( $order, $person['suffixes'] ) );
		$ids[ $name ] = $import->upsert(
			'person:' . sanitize_title( $name ),
			array(
				'post_type'  => 'rcobeca_person',
				'post_title' => $name,
				'post_name'  => sanitize_title( $name ),
			),
			array(
				'rcobeca_post_nominals' => implode( ', ', $suffixes ),
				'rcobeca_honorific'     => $suffixes ? '' : $person['honorific'],
			)
		);
	}

	$note = sprintf(
		/* translators: %d: year. */
		__( 'Awaiting review: the old Committee page lists this under %1$d in its “Past Committees” table, but its current “%2$d/%3$d Committee” list differs. Publish it only if RCOBECA confirms it.', 'rcobeca' ),
		$current,
		$current,
		$current + 1
	);
	foreach ( $terms as $term ) {
		$id = $import->upsert(
			'term:' . $term['year'] . ':' . sanitize_title( $term['role'] ) . ':' . sanitize_title( $term['name'] ),
			array(
				'post_type'   => 'rcobeca_term',
				'post_status' => $term['pending'] ? 'pending' : 'publish',
				'post_name'   => $term['year'] . '-' . sanitize_title( $term['role'] . ' ' . $term['name'] ),
				'post_title'  => rcobeca_club_year_label( $term['year'] ) . ' · ' . $term['role'] . ' · ' . $term['name'],
			),
			array(
				'rcobeca_person'     => $ids[ $term['name'] ],
				'rcobeca_role'       => $term['role'],
				'rcobeca_club_year'  => $term['year'],
				'rcobeca_sort'       => $term['sort'],
				'rcobeca_email'      => $term['email'],
				'rcobeca_highlights' => $term['highlights'],
				'rcobeca_note'       => $term['pending'] ? $note : '',
			)
		);
	}
	$import->log( sprintf( '%d Persons, %d Committee Terms (%d awaiting review)', count( $ids ), count( $terms ), count( array_filter( array_column( $terms, 'pending' ) ) ) ) );

	foreach ( $notes as $check ) {
		$import->check( $check );
	}
	$pending = array_filter( $terms, static fn( $t ) => $t['pending'] );
	$import->check(
		sprintf(
			'Committee %1$s: the old Committee page’s “%2$d/%3$d Committee” list (President Kanna Sriskanthan) and its “Past Committees” %2$d table (President Sudath Rannulu, MD) disagree. The site shows the %2$d/%3$d list; the table’s other rows are Committee Terms awaiting review: %4$s.',
			rcobeca_club_year_label( $current ),
			$current,
			$current + 1,
			implode( '; ', array_map( static fn( $t ) => "{$t['role']} {$t['name']}", $pending ) )
		)
	);

	$import->check( 'The old Committee page gives president@rcobeca.com; the site shows president@rcobeca.org, like secretary@ and treasurer@. Confirm the address.' );
	$import->check( 'Club Year boundary: Club Years are filed under the year of the AGM that elects the Committee. Confirm the AGM month, and that the old “Past Committees” year labels follow it.' );
	return $ids;
};

/*
 * The Committee page (same URL as before) and Committee history under it.
 */
$build_pages = static function ( Context $import ): array {
	$base  = 'https://rcobeca.org/newsite/wp-content/uploads/2025/10/';
	$group = $import->media->import( $base . '2025-Committee-scaled.jpg', array( 'alt' => 'Group photo of the 2025–26 RCOBECA Committee' ) );
	$exco  = $import->media->import( $base . 'Exco-2025-scaled.jpg', array( 'alt' => 'The 2025–26 RCOBECA Executive Committee' ) );

	$committee = $import->upsert(
		'page:committee',
		array(
			'post_type'    => 'page',
			'post_name'    => 'committee',
			'post_title'   => 'Committee',
			'post_content' => Blocks::markup(
				array_filter(
					array(
						Blocks::paragraph( 'RCOBECA is run by volunteers: a Committee of Members elected at each Annual General Meeting to serve for one Club Year. Write to an office bearer at the address shown.', 'has-large-font-size' ),
						$group ? Blocks::image( $group, 'The 2025–26 Committee' ) : null,
						array( 'markup' => '<!-- wp:rcobeca/current-committee /-->' ),
						$exco ? Blocks::image( $exco, 'The 2025–26 Executive Committee' ) : null,
						Blocks::paragraph( '<a href="' . esc_url( home_url( '/committee/history/' ) ) . '">Committee history: every Committee since 1993, and Past Presidents</a>' ),
					)
				)
			),
		)
	);

	$presidents = $import->media->import( $base . 'DSP_3431-scaled.jpg', array( 'alt' => 'Past Presidents of RCOBECA together in 2025' ) );

	$history = $import->upsert(
		'page:committee-history',
		array(
			'post_type'    => 'page',
			'post_parent'  => $committee,
			'post_name'    => 'history',
			'post_title'   => 'Committee History',
			'post_content' => Blocks::markup(
				array_filter(
					array(
						Blocks::paragraph( 'Every Committee since RCOBECA was founded in 1993, newest first, and every President. Names are as the old website recorded them; write to <a href="mailto:secretary@rcobeca.org">secretary@rcobeca.org</a> with corrections.', 'has-large-font-size' ),
						Blocks::heading( 'Past Presidents' ),
						array( 'markup' => '<!-- wp:rcobeca/past-presidents /-->' ),
						$presidents ? Blocks::image( $presidents, 'Past Presidents, 2025' ) : null,
						// Wide, to line up with the history list below it.
						array( 'markup' => "<!-- wp:heading {\"align\":\"wide\"} -->\n<h2 class=\"wp-block-heading alignwide\">Every Committee</h2>\n<!-- /wp:heading -->" ),
						array( 'markup' => '<!-- wp:rcobeca/committee-history {"align":"wide"} /-->' ),
						Blocks::heading( 'How Club Years work', 3 ),
						Blocks::paragraph( 'A Club Year runs from one Annual General Meeting to the next, and is named for the year of the AGM that elects its Committee.' ),
					)
				)
			),
		)
	);
	return array( $committee, $history );
};

/*
 * Life Members, from the old page's "Member Since | Names" table, each linked
 * to his Person where the name matches one (spellings through people.tsv).
 */
$life_members = static function ( Context $import, array $people ) use ( $table_rows, $parse_name, $aliases ): int {
	$source    = $import->snapshot->page( 'life-members' );
	[ $names ] = $aliases();
	$count     = 0;
	foreach ( $table_rows( $source['content']['rendered'] ) as $cells ) {
		$since = strtotime( ( $cells[0] ?? '' ) . ' 12:00 UTC' );
		if ( false === $since || '' === ( $cells[1] ?? '' ) ) {
			continue;
		}
		// The roll's own spelling, without "Mr.", post-nominals written the site's way.
		[ $name, $suffixes, $honorific ] = $parse_name( $cells[1] );
		$shown                           = trim( "$honorific $name" ) . ( $suffixes ? ', ' . implode( ', ', $suffixes ) : '' );
		$person                          = $people[ $names[ $name ] ?? $name ] ?? 0;
		++$count;
		$import->upsert(
			'life-member:' . sanitize_title( $name ),
			array(
				'post_type'  => 'rcobeca_life_member',
				'post_title' => $shown,
				'post_name'  => sanitize_title( $name ),
				'menu_order' => $count,
			),
			array(
				'rcobeca_member_since' => gmdate( 'Y-m-d', $since ),
				'rcobeca_person'       => $person,
			)
		);
	}

	$page = $import->upsert(
		'page:life-members',
		array(
			'post_type'    => 'page',
			'post_name'    => 'life-members',
			'post_title'   => 'Life Members',
			'post_content' => Blocks::markup(
				array(
					Blocks::paragraph( 'Old Boys who have committed to RCOBECA for life. Their support keeps our work for Royal College going year after year, and we thank every one of them.', 'has-large-font-size' ),
					array( 'markup' => '<!-- wp:rcobeca/life-members {"asOf":"' . wp_date( 'j F Y', (int) strtotime( $source['modified'] . ' UTC' ) ) . '"} /-->' ),
					Blocks::heading( 'Become a Life Member' ),
					Blocks::paragraph( 'Life Membership is a single payment that makes you a Member of RCOBECA for good. <a href="' . esc_url( home_url( '/join/' ) ) . '">Become a Life Member</a>.' ),
				)
			),
		)
	);
	$import->log( "$count Life Members" );
	$import->redirect( '/life-members/', $page );
	$import->redirect( '/index-5.html', $page );
	$import->moved( '/life-members/', 'Life members table', $page );
	$import->moved( '/life-members/', 'Become a life member link', $page );
	$import->check( 'Life Members: is "Dr. Hary Anantham" (Life Member since 25 October 2009) the 2010–11 President Anantham Harin, MD? Is "Sujan Subramaniam" (25 October 2009) S. Sujanthakumar, CPA (2007–08 President)? Both are left unlinked from a Person until confirmed. Also confirm "Ramesh Ramanathan": Mr. on the roll, Dr. on the 2023 Committee.' );
	$import->check( 'Life Members: none is marked deceased, because the old roll did not say. Mark any who have died, and update the roll’s “as of” date (taken from the old page: ' . wp_date( 'j F Y', (int) strtotime( $source['modified'] . ' UTC' ) ) . ').' );
	return $page;
};

return static function ( Context $import ) use ( $committee_terms, $build_pages, $life_members ): void {
	$people                  = $committee_terms( $import );
	[ $committee, $history ] = $build_pages( $import );
	$life_members( $import, $people );

	$import->redirect( '/committee/', $committee );
	foreach ( array( 'Office Bearers 2025/2026', 'Committee Members', '2025 Committee photo', 'Exco 2025 photo' ) as $block ) {
		$import->moved( '/committee/', $block, $committee );
	}
	$import->moved( '/committee/', 'Past Committees 2001–2025', $history );
	$import->moved( '/committee/', 'Past presidents photo', $history );

	// The theme's team stubs (empty pages, some demo people) and their categories.
	foreach ( $import->snapshot->sitemap_paths() as $path ) {
		if ( preg_match( '#^/dgtfw_team(_category)?/#', $path ) ) {
			$import->redirect( $path, $committee );
		}
	}
	$import->redirect( '/dgtfw_team/', $committee );

	// Committee pages of the 2004–2016 sites (docs/research/wayback-recovery.md).
	$import->redirect( '/index-3.html', $committee );
	$import->redirect( '/index-3p.html', $history );
	foreach ( range( 2001, 2005 ) as $year ) {
		$import->redirect( "/committe_$year.htm", '/committee/history/#club-year-' . $year );
	}
	$import->redirect( '/agm.html', $history );
	$import->dropped( '/agm.html', 'AGM notice of 18 June 2010', 'not on the current rcobeca.org: the new site carries only the live site’s content' );
};
