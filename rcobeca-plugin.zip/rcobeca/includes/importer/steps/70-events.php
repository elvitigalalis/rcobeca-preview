<?php
/**
 * Importer step: Events and Royal Charity Balls.
 *
 * Builds every Event from the snapshot: the 22 legacy event posts (raw/html,
 * merged where the old site had two posts for one Ball), the Ball venues
 * from the old History table, the Souvenir Journal and ad pages, and
 * the Events, Ball and Past Balls pages. Old URLs redirect to their new home.
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

use RCOBECA\Events;

/*
 * Helpers shared by the Event builders below.
 */
$helpers = static function ( Context $import ): array {
	$links = new Links();

	// A link through the dead-link map: live, its Wayback snapshot, or plain text marked unavailable.
	$link = static function ( string $label, string $url ) use ( $links ): string {
		$result = $links->rewrite( $url );
		if ( Links::UNAVAILABLE === $result['action'] ) {
			return esc_html( $label ) . ' (archive unavailable)';
		}
		return '<a href="' . esc_url( $result['href'] ) . '">' . esc_html( $label ) . '</a>';
	};

	// An image from the old site: the original if it can be had, else the resized copy the page showed.
	$image = static function ( string $url, string $about ) use ( $import ): int {
		$original = (string) preg_replace( '/-\d+x\d+(?=\.\w+$)/', '', $url );
		$id       = $import->media->import( $original, array( 'about' => $about ) );
		return $id ? $id : ( $original !== $url ? $import->media->import( $url, array( 'about' => $about ) ) : 0 );
	};

	// A Gallery block whose photos open in the lightbox.
	$gallery = static function ( array $ids, string $caption = '' ): array {
		$ids = array_values( array_filter( $ids ) );
		if ( ! $ids ) {
			return array();
		}
		$inner = '';
		foreach ( $ids as $id ) {
			$full   = (string) wp_get_attachment_url( $id );
			$large  = (string) wp_get_attachment_image_url( $id, 'large' );
			$alt    = (string) get_post_meta( $id, '_wp_attachment_image_alt', true );
			$inner .= '<!-- wp:image {"id":' . $id . ',"sizeSlug":"large","linkDestination":"media"} -->' . "\n"
				. '<figure class="wp-block-image size-large"><a href="' . esc_url( $full ) . '"><img src="' . esc_url( $large ) . '" alt="' . esc_attr( $alt ) . '" class="wp-image-' . $id . '"/></a></figure>' . "\n"
				. "<!-- /wp:image -->\n";
		}
		$columns = min( 3, count( $ids ) );
		$figcap  = '' !== $caption ? '<figcaption class="blocks-gallery-caption wp-element-caption">' . $caption . '</figcaption>' : '';
		return array(
			'name'   => 'core/gallery',
			'text'   => wp_strip_all_tags( $caption ),
			'markup' => '<!-- wp:gallery {"columns":' . $columns . ',"linkTo":"media","sizeSlug":"large","className":"rcobeca-gallery"} -->' . "\n"
				. '<figure class="wp-block-gallery has-nested-images columns-' . $columns . ' is-cropped rcobeca-gallery">' . "\n" . $inner . $figcap . "</figure>\n<!-- /wp:gallery -->",
		);
	};

	// The prose of a legacy event post (its entry-content), as blocks.
	$legacy = static function ( string $file ) use ( $import ): array {
		$document = new \DOMDocument();
		libxml_use_internal_errors( true );
		$document->loadHTML( $import->snapshot->read( 'raw/html/' . $file ) );
		libxml_clear_errors();
		$content = ( new \DOMXPath( $document ) )->query( '//article//div[contains(@class,"entry-content")]' )->item( 0 );
		$html    = '';
		foreach ( $content ? $content->childNodes : array() as $child ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM API.
			$html .= $document->saveHTML( $child );
		}
		return $import->converter->html_to_blocks( $html );
	};

	// Paragraph blocks of a legacy post whose text contains any of the given phrases.
	$prose = static function ( array $blocks, array $phrases ): array {
		return array_values(
			array_filter(
				$blocks,
				static function ( $block ) use ( $phrases ) {
					foreach ( $phrases as $phrase ) {
						if ( str_contains( $block['text'], $phrase ) ) {
							return true;
						}
					}
					return false;
				}
			)
		);
	};

	return compact( 'link', 'image', 'gallery', 'legacy', 'prose' );
};

/*
 * The Balls known only from the old site's History table (Our Story), where
 * the "Major events" column names each year's dance venue.
 */
$history_balls = array(
	1994 => 'Old Trinity Church, New York',
	1995 => 'Glen Island Casino, New York',
	1996 => 'The Palisadium, New Jersey',
	1997 => 'The Palisadium, New Jersey',
	1998 => 'The Palisadium, New Jersey',
	1999 => 'VIP Country Club, New York',
	2000 => 'The Palisadium, New Jersey',
	2001 => 'The Palisadium, New Jersey',
	2002 => 'The Palisadium, New Jersey',
	2003 => 'The Palisadium, New Jersey',
	2004 => 'VIP Country Club, New York',
	2005 => 'The Villa at Mountain Lakes, New Jersey',
	2006 => 'The Villa at Mountain Lakes, New Jersey',
	2007 => 'VIP Country Club, New York',
	2008 => 'The Villa at Mountain Lakes, New Jersey',
	2009 => 'The Villa at Mountain Lakes, New Jersey',
);

/*
 * Every Event: the facts, the old URLs, and a builder for the page body.
 * A Ball whose body comes out empty has no page of its own (a Past Balls row).
 */
$events = static function ( Context $import, array $h ) use ( $history_balls ): array {
	$link     = $h['link'];
	$image    = $h['image'];
	$gallery  = $h['gallery'];
	$legacy   = $h['legacy'];
	$prose    = $h['prose'];
	$p        = static fn( string $html ) => Blocks::paragraph( $html );
	$heading  = static fn( string $text ) => Blocks::heading( esc_html( $text ) );
	$manor    = 'The Royal Manor';
	$garfield = '454 Midland Ave, Garfield, NJ 07026';
	$events   = array();

	foreach ( $history_balls as $year => $venue ) {
		$events[ "ball-$year" ] = array(
			'type'   => Events::BALL,
			'title'  => "Royal Charity Ball $year",
			'date'   => "$year-01-01",
			'prec'   => 'year',
			'venue'  => $venue,
			'source' => 'History table, Our Story',
			'body'   => static fn() => array(),
		);
	}

	$events['ball-2010'] = array(
		'type'    => Events::BALL,
		'title'   => 'Royal Charity Ball 2010',
		'date'    => '2010-01-01',
		'prec'    => 'year',
		'venue'   => 'The Royal Manor Banquet Hall',
		'address' => 'Garfield, New Jersey',
		'photos'  => 'http://picasaweb.google.com/110423856543558005057/RoyalBall201002#slideshow/5454388134552308306',
		'old'     => array( '/event/royal-ball-2010/' ),
		'body'    => static fn() => array(
			$heading( 'Photos' ),
			$p( $link( 'Photos from the evening', 'http://picasaweb.google.com/110423856543558005057/RoyalBall201002#slideshow/5454388134552308306' ) . ' (Picasa, as kept by the Internet Archive).' ),
			$gallery( array( $image( 'http://rcobeca.org/newsite/wp-content/uploads/2017/01/DSC05087.jpg', 'Guests at the Royal Ball 2010' ) ) ),
		),
	);

	$events['ball-2011'] = array(
		'type'    => Events::BALL,
		'title'   => 'Royal Charity Ball 2011',
		'date'    => '2011-01-01',
		'prec'    => 'year',
		'venue'   => 'The Royal Manor',
		'address' => 'Garfield, New Jersey',
		'photos'  => 'https://www.facebook.com/pg/rcobecf/photos/?tab=album&album_id=2410127272371836',
		'old'     => array( '/event/royal-ball-2011royal-manor-garfield-nj/' ),
		'body'    => static fn() => array(
			$heading( 'Photos' ),
			$p( $link( 'Photos of the event', 'https://www.facebook.com/pg/rcobecf/photos/?tab=album&album_id=2410127272371836' ) . ', on Facebook.' ),
			$gallery( array( $image( 'http://rcobeca.org/newsite/wp-content/uploads/2017/01/18AnuualDinnerDance-300x196.jpg', 'Royal Ball 2011 at the Royal Manor' ) ) ),
		),
	);

	$events['ball-2012'] = array(
		'type'    => Events::BALL,
		'title'   => 'Royal Charity Ball 2012',
		'date'    => '2012-01-01',
		'prec'    => 'year',
		'venue'   => 'The Royal Manor',
		'address' => 'Garfield, New Jersey',
		'old'     => array( '/event/royal-ball-2012-royal-manor-garfield-new-jersey/' ),
		'body'    => static fn() => array(
			$heading( 'Photos' ),
			$p( $link( 'Photos from the event', 'https://picasaweb.google.com/104350235642494691798/RoyalBall2012?authuser=0&feat=directlink#slideshow/5760896681308460354' ) . ', on Picasa.' ),
			$gallery( array( $image( 'http://rcobeca.org/newsite/wp-content/uploads/2017/01/HomePic-300x200.jpg', 'Guests at the Royal Ball 2012' ) ) ),
		),
	);

	$events['ball-2013'] = array(
		'type'    => Events::BALL,
		'title'   => 'Royal Charity Ball 2013',
		'edition' => 20,
		'date'    => '2013-01-01',
		'prec'    => 'year',
		'venue'   => 'The Villa',
		'address' => 'Mountain Lakes, New Jersey',
		'photos'  => 'https://www.facebook.com/media/set/?set=a.537710072946908.1073741827.240808325970419&type=3',
		'old'     => array( '/event/royal-ball-2013-20th-anniversary-royal-ball-the-villa-mountain-lakes-new-jersey/' ),
		'body'    => static fn() => array(
			$p( esc_html( 'The 20th Anniversary Royal Ball, marking twenty years of RCOBECA.' ) ),
			$heading( 'Photos' ),
			$p( $link( 'Photos from the event', 'https://www.facebook.com/media/set/?set=a.537710072946908.1073741827.240808325970419&type=3' ) . ', on Facebook.' ),
			$gallery( array( $image( 'http://rcobeca.org/newsite/wp-content/uploads/2017/01/MG_7321-2469585206-O-300x144.jpg', 'The 20th Anniversary Royal Ball at The Villa, Mountain Lakes' ) ) ),
		),
	);

	$events['ball-2014'] = array(
		'type'    => Events::BALL,
		'title'   => 'Royal Charity Ball 2014',
		'date'    => '2014-01-01',
		'prec'    => 'year',
		'venue'   => 'The Royal Manor',
		'address' => 'Garfield, New Jersey',
		'photos'  => 'http://damminseneratphotography.smugmug.com/Events/Royal-Ball-2014/i-DfpLnVq',
		'video'   => 'https://www.youtube.com/watch?v=U7PxKDe1mWw',
		'old'     => array( '/event/royal-ball-2014/' ),
		'body'    => static fn() => array(
			$heading( 'Photos and video' ),
			$p( $link( 'Photos from the event', 'http://damminseneratphotography.smugmug.com/Events/Royal-Ball-2014/i-DfpLnVq' ) . ' by Dammin Senerat Photography (as kept by the Internet Archive).' ),
			Blocks::embed( 'https://www.youtube.com/watch?v=U7PxKDe1mWw' ),
			$gallery( array( $image( 'http://rcobeca.org/newsite/wp-content/uploads/2017/01/royalball2014-300x171.jpg', 'Royal Ball 2014 at the Royal Manor' ) ) ),
		),
	);

	$events['ball-2015'] = array(
		'type'    => Events::BALL,
		'title'   => 'Royal Charity Ball 2015',
		'date'    => '2015-03-14',
		'venue'   => 'The Royal Manor',
		'address' => 'Garfield, New Jersey',
		'photos'  => 'http://www.damminseneratphotography.com/Events/Royal-Ball-2015/',
		'video'   => 'https://www.youtube.com/watch?v=uVyMeRtU2qE',
		'old'     => array( '/event/royal-ball-2015/' ),
		'body'    => static fn() => array(
			$heading( 'Photos and video' ),
			$p( $link( 'Photos from the event', 'http://www.damminseneratphotography.com/Events/Royal-Ball-2015/' ) . ' by Dammin Senerat Photography (as kept by the Internet Archive).' ),
			Blocks::embed( 'https://www.youtube.com/watch?v=uVyMeRtU2qE' ),
			$gallery( array( $image( 'http://rcobeca.org/newsite/wp-content/uploads/2017/01/RoyalBall2015-300x171.jpg', 'Royal Ball 2015 at the Royal Manor' ) ) ),
		),
	);

	$events['ball-2016'] = array(
		'type'    => Events::BALL,
		'title'   => 'Royal Charity Ball 2016',
		'edition' => 23,
		'date'    => '2016-03-19',
		'venue'   => 'The Royal Manor',
		'address' => 'Garfield, New Jersey',
		'photos'  => 'http://www.damminseneratphotography.com/Events/Royal-Ball-2016/',
		'video'   => 'https://youtu.be/9cImp54bo-0',
		'journal' => 'http://rcobeca.org/2016RoyalBallSouvenir.pdf',
		'old'     => array( '/event/royal-ball-2016/', '/dance2016.html', '/2016RoyalBallSouvenir.pdf' ),
		'body'    => static fn() => array(
			$heading( 'Photos and video' ),
			$p( $link( 'Photos from the event', 'http://www.damminseneratphotography.com/Events/Royal-Ball-2016/' ) . ' by Dammin Senerat Photography (as kept by the Internet Archive).' ),
			$p( esc_html( 'Watch a 15 minute short edit of the Royal Ball 2016:' ) ),
			Blocks::embed( 'https://www.youtube.com/watch?v=zYm3yqQneYQ' ),
			$p( 'Watch the ' . $link( 'complete video from the RCOBECA Ball 2016', 'https://youtu.be/9cImp54bo-0' ) . ' on YouTube.' ),
			$gallery(
				array(
					$image( 'http://rcobeca.org/newsite/wp-content/uploads/2017/01/RoyalBall2016Logo_Small-300x124.jpg', 'Royal Ball 2016 logo' ),
					$image( 'https://rcobeca.org/newsite/wp-content/uploads/2017/01/2016RoyalBallSouvenir_Page_001-791x1024.jpg', 'Cover of the 2016 Royal Ball Souvenir Journal' ),
				)
			),
		),
	);

	$events['ball-2017'] = array(
		'type'    => Events::BALL,
		'title'   => 'Royal Charity Ball 2017',
		'edition' => 24,
		'date'    => '2017-03-01',
		'prec'    => 'month',
		'venue'   => 'The Royal Manor',
		'address' => 'Garfield, New Jersey',
		'video'   => 'https://www.youtube.com/watch?v=zb2rp4Hs3xQ',
		'journal' => 'http://rcobeca.org/2017RoyalBallSouvenir.pdf',
		'old'     => array( '/event/royal-ball-2017/', '/2017RoyalBallSouvenir.pdf' ),
		'body'    => static fn() => array(
			$heading( 'Photos and video' ),
			Blocks::list(
				array(
					$link( 'Gallery 1', 'http://www.damminseneratphotography.com/Events/Royal-Ball-2017/' ) . ' (photo credits: Dammin Senerat; as kept by the Internet Archive)',
					$link( 'Gallery 2', 'https://photos.google.com/share/AF1QipMa_ZdAeTFVco4MsrCNDDK55tcNBiHDRdd6TQZFWuqjN5RxD5vJEMXLBHgEoyjIlA?key=Y0lBdjhaZmk2QUhNbGZKNW1ndFpJa2NBLXc3TDR3' ) . ' (photo credits: Sudath Jayasinghe)',
					$link( 'Gallery 3', 'https://rcobeca.shutterfly.com/484' ) . ' (photo credits: Nirosh Warusawithana)',
				)
			),
			$p( esc_html( 'Watch a 20 minute short edit of the Royal Ball 2017:' ) ),
			Blocks::embed( 'https://www.youtube.com/watch?v=6N_zPwY4njQ' ),
			$p( esc_html( 'Watch the complete video from the RCOBECA Ball 2017:' ) ),
			Blocks::embed( 'https://www.youtube.com/watch?v=zb2rp4Hs3xQ' ),
			$gallery(
				array(
					$image( 'http://rcobeca.org/newsite/wp-content/uploads/2016/07/Event-Logo-300x264.jpg', 'Royal Ball 2017 logo' ),
					$image( 'https://rcobeca.org/newsite/wp-content/uploads/2017/03/2017RoyalBallSouvenir_Page_001-791x1024.jpg', 'Cover of the 2017 Royal Ball Souvenir Journal' ),
				)
			),
		),
	);

	$events['ball-2018'] = array(
		'type'    => Events::BALL,
		'title'   => 'Royal Charity Ball 2018',
		'edition' => 25,
		'date'    => '2018-03-24',
		'venue'   => 'The Royal Manor',
		'address' => 'Garfield, New Jersey',
		'photos'  => 'https://www.facebook.com/media/set/?set=a.1835100749874494&type=3',
		'journal' => 'http://rcobeca.org/2018RoyalBallSouvenir.pdf',
		'old'     => array( '/event/royal-ball-2018/', '/event/royal_ball_2018/', '/2018RoyalBallSouvenir.pdf' ),
		'body'    => static fn() => array(
			$p( esc_html( 'The 25th Annual Royal Ball, marking RCOBECA’s 25th anniversary.' ) ),
			$heading( 'Photos' ),
			$p( $link( 'Photos from the event', 'https://www.facebook.com/media/set/?set=a.1835100749874494&type=3' ) . ', on Facebook.' ),
			$gallery(
				array(
					$image( 'https://rcobeca.org/newsite/wp-content/uploads/2018/05/IMG_2033-300x200.jpg', 'Guests at the Royal Ball 2018' ),
					$image( 'https://rcobeca.org/newsite/wp-content/uploads/2018/05/FIANL-HIGH-RES-updated-RC-2018-8TH-PROOF-Copy-1-800x1024.jpg', 'Cover of the 2018 Royal Ball Souvenir Journal' ),
				)
			),
		),
	);

	$events['ball-2019'] = array(
		'type'    => Events::BALL,
		'title'   => 'Royal Charity Ball 2019',
		'edition' => 26,
		'date'    => '2019-03-30',
		'venue'   => 'The Royal Manor',
		'address' => 'Garfield, New Jersey',
		'photos'  => 'https://www.facebook.com/media/set/?set=a.2902731653111393&type=3',
		'video'   => 'https://www.facebook.com/watch/?v=483339795590372',
		'journal' => 'http://rcobeca.org/2019RoyalBallSouvenir.pdf',
		'thumb'   => 'https://rcobeca.org/newsite/wp-content/uploads/2018/09/RCOBECF_AD-Copy-825x510.jpg',
		'old'     => array( '/event/royal_ball_2019/', '/event/royal-ball-2019-royal-manor-garfield-new-jersey/', '/2019RoyalBallSouvenir.pdf' ),
		'body'    => static fn() => array(
			$heading( 'Photos and video' ),
			Blocks::list(
				array(
					$link( 'Pictures from the dance', 'https://www.facebook.com/media/set/?set=a.2902731653111393&type=3' ) . ', on Facebook',
					$link( 'Video from the dance', 'https://www.facebook.com/watch/?v=483339795590372' ) . ', on Facebook',
				)
			),
			$gallery(
				array(
					$image( 'https://rcobeca.org/newsite/wp-content/uploads/2018/09/RCOBECF_AD-Copy-825x510.jpg', 'Royal Ball 2019 announcement' ),
					$image( 'https://rcobeca.org/newsite/wp-content/uploads/2019/04/DSP_4127-scaled.jpg', 'Guests at the Royal Ball 2019' ),
					$image( 'https://rcobeca.org/newsite/wp-content/uploads/2016/07/Frontpage.jpg', 'Cover of the 2019 Royal Ball Souvenir Journal' ),
				)
			),
		),
	);

	$events['ball-2020'] = array(
		'type'    => Events::BALL,
		'title'   => 'New Year’s Eve Royal Charity Ball 2020',
		'date'    => '2020-12-31',
		'time'    => '9:30 PM to 1:00 AM',
		'venue'   => 'Live on YouTube and Facebook',
		'artists' => 'MISTY, “Sri Lanka’s most acclaimed band”',
		'cause'   => 'Food and dry rations for COVID-19-impacted families, of all ethnicities, religions and regions, throughout Sri Lanka and New York',
		'video'   => 'https://www.youtube.com/watch?v=5N8_-v8SgnI',
		'thumb'   => 'https://rcobeca.org/newsite/wp-content/uploads/2020/12/logo1-825x435.jpg',
		'old'     => array( '/event/nye2020/', '/event/royal_ball_2020/' ),
		'body'    => static function () use ( $p, $heading, $link, $gallery, $image, $legacy, $prose ) {
			$postponed = $prose( $legacy( 'event__royal_ball_2020.html' ), array( 'Due to the current COVID-19', 'All tickets purchased', 'Senaka Senaviratne' ) );
			foreach ( $postponed as &$block ) {
				$block = Blocks::paragraph( str_replace( array( '<strong>', '</strong>' ), '', Blocks::inner( $block ) ) );
			}
			unset( $block );
			return array_merge(
				array(
					$p( esc_html( 'A live-streamed New Year’s Eve event in place of the Ball, to raise funds for COVID-19 impacted families throughout Sri Lanka and New York. Music was provided by Sri Lanka’s most acclaimed band, MISTY.' ) ),
					$p( esc_html( 'New Year was ushered in by donating food and dry rations to impacted families covering all ethnicities, religions, and regions of Sri Lanka and New York.' ) ),
					$p( esc_html( 'The event was 100% funded by RCOBECF, and 100% of all donations went to charity. Donations were welcome by Zelle to treasurer@rcobeca.org, through PayPal (paypal.me/rcobecf) or by credit card. RCOBECF is a registered 501(c)(3) charitable organization.' ) ),
					$heading( 'Watch the live stream' ),
					Blocks::list(
						array(
							$link( 'On YouTube', 'https://www.youtube.com/watch?v=5N8_-v8SgnI' ),
							$link( 'On Facebook Live', 'https://www.facebook.com/rcobecf/videos/2858432954477890/' ),
						)
					),
					$gallery( array( $image( 'https://rcobeca.org/newsite/wp-content/uploads/2020/12/RoyalBall2020-ThankYou-1.jpg', 'Thank-you card from the New Year’s Eve Royal Charity Ball 2020' ) ) ),
					$heading( 'The March 2020 Ball was postponed' ),
					$p( esc_html( 'The 27th Royal Charity Ball was planned for Saturday, March 28th, 2020 at the Royal Manor, Garfield, New Jersey: cocktail hour at 6:30 PM, dancing to the music of Sri Lanka’s most acclaimed band, a local band and live DJ music, a multinational buffet dinner and open bar, free valet parking, and a chance to win airline tickets and other fabulous prizes. Tickets were $160, with discounted tickets for those under 21.' ) ),
				),
				$postponed,
				array(
					$gallery(
						array(
							$image( 'https://rcobeca.org/newsite/wp-content/uploads/2020/03/RB2020-LOGO-smallcovid-825x510.jpg', 'Royal Charity Ball 2020 logo with the postponement notice' ),
							$image( 'https://rcobeca.org/newsite/wp-content/uploads/2020/01/RC-BAll-Postponed-3-13-20.jpg', 'Notice that the Royal Charity Ball 2020 is postponed' ),
							$image( 'https://rcobeca.org/newsite/wp-content/uploads/2020/01/RoyalBall2020-1.jpg', 'Flyer for the Royal Charity Ball 2020, planned for March 28, 2020' ),
						)
					),
				)
			);
		},
	);

	$events['ball-2023'] = array(
		'type'        => Events::BALL,
		'title'       => 'Royal Charity Ball 2023',
		'date'        => '2023-04-01',
		'time'        => '6:30 PM',
		'venue'       => $manor,
		'address'     => $garfield,
		'edition'     => 27,
		'cause'       => 'Essential academic and student enrichment programs at Royal College, Sri Lanka, that are not covered by public funding, and other charitable causes in the United States and Sri Lanka',
		'photos'      => 'https://www.facebook.com/media/set/?set=a.622682853382993&type=3',
		'journal'     => 'http://rcobeca.org/2023RoyalBallSouvenir.pdf',
		'ad_tiers'    => "Personal full-page color advertisement | $150\nCommercial full-page color advertisement | $250\nSilver full-page color advertisement | $500\nGold full-page color advertisement | $1,000\nPlatinum full-page color advertisement | $2,500",
		'ad_deadline' => '2023-03-17',
		'ad_specs'    => "Page size 8.5 x 11 (Letter), portrait\nFinal ad copy as PDF, TIFF or JPEG only\nEmail the ad copy to AdCopy@rcobeca.org\nAll ads are tax-deductible",
		'thumb'       => 'https://rcobeca.org/newsite/wp-content/uploads/2021/12/Logo-825x510.jpg',
		'old'         => array( '/event/royalball2023/', '/2023RoyalBallSouvenir.pdf' ),
		'body'        => static function () use ( $p, $heading, $link, $gallery, $image, $import ) {
			$ad    = $import->converter->to_blocks( $import->snapshot->page( 'personal-full-page-color-advertisement' )['content']['rendered'] );
			$ad    = array_values( array_filter( $ad, static fn( $b ) => str_contains( $b['text'], 'Your contributions' ) ) );
			$thank = $import->converter->to_blocks( $import->snapshot->page( 'royal-ball-ad-thank-you' )['content']['rendered'] );
			foreach ( $thank as &$block ) {
				$block = Blocks::paragraph( str_replace( 'Foundatin', 'Foundation', Blocks::inner( $block ) ) );
			}
			unset( $block );
			return array_merge(
				array(
					$heading( 'Photos and video' ),
					Blocks::list(
						array(
							$link( 'Pictures from the dance', 'https://www.facebook.com/media/set/?set=a.622682853382993&type=3' ) . ', on Facebook',
							$link( 'Video from the dance', 'https://fb.watch/mIpprPTvEE/' ),
						)
					),
					$gallery(
						array(
							$image( 'https://rcobeca.org/newsite/wp-content/uploads/2021/12/CWRPhoto_RoyalCollege-5536-scaled.jpg', 'Guests at the 27th Royal Charity Ball' ),
							$image( 'https://rcobeca.org/newsite/wp-content/uploads/2021/12/FrontPage.jpg', 'Cover of the 2023 Royal Ball Souvenir Journal' ),
						)
					),
					$heading( 'Souvenir Journal ads' ),
					$p( esc_html( 'For the 2023 Souvenir Journal, sponsors bought full-page color advertisements online. The ad submission deadline was March 17, 2023.' ) ),
				),
				$ad,
				array( $p( esc_html( 'RCOBEC Foundation is a 501(c) 3 Approved Public Non-profit Organization. Ads were paid by PayPal; the final price included the PayPal service fee.' ) ) ),
				array( $heading( 'Thank you to our sponsors' ) ),
				$thank
			);
		},
	);

	$events['ball-2024'] = array(
		'type'    => Events::BALL,
		'title'   => 'Royal Charity Ball 2024',
		'date'    => '2024-04-06',
		'time'    => 'Cocktail hour starts at 6 PM',
		'venue'   => $manor,
		'address' => $garfield,
		'edition' => 28,
		'prices'  => '$175 (a limited number of discounted tickets for those under 21)',
		'artists' => 'A prominent Sri Lankan band and DJ',
		'photos'  => 'https://www.9photographyny.com/Events/Royal-ball-2024',
		'video'   => 'https://www.facebook.com/watch/?v=1148307466395130',
		'thumb'   => 'https://rcobeca.org/newsite/wp-content/uploads/2024/02/Screenshot-2024-02-20-at-4.32.25-PM-1-825x510.png',
		'old'     => array( '/event/royalball2024/' ),
		'body'    => static fn() => array(
			$p( esc_html( 'Tickets were sold through TicketSpice.' ) ),
			$heading( 'Photos and video' ),
			Blocks::list(
				array(
					$link( 'Event photos', 'https://www.9photographyny.com/Events/Royal-ball-2024' ) . ' by 9 Photography NY',
					$link( 'The Royal Ball dance video', 'https://www.facebook.com/watch/?v=1148307466395130' ) . ', on Facebook',
				)
			),
			$gallery( array( $image( 'https://rcobeca.org/newsite/wp-content/uploads/2024/02/RoyalBall2024Flyer-1-pdf.jpg', 'Flyer for the 28th Royal Charity Ball 2024' ) ) ),
		),
	);

	$events['ball-2025'] = array(
		'type'    => Events::BALL,
		'title'   => 'Royal Charity Ball 2025',
		'date'    => '2025-04-26',
		'time'    => 'Cocktail hour starts at 6 PM',
		'prices'  => '$180 (discounted tickets for those under 21)',
		'artists' => 'A prominent Sri Lankan band with guest artists from Sri Lanka, and live DJ music',
		'venue'   => $manor,
		'address' => 'Garfield, New Jersey',
		'edition' => 29,
		'cause'   => 'Royal College, Colombo, Sri Lanka, and charitable projects in underprivileged Sri Lankan communities',
		'photos'  => 'https://www.9photographyny.com/Events/Royal-Dinner-Dance-2025',
		'video'   => 'https://youtu.be/_0S98HddJn4',
		'journal' => 'https://rcobeca.org/newsite/wp-content/uploads/2025/05/29th-Royal-Ball-Souvenir-04302025.pdf',
		'thumb'   => 'https://rcobeca.org/newsite/wp-content/uploads/2025/01/29th-Royal-ball-flyer-banner-825x510.png',
		'old'     => array( '/event/29th-royal-charity-ball-2025/' ),
		'body'    => static fn() => array(
			$p( esc_html( 'The 29th Annual Royal Charity Ball raised funds for Royal College, Colombo, Sri Lanka, and for charitable projects in the underprivileged Sri Lankan community. Souvenir Journal ads were sold through TicketSpice.' ) ),
			$heading( 'Photos and video' ),
			Blocks::list(
				array(
					$link( 'Event photos', 'https://www.9photographyny.com/Events/Royal-Dinner-Dance-2025' ) . ' by 9 Photography NY',
					$link( 'Event video', 'https://youtu.be/_0S98HddJn4' ) . ', on YouTube',
				)
			),
			$gallery( array( $image( 'https://rcobeca.org/newsite/wp-content/uploads/2025/01/29th-Royal-Ball-Flyer_Img.png', 'Flyer for the 29th Annual Royal Charity Ball 2025' ) ) ),
		),
	);

	$events['ball-2026'] = array(
		'type'       => Events::BALL,
		'title'      => 'Royal Charity Ball 2026',
		'date'       => '2026-04-25',
		'time'       => 'Cocktail hour starts at 6 PM; until midnight',
		'prices'     => '$195 (discounted tickets for those under 21)',
		'artists'    => 'A prominent Sri Lankan band with guest artists from Sri Lanka, and live DJ music',
		'venue'      => $manor,
		'address'    => $garfield,
		'edition'    => 30,
		'ticket_url' => 'https://www.zeffy.com/en-US/ticketing/30th-annual-royal-charity-ball',
		'ad_url'     => 'https://www.zeffy.com/en-US/ticketing/30th-annual-royal-charity-ball',
		'photos'     => 'https://www.9photographyny.com/Events/Royal-Ball-2026',
		'video'      => 'https://www.youtube.com/watch?v=bsz1xWRg-5o',
		'journal'    => 'https://rcobeca.org/newsite/wp-content/uploads/2026/05/2-RC-BOOK-2026-revised-file-05-5-26.pdf',
		'thumb'      => 'https://rcobeca.org/newsite/wp-content/uploads/2026/02/RB-Web-Banner-825x510.png',
		'state'      => 'between',
		'old'        => array( '/event/30th-annual-royal-charity-ball-2026/' ),
		'body'       => static fn() => array(
			$p( esc_html( 'Join us for the Royal Charity Ball 2026: an unforgettable evening of music, dancing, fine dining, and camaraderie in support of a noble cause.' ) ),
			$p( esc_html( 'Tickets, sponsorships, Souvenir Journal ads and donations were taken through Zeffy.' ) ),
			$heading( 'Be a part of history. Join the celebration!' ),
			Blocks::embed( 'https://www.youtube.com/watch?v=bsz1xWRg-5o' ),
			$heading( 'Photos' ),
			$p( $link( 'Event photos', 'https://www.9photographyny.com/Events/Royal-Ball-2026' ) . ' by 9 Photography NY.' ),
			$gallery(
				array(
					$image( 'https://rcobeca.org/newsite/wp-content/uploads/2026/02/2026-RC-DinnerDanceFlyer.jpeg', 'Flyer for the 30th Annual Royal Charity Ball 2026' ),
					$image( 'https://rcobeca.org/newsite/wp-content/uploads/2026/02/Zeffy-ticketing-sponsor-instructions-scaled.png', 'How to buy tickets, sponsorships and Souvenir Journal ads on Zeffy, step by step' ),
				)
			),
		),
	);

	/*
	 * Other Events.
	 */
	$events['royal-cruise-2017']     = array(
		'type'    => 'other',
		'title'   => 'Royal Cruise 2017',
		'date'    => '2017-05-20',
		'time'    => 'Sailing at 7:00 PM',
		'venue'   => 'Boat leaving from 225 Ellis St',
		'address' => 'Staten Island, NY 10307',
		'prices'  => '$60 per adult and $30 for children under 18 (limited tickets)',
		'photos'  => 'https://goo.gl/photos/nPKWgz7u4Qznxay17',
		'old'     => array( '/event/2017-royal-cruise/' ),
		'body'    => static fn() => array(
			$p( esc_html( '“Gangway lowered for the 2017 Royal Cruise”: a six-hour cruise past the Statue of Liberty and the Manhattan skyline at night, with Sri Lankan appetizers and buffet, a cash bar and a five-piece Sri Lankan live band. Free parking; dress code smart casual. Tickets were sold online and through tickets@rcobeca.org.' ) ),
			$p( $link( 'Pictures from the event', 'https://goo.gl/photos/nPKWgz7u4Qznxay17' ) . ' (photo credits: Sudath Jayasinghe).' ),
			$gallery( array( $image( 'https://rcobeca.org/newsite/wp-content/uploads/2017/03/Royal-Cruise-2017-1.jpg', 'Flyer for the Royal Cruise 2017, Saturday May 20, 2017' ) ) ),
		),
	);
	$events['acoba-2017']            = array(
		'type'    => 'cricket-festival',
		'title'   => 'ACOBA East Coast Cricket Festival 2017',
		'date'    => '2017-06-17',
		'venue'   => 'Tall Timbers Park',
		'address' => '178 Culver Road, Dayton, NJ',
		'photos'  => 'https://www.facebook.com/media/set/?set=a.1498837040167535.1073741838.240808325970419&type=1&l=7bc9043a44',
		'old'     => array( '/event/acoba-2017/' ),
		'body'    => static fn() => array(
			$p( esc_html( 'The 12th East Coast Cricket Festival, organised by the Ananda College Old Boys’ Association East Coast USA: a day of cricket, volleyball, kids’ games, food, music and more.' ) ),
			$p( $link( 'Pictures from the event', 'https://www.facebook.com/media/set/?set=a.1498837040167535.1073741838.240808325970419&type=1&l=7bc9043a44' ) . ', on Facebook.' ),
			$gallery( array( $image( 'https://rcobeca.org/newsite/wp-content/uploads/2017/03/Ananda-College-2017-1.jpg', 'ACOBA East Coast Cricket Festival 2017' ) ) ),
		),
	);
	$events['acoba-2018']            = array(
		'type'   => 'cricket-festival',
		'title'  => 'ACOBA East Coast Cricket Festival 2018',
		'date'   => '2018-06-01',
		'prec'   => 'month',
		'venue'  => 'New Jersey',
		'photos' => 'https://www.facebook.com/media/set/?set=a.1973327396051828&type=1&l=3066ecd9c0',
		'video'  => 'https://www.facebook.com/rcobeca/videos/269312860459091/',
		'old'    => array( '/event/acoba-2018/' ),
		'body'   => static function () use ( $p, $heading, $link, $gallery, $image, $legacy ) {
			$article = array();
			foreach ( Blocks::section( $legacy( 'event__acoba-2018.html' ), 'East Coast Cricket Festival the Annual Big Match in the US' ) as $block ) {
				if ( 'core/paragraph' === $block['name'] && ! str_contains( $block['text'], 'sundaytimes.lk' ) && ! str_contains( $block['text'], 'The above article' ) ) {
					$article[] = $block;
				}
			}
			return array_merge(
				array(
					$p( esc_html( 'The 13th East Coast Cricket Festival, organised by ACOBA USA. Royal College won it, beating St. Joseph’s in the final.' ) ),
					Blocks::list(
						array(
							$link( 'Pictures from the event', 'https://www.facebook.com/media/set/?set=a.1973327396051828&type=1&l=3066ecd9c0' ) . ', on Facebook',
							$link( 'Drone footage', 'https://www.facebook.com/rcobeca/videos/269312860459091/' ) . ', on Facebook',
						)
					),
					$heading( 'East Coast Cricket Festival the Annual Big Match in the US' ),
				),
				$article,
				array(
					$p( '<em>From ' . $link( 'the Sunday Times (Sri Lanka), June 24, 2018', 'http://www.sundaytimes.lk/180624/sports/east-coast-cricket-festival-the-annual-big-match-in-the-us-299396.html' ) . '.</em>' ),
					$gallery( array( $image( 'http://rcobeca.org/newsite/wp-content/uploads/2018/09/trophy_presentation-300x225.jpg', 'Royal College receive the Henry Steel Olcott Trophy at the East Coast Cricket Festival 2018' ) ) ),
				)
			);
		},
	);
	$events['acoba-2019']            = array(
		'type'    => 'cricket-festival',
		'title'   => 'ACOBA East Coast Cricket Festival 2019',
		'date'    => '2019-06-15',
		'time'    => 'From dawn to dusk',
		'venue'   => 'Tall Timbers Park',
		'address' => 'Monmouth Junction, NJ',
		'old'     => array( '/event/acoba-east-coast-cricket-festival-2019/' ),
		'body'    => static fn() => array(
			$p( esc_html( 'The Ananda College Old Boys’ Association East Coast presented the 14th Annual East Coast Cricket Festival: cricket, volleyball, kids’ games, food, music and more, from dawn to dusk.' ) ),
			$p( esc_html( 'Teams: Ananda College, Royal College, Trinity College, St. John’s College, Maris Stella College, Nalanda College, St. Peter’s College, S. Thomas’ College, Mahanama College and St. Joseph’s College.' ) ),
			$gallery( array( $image( 'https://rcobeca.org/newsite/wp-content/uploads/2019/06/flyer-1-801x1024.jpg', 'Flyer for the ACOBA East Coast Cricket Festival 2019' ) ) ),
		),
	);
	$events['smart-conference-room'] = array(
		'type'    => 'other',
		'title'   => 'Grand Opening of the Smart Conference Room',
		'date'    => '2024-08-29',
		'time'    => '3:30 PM in Sri Lanka (6:00 AM EST)',
		'venue'   => 'Royal College',
		'address' => 'Colombo, Sri Lanka',
		'thumb'   => 'https://rcobeca.org/newsite/wp-content/uploads/2024/08/Screenshot-2024-08-24-at-11.27.10-AM-e1724513955389-825x510.png',
		'old'     => array( '/event/smart-conference-room/' ),
		'body'    => static fn() => array(
			$p( 'The ceremonial opening of the new Smart Conference Room at Royal College, in the presence of <strong>Mr. Thilak Waththuhewa</strong>, Principal of Royal College.' ),
			$p( 'This cutting-edge space was made possible by generous funding from the <strong>RCOBEC Foundation</strong> and <strong>DiNi Communications, Inc.</strong>, with service support from the <strong>Sri Lanka Navy</strong>.' ),
			$gallery( array( $image( 'https://rcobeca.org/newsite/wp-content/uploads/2024/08/Screenshot-2024-08-24-at-11.27.10-AM-1-787x1024.png', 'Invitation to the grand opening of the Smart Conference Room at Royal College, August 29, 2024' ) ) ),
		),
	);

	return $events;
};

/*
 * Saves one Event and its old URLs.
 */
$save = static function ( Context $import, string $key, array $event, array $h ): int {
	$journal = isset( $event['journal'] ) ? $import->media->import( $event['journal'], array( 'title' => $event['title'] . ' Souvenir Journal' ) ) : 0;
	$thumb   = isset( $event['thumb'] ) ? $h['image']( $event['thumb'], $event['title'] ) : 0;
	$blocks  = array_values( array_filter( ( $event['body'] )() ) );
	$meta    = array(
		'rcobeca_event_type'     => $event['type'],
		'rcobeca_date'           => $event['date'],
		'rcobeca_date_precision' => $event['prec'] ?? 'day',
		'rcobeca_time'           => $event['time'] ?? '',
		'rcobeca_venue'          => $event['venue'] ?? '',
		'rcobeca_address'        => $event['address'] ?? '',
		'rcobeca_ticket_url'     => $event['ticket_url'] ?? '',
		'rcobeca_ticket_prices'  => $event['prices'] ?? '',
		'rcobeca_photos_url'     => $event['photos'] ?? '',
		'rcobeca_video_url'      => $event['video'] ?? '',
		'rcobeca_ball_state'     => $event['state'] ?? '',
		'rcobeca_edition'        => $event['edition'] ?? 0,
		'rcobeca_artists'        => $event['artists'] ?? '',
		'rcobeca_cause'          => $event['cause'] ?? '',
		'rcobeca_funds_raised'   => $event['raised'] ?? '',
		'rcobeca_journal'        => $journal,
		'rcobeca_ad_tiers'       => $event['ad_tiers'] ?? '',
		'rcobeca_ad_url'         => $event['ad_url'] ?? '',
		'rcobeca_ad_deadline'    => $event['ad_deadline'] ?? '',
		'rcobeca_ad_specs'       => $event['ad_specs'] ?? '',
	);
	if ( $thumb ) {
		$meta['_thumbnail_id'] = $thumb;
	} elseif ( ! $thumb && preg_match( '/wp-image-(\d+)/', Blocks::markup( $blocks ), $m ) ) {
		$meta['_thumbnail_id'] = (int) $m[1];
	}
	$id = $import->upsert(
		'event:' . $key,
		array(
			'post_type'    => Events::POST_TYPE,
			'post_name'    => sanitize_title( $event['title'] ),
			'post_title'   => $event['title'],
			'post_content' => Blocks::markup( $blocks ),
		),
		$meta
	);
	if ( ! isset( $meta['_thumbnail_id'] ) ) {
		delete_post_thumbnail( $id );
	}
	foreach ( $event['old'] ?? array() as $old ) {
		$import->redirect( $old, Events::has_page( $id ) ? $id : '/ball/past/' );
	}
	return $id;
};

return static function ( Context $import ) use ( $helpers, $events, $save ): void {
	$h   = $helpers( $import );
	$ids = array();
	foreach ( $events( $import, $h ) as $key => $event ) {
		$ids[ $key ] = $save( $import, $key, $event, $h );
	}
	$import->log( count( $ids ) . ' Events' );

	// Events listing, at the old /events/ URL.
	$events_page = $import->upsert(
		'page:events',
		array(
			'post_type'    => 'page',
			'post_name'    => 'events',
			'post_title'   => 'Events',
			'post_excerpt' => 'RCOBECA’s gatherings: the Royal Charity Ball, cricket festivals and more, since 1994.',
			'post_content' => Blocks::markup(
				array(
					Blocks::paragraph( 'Our gatherings over the years: the Royal Charity Ball since 1994, cricket festivals, a Royal Cruise and more. Every Ball has its own story on <a href="' . esc_url( home_url( '/ball/past/' ) ) . '">Past Balls</a>.', 'has-large-font-size' ),
					array(
						'name'   => 'rcobeca/event-list',
						'text'   => '',
						'markup' => '<!-- wp:rcobeca/event-list {"align":"wide"} /-->',
					),
				)
			),
		)
	);
	$import->redirect( '/events/', $events_page );
	$import->moved( '/events/', 'Upcoming and Past Events', $events_page );
	$listings = array( '/events/page/2/', '/events/page/3/', '/event/', '/event/page/2/', '/event/page/3/', '/event_category/events/', '/event_category/recent/', '/event_category/recent/page/2/', '/event_category/recent/page/3/', '/event_category/most-recent/' );
	foreach ( $listings as $listing ) {
		$import->redirect( $listing, $events_page );
	}
	// The 2008–2016 site's Events page, and the 2004 "Future Events" calendar.
	$import->redirect( '/index-2.html', $events_page );
	$import->redirect( '/future.htm', $events_page );
	$import->moved( '/index-2.html', 'Royal Balls 2010–2014', $events_page );
	$import->dropped( '/index-2.html', 'East Coast Cricket Festival 2010', 'not on the current rcobeca.org: the new site carries only the live site’s content' );
	$import->dropped( '/future.htm', '2004 calendar: 11th Royal Ball, AGM, Stag Nite and Summer Picnic', 'not on the current rcobeca.org: the new site carries only the live site’s content' );

	// The permanent Royal Charity Ball page: the newest Ball, in the state set on its Event.
	// Its hero photo: guests on the 2019 Ball night, from that Ball's gallery.
	$hero      = $import->media->find( 'https://rcobeca.org/newsite/wp-content/uploads/2019/04/DSP_4127-scaled.jpg' );
	$ball_page = $import->upsert(
		'page:ball',
		array(
			'post_type'     => 'page',
			'post_name'     => 'ball',
			'post_title'    => 'Royal Charity Ball',
			'post_excerpt'  => 'RCOBECA’s flagship gala since 1994: dinner, music and dancing that fund Royal College, Colombo.',
			'post_content'  => '<!-- wp:rcobeca/ball {' . ( $hero ? '"heroImage":' . $hero . ',' : '' ) . '"align":"full"} /-->',
			// Set as meta below: WordPress refuses a template the active theme lacks (as under PHPUnit).
			'page_template' => '',
		),
		array( '_wp_page_template' => 'full-width' )
	);

	// Past Balls, under the Ball page.
	$past_page = $import->upsert(
		'page:ball-past',
		array(
			'post_type'    => 'page',
			'post_parent'  => $ball_page,
			'post_name'    => 'past',
			'post_title'   => 'Past Balls',
			'post_excerpt' => 'Every Royal Charity Ball since 1994: date, venue, music, tickets, cause, funds raised, photos and Souvenir Journals.',
			'post_content' => Blocks::markup(
				array(
					Blocks::paragraph( 'Every Royal Charity Ball since the first Dinner Dance in 1994, newest first. Balls from before 2010 come from the old site’s History table. Have photos, a programme or a Souvenir Journal from a Ball not shown here? Please share it with <a href="mailto:secretary@rcobeca.org">secretary@rcobeca.org</a>.', 'has-large-font-size' ),
					array(
						'name'   => 'rcobeca/past-balls',
						'text'   => '',
						'markup' => '<!-- wp:rcobeca/past-balls {"align":"wide"} /-->',
					),
				)
			),
		)
	);
	$import->moved( '/about-us/', 'HISTORY table: each year’s dance venue (Major events column)', $past_page );

	// Ball pages, flyers and photo albums of the 2004–2005 site.
	foreach ( array( '/royal_ball2004.htm', '/2004flyer.htm', '/flyer.htm', '/futurevents.htm', '/album1.htm', '/album2.htm', '/Album_Main.htm' ) as $old ) {
		$import->redirect( $old, $past_page );
		$import->dropped( $old, 'Royal Ball details, flyers and photo albums (2003–2005)', 'not on the current rcobeca.org: the new site carries only the live site’s content' );
	}

	// The 2023 Souvenir Journal ad sales and their PayPal thank-you page now live on the Ball page and the 2023 Ball.
	$ball_2023 = $ids['ball-2023'];
	foreach ( array( '/souvenir-journal/', '/personal-full-page-color-advertisement/', '/commercial-full-page-color-advertisement/', '/silver-full-page-color-advertisement/', '/gold-full-page-color-advertisement/', '/platinum-full-page-color-advertisement/', '/royal-ball-ad-thank-you/' ) as $old ) {
		$import->redirect( $old, $ball_page );
	}
	$import->moved( '/souvenir-journal/', '2023 ad tiers, page size, formats, AdCopy@rcobeca.org, deadline', $ball_2023 );
	foreach ( array( 'personal', 'commercial', 'silver', 'gold', 'platinum' ) as $tier ) {
		$import->moved( "/$tier-full-page-color-advertisement/", 'Ad text and price', $ball_2023 );
		$import->dropped( "/$tier-full-page-color-advertisement/", 'PayPal Buy button', 'payments are on Zeffy (ADR 0002); the Ball page links the current Zeffy ad form' );
	}
	$import->moved( '/royal-ball-ad-thank-you/', 'Sponsorship thank-you', $ball_2023 );
	$import->moved( '/event/nye2020/', 'Donation details (Zelle, PayPal)', $ids['ball-2020'] );
	$import->dropped( '/event/nye2020/', 'PayPal donate form, Zelle and PayPal logos, PayPal QR code', 'payments are on Zeffy (ADR 0002); the donation channels are kept as text' );
	$import->dropped( '/event/29th-royal-charity-ball-2025/', 'Duplicate Souvenir Journal PDF (2025/04/29TH_ROYAL_BALL_SOUVENIR.pdf)', 'an earlier upload of the same journal; the final 2025/05 PDF is kept' );
	$import->dropped( '/event/30th-annual-royal-charity-ball-2026/', 'Pay for souvenir ad and donate buttons (Zeffy)', 'the Ball is over; the Zeffy link is kept on the Event and the Ball page offers current forms' );

	// The 2008–2016 home page announced each year's Ball; the page itself is the home page.
	$import->redirect( '/index.html', '/' );
	$import->dropped( '/index.html', 'Yearly Royal Ball announcements (2008–2016)', 'not on the current rcobeca.org: the new site carries only the live site’s content' );
	$import->dropped( 'http://www.rcobeca.org/news.htm', '2005 Dinner-Dance notice and 2004 President’s Message', 'not on the current rcobeca.org: the new site carries only the live site’s content' );

	$import->check( 'Royal Charity Ball dates and venues known only from a flyer, a Souvenir Journal cover or the History table: 2015 (March 14), 2016 (March 19), 2018 (March 24), and the venues of 1994–2009. The 1994 Ball is the History table’s 1993–94 dance.' );
	$import->check( 'Event dates still to the month or year only: Royal Charity Balls 2010–2014 and 2017, ACOBA East Coast Cricket Festival 2018. Add the exact dates if known.' );
	$import->check( 'Ball editions are shown only where a page, flyer or Souvenir Journal cover states them (20th, 23rd–30th). The 27th was planned for 2020 and held in 2023. Confirm the numbering.' );
	$import->check( 'The tax-deductible portion of a Royal Charity Ball ticket (set it on the next Ball’s Event; the Ball page shows it).' );
	$import->check( 'tickets@rcobeca.org (on flyers 2016–2024) is still read: the Ball page gives it for ticket and table questions.' );
};
