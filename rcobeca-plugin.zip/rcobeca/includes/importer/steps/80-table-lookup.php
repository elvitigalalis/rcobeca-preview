<?php
/**
 * Importer step: Table Lookup's own page (ticket #8). /table/ is the short,
 * permanent address for the QR code at the venue; it replaces the old site's
 * empty "Check your Table No." page.
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

return static function ( Context $import ): void {
	$page = $import->upsert(
		'page:table',
		array(
			'post_type'    => 'page',
			'post_name'    => 'table',
			'post_title'   => 'Find your table',
			'post_excerpt' => 'On the night of the Royal Charity Ball, type your full name to see your table number.',
			'post_content' => '<!-- wp:rcobeca/table-lookup /-->',
		)
	);
	$import->redirect( '/check-your-table/', $page );
	$import->moved( '/check-your-table/', 'Check your Table No. (empty page)', $page );
};
