<?php
/**
 * Importer step: joining and getting in touch (ticket #9). Royal College
 * Worldwide, and the redirects from the old pages they replace.
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

/*
 * A lead paragraph: the large first paragraph under a page's title.
 */
$lead = static fn( string $html ): array => array(
	'markup' => "<!-- wp:paragraph {\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\">$html</p>\n<!-- /wp:paragraph -->",
);

/*
 * Royal College Worldwide, from the old Royal College page's "Online
 * Destinations" plus the bodies in docs/research/benchmark-sites.md.
 */
$worldwide = static function ( Context $import ) use ( $lead ): int {
	$card = static function ( string $place, string $name, string $url, string $about, string $extra = '' ): string {
		return '<!-- wp:group {"className":"rcobeca-org","layout":{"type":"default"}} -->
<div class="wp-block-group rcobeca-org"><!-- wp:paragraph {"className":"rcobeca-org__place"} -->
<p class="rcobeca-org__place">' . esc_html( $place ) . '</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"className":"rcobeca-org__name"} -->
<h3 class="wp-block-heading rcobeca-org__name"><a href="' . esc_url( $url ) . '">' . esc_html( $name ) . '</a></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>' . $about . '</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"rcobeca-org__link"} -->
<p class="rcobeca-org__link">' . esc_html( (string) preg_replace( '#^https?://(www\.)?#', '', untrailingslashit( $url ) ) ) . $extra . '</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->';
	};
	$grid = static fn( array $cards ): string => '<!-- wp:group {"className":"rcobeca-orgs","layout":{"type":"default"}} -->
<div class="wp-block-group rcobeca-orgs">' . implode( "\n\n", $cards ) . '</div>
<!-- /wp:group -->';

	$content = Blocks::markup(
		array(
			$lead( 'Wherever Old Royalists settle, they find each other. RCOBECA is one of several Royal College alumni bodies around the world. These are the school and the associations we know of; if we have missed one, <a href="' . esc_url( home_url( '/contact/' ) ) . '">tell the Secretary</a>.' ),
			Blocks::heading( 'In Colombo' ),
		)
	) . "\n\n" . $grid(
		array(
			$card( 'Colombo, Sri Lanka', 'Royal College, Colombo', 'https://royalcollege.lk/', 'The school itself, founded in 1835 as the Colombo Academy. News, admissions and the official history.' ),
			$card( 'Colombo, Sri Lanka', 'Royal College Union', 'https://rcu.lk/', 'The Old Boys’ union of Royal College, founded in 1891, and the parent body of its alumni associations: batch groups, clubs and member offers.' ),
		)
	) . "\n\n" . Blocks::markup( array( Blocks::heading( 'Alumni associations abroad' ) ) ) . "\n\n" . $grid(
		array(
			$card( 'US West Coast', 'Royal College Old Boys Association of North America (RCOBANA)', 'https://www.facebook.com/RCOBANA/', 'Old Boys on the West Coast. In 2002 RCOBANA and RCOBECA together gave the Royal College Rowing Club two new boats.' ),
			$card( 'Washington DC', 'Royal College Alumni Association of Washington DC', 'https://www.facebook.com/royalcollegedc/', 'Old Royalists in and around the US capital.' ),
			$card( 'Ontario, Canada', 'Royal College Old Boys Association of Ontario – Canada', 'https://www.facebook.com/groups/120805988025412/', 'Old Boys in Ontario, meeting through their Facebook group.' ),
			$card( 'United Kingdom', 'Old Royalists’ Association UK', 'https://oldroyalists.org.uk/', 'Old Royalists in the UK, funding scholarships, sport and buildings at the school.', ' · <a href="https://www.facebook.com/ORAUK/">Old Royalists’ Association UK on Facebook</a>' ),
			$card( 'New South Wales and the ACT, Australia', 'Royal College Old Boys’ Association NSW & ACT', 'https://rcoba.org.au/', 'Royal College alumni in New South Wales and the Australian Capital Territory, listed on our old site as the Royal College Old Boys in Australia Association.' ),
		)
	);

	return $import->upsert(
		'page:royal-college-worldwide',
		array(
			'post_type'    => 'page',
			'post_name'    => 'royal-college-worldwide',
			'post_title'   => 'Royal College Worldwide',
			'post_excerpt' => 'Royal College, Colombo, the Royal College Union and Old Royalists’ associations in North America, the UK and Australia.',
			'post_content' => $content,
		)
	);
};

/*
 * Who to write to, as published on the old Contact and Committee pages.
 */
$officers = array(
	array( 'The Secretary', 'General questions, membership and your details', 'secretary@rcobeca.org' ),
	array( 'The Treasurer', 'Donations, dues, receipts and Zelle payments', 'treasurer@rcobeca.org' ),
	array( 'The President', 'The committee and RCOBECA’s direction', 'president@rcobeca.org' ),
	array( 'Souvenir Journal', 'Advertisement copy for the Royal Charity Ball Souvenir Journal', 'AdCopy@rcobeca.org' ),
);

/*
 * The socials, with their labels fixed and URLs modernised (as in the footer).
 */
$socials = '<!-- wp:social-links {"showLabels":true,"className":"is-style-logos-only rcobeca-socials","layout":{"type":"flex","orientation":"vertical"}} -->
<ul class="wp-block-social-links has-visible-labels is-style-logos-only rcobeca-socials"><!-- wp:social-link {"url":"https://www.facebook.com/rcobecf","service":"facebook"} /-->

<!-- wp:social-link {"url":"https://www.instagram.com/rcobeca/","service":"instagram"} /-->

<!-- wp:social-link {"url":"https://x.com/rcobeca","service":"x"} /-->

<!-- wp:social-link {"url":"https://www.linkedin.com/groups/2417585/","service":"linkedin"} /-->

<!-- wp:social-link {"url":"https://www.youtube.com/@rcobeca","service":"youtube"} /--></ul>
<!-- /wp:social-links -->';

/*
 * A form beside an aside: the layout of Contact and Update Your Details.
 */
$form_page = static fn( string $main, string $aside ): string => '<!-- wp:columns {"align":"wide","className":"rcobeca-form-page"} -->
<div class="wp-block-columns alignwide rcobeca-form-page"><!-- wp:column {"width":"62%"} -->
<div class="wp-block-column" style="flex-basis:62%">' . $main . '</div>
<!-- /wp:column -->

<!-- wp:column {"width":"38%","className":"rcobeca-form-page__aside"} -->
<div class="wp-block-column rcobeca-form-page__aside" style="flex-basis:38%">' . $aside . '</div>
<!-- /wp:column --></div>
<!-- /wp:columns -->';

/*
 * Contact: the old page's words with their typos fixed, the new form, and the
 * officers' published addresses and socials.
 */
$contact = static function ( Context $import ) use ( $officers, $socials, $form_page ): int {
	$source = $import->snapshot->page( 'contact-us' );
	$blocks = $import->converter->to_blocks( $source['content']['rendered'], 'Contact' );
	$intro  = array();
	foreach ( Blocks::section( $blocks, 'Get in touch' ) as $block ) {
		if ( 'core/paragraph' === $block['name'] ) {
			$intro[] = Blocks::paragraph( str_replace( 'Fell free', 'Feel free', Blocks::inner( $block ) ) );
		}
	}

	$people = array( Blocks::heading( 'Contact information' ) );
	foreach ( $officers as [ $role, $about, $email ] ) {
		$people[] = Blocks::paragraph( '<strong>' . esc_html( $role ) . '</strong><br>' . esc_html( $about ) . '<br><a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>', 'rcobeca-officer' );
	}
	$people[] = Blocks::heading( 'Follow RCOBECA', 3 );

	$page = $import->upsert(
		'page:contact',
		array(
			'post_type'    => 'page',
			'post_name'    => 'contact',
			'post_title'   => 'Contact',
			'post_excerpt' => 'Write to the RCOBECA committee: the form, the officers’ email addresses and our socials.',
			'post_content' => $form_page(
				Blocks::markup( array_merge( array( Blocks::heading( 'Get in touch' ) ), $intro ) ) . "\n\n<!-- wp:rcobeca/form {\"form\":\"contact\"} /-->",
				Blocks::markup( $people ) . "\n\n" . $socials
			),
		)
	);
	$import->redirect( '/contact-us/', $page );
	foreach ( array( 'Get in touch', 'Secretary email', 'Contact form', 'Social links' ) as $block ) {
		$import->moved( '/contact-us/', $block, $page );
	}
	$import->dropped( '/contact-us/', 'reCAPTCHA', 'replaced by a honeypot field and a rate limit (no third-party script)' );
	$import->check( 'Contact page: it lists president@rcobeca.org, but the old Committee page gives president@rcobeca.com. Confirm the President’s address (and that AdCopy@rcobeca.org is still read).' );

	// Contact pages of the 2004–2016 sites (docs/research/wayback-recovery.md).
	foreach ( array( '/contacts.htm', '/index-8.html', '/thank-co.html' ) as $old ) {
		$import->redirect( $old, $page );
	}
	return $page;
};

/*
 * Update Your Details: the no-login way to keep the Membership Register
 * current (the old paper forms' "Please help us to update our Membership
 * Register"), with the fields of the old join form.
 */
$update_details = static function ( Context $import ) use ( $lead, $form_page ): int {
	$aside = Blocks::markup(
		array(
			Blocks::heading( 'Why it matters' ),
			Blocks::paragraph( 'RCOBECA has no member logins. The Secretary keeps the Membership Register, and this form is how it stays current: a new email, a move, or a batch year we have wrong.' ),
			Blocks::paragraph( 'On the <a href="' . esc_url( home_url( '/life-members/' ) ) . '">Life Members</a> roll and spotted a mistake? Say so under “What has changed?”.' ),
			Blocks::paragraph( 'Prefer email? Write to <a href="mailto:secretary@rcobeca.org">secretary@rcobeca.org</a>.' ),
			Blocks::heading( 'Not a Member yet?', 3 ),
			Blocks::paragraph( 'Annual and Life Membership are a single form on our <a href="' . esc_url( home_url( '/join/' ) ) . '">Join or Renew</a> page.' ),
		)
	);
	return $import->upsert(
		'page:update-your-details',
		array(
			'post_type'    => 'page',
			'post_name'    => 'update-your-details',
			'post_title'   => 'Update Your Details',
			'post_excerpt' => 'Tell the Secretary your new email, address or batch year, so RCOBECA can keep in touch. No login needed.',
			'post_content' => $form_page(
				Blocks::markup( array( $lead( 'Moved, changed your email, or never been on our list? Tell us here and the Secretary will update RCOBECA’s records. It takes a minute and needs no login.' ) ) ) . "\n\n<!-- wp:rcobeca/form {\"form\":\"update-details\"} /-->",
				$aside
			),
		)
	);
};

/*
 * Join or Renew: the two membership types and their dues (from the old Join
 * Us page), why to join, and the Zeffy membership card (one flow: details and
 * payment together; its link is a setting). The old sign-up form and PayPal
 * button are replaced by it.
 */
$join = static function ( Context $import ) use ( $lead ): int {
	$tier = static function ( string $name, string $price, string $per, array $points, string $modifier ): string {
		$items = implode( '', array_map( static fn( $p ) => "<!-- wp:list-item -->\n<li>$p</li>\n<!-- /wp:list-item -->", $points ) );
		return '<!-- wp:group {"tagName":"section","ariaLabel":"' . esc_attr( $name ) . '","className":"rcobeca-tier ' . $modifier . '","layout":{"type":"default"}} -->
<section class="wp-block-group rcobeca-tier ' . $modifier . '" aria-label="' . esc_attr( $name ) . '"><!-- wp:heading {"level":3,"className":"rcobeca-tier__name"} -->
<h3 class="wp-block-heading rcobeca-tier__name">' . esc_html( $name ) . '</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"rcobeca-tier__price"} -->
<p class="rcobeca-tier__price"><strong>' . esc_html( $price ) . '</strong> ' . esc_html( $per ) . '</p>
<!-- /wp:paragraph -->

<!-- wp:list {"className":"rcobeca-tier__points"} -->
<ul class="wp-block-list rcobeca-tier__points">' . $items . '</ul>
<!-- /wp:list --></section>
<!-- /wp:group -->';
	};

	$why = static fn( string $title, string $text ): string => '<!-- wp:group {"className":"rcobeca-reason","layout":{"type":"default"}} -->
<div class="wp-block-group rcobeca-reason"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">' . $title . '</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>' . $text . '</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->';

	$content = implode(
		"\n\n",
		array(
			Blocks::markup( array( $lead( 'Join the Old Boys of Royal College, Colombo, living on the US East Coast. Membership keeps RCOBECA going: the get-togethers, the Royal Charity Ball, and the Projects we fund for the students of Royal College.' ) ) ),
			'<!-- wp:group {"className":"rcobeca-tiers","layout":{"type":"default"}} -->
<div class="wp-block-group rcobeca-tiers">' . $tier(
				'Annual Membership',
				'$30',
				'a year',
				array( 'A full Member of RCOBECA for the Club Year', 'Renew each year with the same form' ),
				'rcobeca-tier--annual'
			) . "\n\n" . $tier(
				'Life Membership',
				'$300',
				'once',
				array( 'A Member for life: never renew again', 'Your name on our <a href="' . esc_url( home_url( '/life-members/' ) ) . '">Life Members</a> roll' ),
				'rcobeca-tier--life'
			) . '</div>
<!-- /wp:group -->',
			Blocks::markup( array( Blocks::heading( 'Why join' ) ) ),
			'<!-- wp:group {"className":"rcobeca-reasons","layout":{"type":"default"}} -->
<div class="wp-block-group rcobeca-reasons">' . implode(
				"\n\n",
				array(
					$why( 'Keep in touch', 'Once your details are verified, you will be included in our mailing list: news of events, the Ball and our Projects.' ),
					$why( 'Bring the family', 'RCOBECA brings Old Boys and their families together for social activities and sports.' ),
					$why( 'Give back to Royal', 'Above all, RCOBECA is a charity that helps the students of Royal College, through the RCOBEC Foundation.' ),
				)
			) . '</div>
<!-- /wp:group -->',
			Blocks::markup( array( Blocks::heading( 'Join or renew online' ) ) ),
			'<!-- wp:columns {"className":"rcobeca-join-pay"} -->
<div class="wp-block-columns rcobeca-join-pay"><!-- wp:column {"width":"40%"} -->
<div class="wp-block-column" style="flex-basis:40%">' . Blocks::markup(
				array(
					Blocks::paragraph( 'One form, a few minutes. Zeffy, the platform RCOBECA uses for all payments, takes your details and your dues together.' ),
					Blocks::list(
						array(
							'Choose Annual or Life Membership.',
							'Fill in your name, contact details and Royal College batch year.',
							'Pay by card. Zeffy emails your receipt straight away.',
						),
						true
					),
					Blocks::paragraph( '<strong>Renewing?</strong> Use the same form each year.' ),
					Blocks::paragraph( '<strong>Already a Member?</strong> Moved or changed your email? <a href="' . esc_url( home_url( '/update-your-details/' ) ) . '">Update your details</a>.' ),
				)
			) . '</div>
<!-- /wp:column -->

<!-- wp:column {"width":"60%"} -->
<div class="wp-block-column" style="flex-basis:60%"><!-- wp:rcobeca/zeffy-card {"formSetting":"membership"} /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->',
			// The newsletter band; the old sign-up pages redirect to #newsletter.
			'<!-- wp:group {"anchor":"newsletter","align":"full","className":"rcobeca-join-newsletter","layout":{"type":"default"}} -->
<div id="newsletter" class="wp-block-group alignfull rcobeca-join-newsletter"><!-- wp:pattern {"slug":"rcobeca/newsletter-band"} /--></div>
<!-- /wp:group -->',
		)
	);

	$page = $import->upsert(
		'page:join',
		array(
			'post_type'    => 'page',
			'post_name'    => 'join',
			'post_title'   => 'Join or Renew',
			'post_excerpt' => 'Become an Annual ($30 a year) or Life ($300) Member of RCOBECA: one Zeffy form for your details and dues.',
			'post_content' => $content,
		)
	);

	$import->redirect( '/join-rcobeca/', $page );
	foreach ( array( 'Sign-up as a Member (intro)', 'Pay Membership Dues (Annual $30, Life $300)' ) as $block ) {
		$import->moved( '/join-rcobeca/', $block, $page );
	}
	$import->dropped( '/join-rcobeca/', 'Sign-up form (Ultimate Form Builder, reCAPTCHA v2)', 'replaced by the Zeffy membership form, which takes details and payment together; its fields live on in Update Your Details' );
	$import->dropped( '/join-rcobeca/', 'PayPal membership button', 'all payments move to Zeffy (ADR 0002)' );
	$import->moved( '/about-us/', 'Join Us Today button', $page );

	// The old site's two bare sign-up forms, replaced by the one newsletter sign-up.
	foreach ( array( '/join-email-list/', '/newsletter/' ) as $old ) {
		$import->redirect( $old, '/join/#newsletter' );
		$import->dropped( $old, 'Sign-up form', 'replaced by the one newsletter sign-up (Zeffy email tool) in the footer and the newsletter band' );
	}
	$import->check( 'Newsletter: set up the sign-up form in Zeffy’s email tool and paste its link in Settings → Join and newsletter. Until then, the sign-up button emails the Secretary. Move the old Newsletter-plugin and "Join Email List" subscribers into Zeffy.' );

	$import->redirect( '/membership-success/', $page );
	$import->dropped( '/membership-success/', 'PayPal thank-you text', 'Zeffy shows its own confirmation and emails the receipt' );

	// Membership form PDFs of the 2008–2016 site.
	foreach ( array( '/MembershipForm.pdf', '/RCOBECA_Membership_Form.pdf', '/2010_RCOBECA_ Membership_Form.pdf' ) as $old ) {
		$import->redirect( $old, $page );
		$import->dropped( $old, 'Paper membership form (dues and the Secretary’s postal address of the time)', 'not on the current rcobeca.org: the new site carries only the live site’s content' );
	}

	$import->check( 'Join or Renew: create the Zeffy membership form (Annual $30, Life $300, with a "Royal College batch year" question) and paste its link in Settings → Join and newsletter. Until then the page shows a placeholder.' );
	return $page;
};

return static function ( Context $import ) use ( $worldwide, $contact, $update_details, $join ): void {
	$import->moved( '/royal_college/', 'Online Destinations', $worldwide( $import ) );
	$contact( $import );
	$update_details( $import );
	$join( $import );
};
