<?php
/**
 * Importer step: old URLs that were theme junk, sent somewhere useful.
 *
 * Theme demo and test team entries (/dgtfw_team/) and the DGT archives belong
 * to the tickets that replace them (Committee #6, Events #7, Projects #4); the
 * converter drops Google+, share and author links from content.
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

return static function ( Context $import ): void {
	// Author archives listed the site's maintainers' posts; there are no authors on the new site.
	foreach ( $import->snapshot->sitemap_paths() as $path ) {
		if ( str_starts_with( $path, '/author/' ) ) {
			$import->redirect( $path, '/' );
		}
	}
};
