<?php
/**
 * Importer step: News, and the old URLs of the old site's front page. Runs
 * last, after every record News lists.
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

/*
 * News: a title band, then the feed of Project and Event stories.
 */
$news = static function ( Context $import ): int {
	$content = <<<'HTML'
<!-- wp:group {"align":"full","className":"rcobeca-title-band","backgroundColor":"cream","layout":{"type":"constrained","contentSize":"1104px"}} -->
<div class="wp-block-group alignfull rcobeca-title-band has-cream-background-color has-background">
<!-- wp:paragraph {"className":"is-style-kicker"} -->
<p class="is-style-kicker">Stories</p>
<!-- /wp:paragraph -->
<!-- wp:post-title {"level":1} /-->
<!-- wp:paragraph {"className":"rcobeca-title-band__lead","fontSize":"large"} -->
<p class="rcobeca-title-band__lead has-large-font-size">What Old Boys on the East Coast have been doing: our Projects at Royal College and across Sri Lanka, the Royal Charity Ball and our other Events.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:rcobeca/news-list {"align":"wide","style":{"spacing":{"margin":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|70"}}}} /-->
HTML;

	return $import->upsert(
		'page:news',
		array(
			'post_type'     => 'page',
			'post_name'     => 'news',
			'post_title'    => 'News',
			'post_excerpt'  => 'Stories of RCOBECA’s Projects at Royal College and in Sri Lanka, and of the Royal Charity Ball and our other Events, newest first.',
			'post_content'  => $content,
			'page_template' => 'default',
		),
		array( '_wp_page_template' => 'full-width' )
	);
};

/*
 * A theme pattern's markup with its real copy (Connect · Give · Attend, the
 * membership band, the newsletter band), stored in the page so the page
 * keeps its content if the theme changes. '' if the theme lacks it.
 */
$pattern = static function ( string $slug ): string {
	$registered = \WP_Block_Patterns_Registry::get_instance()->get_registered( $slug );
	return $registered ? trim( (string) $registered['content'] ) . "\n\n" : '';
};

/*
 * A photo from the old site: [attachment ID, URL at the given size, alt text].
 * $about is what the step that owns the photo describes it with, so the alt
 * text is the same whichever step imports it first.
 */
$photo = static function ( Context $import, string $url, string $about, string $size ): array {
	$id = $import->media->import( $url, array( 'about' => $about ) );
	return array( $id, $id ? (string) wp_get_attachment_image_url( $id, $size ) : '', $id ? (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) : '' );
};

/*
 * A section opened by the section header: kicker, H2, optional intro, "more" link.
 */
$section = static function ( string $kicker, string $heading, string $intro, string $more, string $path, string $body ): string {
	$intro = '' !== $intro ? "<!-- wp:paragraph {\"className\":\"rcobeca-section-header__intro\"} -->\n<p class=\"rcobeca-section-header__intro\">" . esc_html( $intro ) . "</p>\n<!-- /wp:paragraph -->\n" : '';
	return '<!-- wp:group {"tagName":"section","align":"full","className":"rcobeca-home-section","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained"}} -->' . "\n"
		. '<section class="wp-block-group alignfull rcobeca-home-section" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">' . "\n"
		. '<!-- wp:group {"align":"wide","className":"rcobeca-section-header","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->' . "\n"
		. '<div class="wp-block-group alignwide rcobeca-section-header">' . "\n"
		. '<!-- wp:group {"className":"rcobeca-section-header__text","layout":{"type":"default"}} -->' . "\n"
		. '<div class="wp-block-group rcobeca-section-header__text">' . "\n"
		. "<!-- wp:paragraph {\"className\":\"is-style-kicker\"} -->\n<p class=\"is-style-kicker\">" . esc_html( $kicker ) . "</p>\n<!-- /wp:paragraph -->\n"
		. "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">" . esc_html( $heading ) . "</h2>\n<!-- /wp:heading -->\n"
		. $intro
		. "</div>\n<!-- /wp:group -->\n"
		. "<!-- wp:paragraph {\"className\":\"rcobeca-more\"} -->\n<p class=\"rcobeca-more\"><a href=\"" . esc_url( home_url( $path ) ) . '">' . esc_html( $more ) . "</a></p>\n<!-- /wp:paragraph -->\n"
		. "</div>\n<!-- /wp:group -->\n\n"
		. $body
		. "</section>\n<!-- /wp:group -->\n\n";
};

/*
 * The home page (spec #1's order; the announcement bar prints above the
 * header and the trust footer is the footer template part): hero, Connect ·
 * Give · Attend, impact numbers, the Ball band, Projects, News, testimonial,
 * membership and the newsletter band.
 */
$home = static function ( Context $import ) use ( $pattern, $photo, $section ): int {
	// Hero (charity: water): Royal College's main building, the photo the old
	// General Project Fund page used (its card is type-only, so no card repeats it).
	$projects                          = (array) json_decode( (string) file_get_contents( RCOBECA_DIR . '/data/projects.json' ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	[ $hero_id, $hero_url, $hero_alt ] = $photo( $import, (string) ( $projects['causes']['donate-towards-rcobeca-projects']['photo'] ?? '' ), 'Royal College, Colombo: the main building seen through the trees', 'full' );
	$donate                            = esc_url( home_url( '/donate/' ) );
	$join                              = esc_url( home_url( '/join/' ) );
	$hero_image                        = $hero_id
		? '<img class="wp-block-cover__image-background wp-image-' . $hero_id . '" alt="' . esc_attr( $hero_alt ) . '" src="' . esc_url( $hero_url ) . '" data-object-fit="cover"/>'
		: '';
	$hero_attrs                        = $hero_id ? '"url":"' . esc_url( $hero_url ) . '","id":' . $hero_id . ',"alt":"' . esc_attr( $hero_alt ) . '",' : '';
	$hero                              = <<<HTML
<!-- wp:cover {{$hero_attrs}"dimRatio":100,"customGradient":"linear-gradient(90deg,rgba(14,29,66,0.9) 0%,rgba(14,29,66,0.72) 42%,rgba(14,29,66,0.18) 78%)","minHeight":640,"contentPosition":"bottom left","isDark":true,"align":"full","className":"rcobeca-hero","layout":{"type":"constrained","contentSize":"1104px"}} -->
<div class="wp-block-cover alignfull is-dark has-custom-content-position is-position-bottom-left rcobeca-hero" style="min-height:640px">$hero_image<span aria-hidden="true" class="wp-block-cover__background has-background-dim-100 has-background-dim wp-block-cover__gradient-background has-background-gradient" style="background:linear-gradient(90deg,rgba(14,29,66,0.9) 0%,rgba(14,29,66,0.72) 42%,rgba(14,29,66,0.18) 78%)"></span><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"className":"is-style-kicker"} -->
<p class="is-style-kicker">Royal College Old Boys’ East Coast Association</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"rcobeca-hero__title"} -->
<h1 class="wp-block-heading rcobeca-hero__title">Bringing Old Royalists together to help the students of Royal College</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"rcobeca-hero__lead"} -->
<p class="rcobeca-hero__lead">Since 1993, Old Boys of Royal College, Colombo, in New York, New Jersey and Connecticut have met as friends and funded classrooms, labs and scholarships at the College, and relief across Sri Lanka.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"className":"rcobeca-hero__actions"} -->
<div class="wp-block-buttons rcobeca-hero__actions"><!-- wp:button {"className":"is-style-gold"} -->
<div class="wp-block-button is-style-gold"><a class="wp-block-button__link wp-element-button" href="$donate">Give</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline rcobeca-on-dark"} -->
<div class="wp-block-button is-style-outline rcobeca-on-dark"><a class="wp-block-button__link wp-element-button" href="$join">Join</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div></div>
<!-- /wp:cover -->


HTML;

	$projects = $section(
		'What we fund',
		'Projects',
		'Classrooms, labs and scholarships at Royal College, and relief in Sri Lanka when disaster strikes.',
		'See all Projects',
		'/projects/',
		"<!-- wp:rcobeca/project-list {\"filters\":false,\"limit\":3,\"align\":\"wide\"} /-->\n"
	);
	$news     = $section( 'Stories', 'News', '', 'All news', '/news/', "<!-- wp:rcobeca/news-list {\"limit\":3,\"headingLevel\":3,\"align\":\"wide\"} /-->\n" );

	// Testimonial: an Old Boy's own words, from the Sports Recovery Center story.
	$story = get_page_by_path( 'royal-college-swimming-complex-sports-recovery-center-inaugurated', OBJECT, RCOBECA_PROJECT );
	// Its photo: the Center's window-side room (the story's lead photo is a Facebook screenshot).
	[ $quote_id, $quote_url, $quote_alt ] = $photo( $import, 'https://rcobeca.org/newsite/wp-content/uploads/2025/01/PHOTO-2025-01-20-09-43-375.jpg', 'The Sports Recovery Center at the Royal College swimming complex: its window-side room', 'medium_large' );
	$testimonial                          = '';
	if ( $story ) {
		$story_url   = esc_url( (string) get_permalink( $story ) );
		$quote_image = $quote_id
			? "<!-- wp:image {\"id\":$quote_id,\"aspectRatio\":\"4/3\",\"scale\":\"cover\",\"sizeSlug\":\"medium_large\",\"className\":\"rcobeca-testimonial__image\"} -->\n<figure class=\"wp-block-image size-medium_large rcobeca-testimonial__image\"><img src=\"" . esc_url( $quote_url ) . '" alt="' . esc_attr( $quote_alt ) . "\" class=\"wp-image-$quote_id\" style=\"aspect-ratio:4/3;object-fit:cover\"/></figure>\n<!-- /wp:image -->\n"
			: '';
		$testimonial = <<<HTML
<!-- wp:group {"tagName":"section","align":"full","className":"rcobeca-home-section rcobeca-home-testimonial","backgroundColor":"cream","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull rcobeca-home-section rcobeca-home-testimonial has-cream-background-color has-background" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns {"verticalAlignment":"center","align":"wide","className":"rcobeca-testimonial","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center rcobeca-testimonial"><!-- wp:column {"verticalAlignment":"center","width":"56%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:56%"><!-- wp:quote {"className":"is-style-plain rcobeca-testimonial__quote"} -->
<blockquote class="wp-block-quote is-style-plain rcobeca-testimonial__quote"><!-- wp:paragraph -->
<p>As alumni, it is our privilege to give back and ensure that the next generation of Royalists is prepared to shine on national and international stages.</p>
<!-- /wp:paragraph --><cite>Rushdhun Ramzy, President, RCOBEC Foundation, handing over the <a href="$story_url">Sports Recovery Center</a> at Royal College, May 2024</cite></blockquote>
<!-- /wp:quote --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center">$quote_image</div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->


HTML;
	}

	// The Ball band's photo: guests at the 2019 Ball, as on the Royal Charity Ball page.
	$ball_photo = $import->media->find( 'https://rcobeca.org/newsite/wp-content/uploads/2019/04/DSP_4127-scaled.jpg' );

	$content = $hero
		. $pattern( 'rcobeca/action-links' )
		. "<!-- wp:rcobeca/impact-numbers {\"align\":\"full\"} /-->\n\n"
		. '<!-- wp:rcobeca/ball-band {' . ( $ball_photo ? '"image":' . $ball_photo . ',' : '' ) . "\"align\":\"full\"} /-->\n\n"
		. $projects
		. $news
		. $testimonial
		. $pattern( 'rcobeca/cta-band' )
		. $pattern( 'rcobeca/newsletter-band' );

	$id = $import->upsert(
		'page:home',
		array(
			'post_type'     => 'page',
			'post_name'     => 'home',
			'post_title'    => 'Home',
			'post_excerpt'  => 'RCOBECA, the Royal College Old Boys’ East Coast Association: Old Boys of Royal College, Colombo, in the New York tri-state area, giving back to the school and to Sri Lanka since 1993.',
			'post_content'  => $content,
			'page_template' => 'default',
		),
		array( '_wp_page_template' => 'full-width' )
	);
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $id );
	return $id;
};

return static function ( Context $import ) use ( $news, $home ): void {
	$news_id = $news( $import );
	// The 2004–2005 site's news page (its content is not on the current site).
	$import->redirect( '/news.htm', $news_id );
	// The old front page listed posts, ten to a page: its later pages are now News.
	foreach ( range( 2, 10 ) as $page ) {
		$import->redirect( "/page/$page/", $news_id );
	}
	$import->log( 'News page built' );

	$home_id = $home( $import );
	$import->redirect( '/', $home_id );
	$import->moved( '/', 'Home page: mission, Projects and Events', $home_id );
	$import->dropped( '/', 'Theme slider and "Fill text to top bar static" placeholder', 'theme junk; the new hero states the mission' );
	$import->log( 'home page built and set as the front page' );
};
