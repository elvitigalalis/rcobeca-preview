<?php
/**
 * Importer step: the launch sweep (ticket #11). The last old-site pages with
 * no home yet, the Privacy page that replaces the 2008 privacy policy, and
 * /royal-charity-ball/ addresses for the Ball (the name used in the spec and
 * in print). /newsite/ addresses are answered by RCOBECA\Redirects itself.
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

use RCOBECA\Events;

return static function ( Context $import ): void {
	// The Privacy page: what this site does with personal information. Every
	// statement describes how the site is built; RCOBECA approves it before
	// launch (docs/pre-launch.md).
	$privacy_blocks = static function (): array {
		return array(
			Blocks::paragraph( 'This page explains what the RCOBECA website (rcobeca.org) collects about you and what we do with it. The site is run by RCOBECA, the Royal College Old Boys’ East Coast Association, and RCOBEC Foundation Inc., a 501(c)(3) public charity.' ),
			Blocks::heading( 'What you send us' ),
			Blocks::paragraph( 'The Contact and Update Your Details forms ask for your name, email address, Royal College batch year and your message or details. What you send is emailed to the RCOBECA officer it concerns (usually the Secretary) and is not stored on the website. We use it only to answer you and to keep our membership records, and we never sell or share it.' ),
			Blocks::heading( 'Payments, membership and the newsletter' ),
			Blocks::paragraph( 'Donations, membership dues, Ball tickets, sponsorships and newsletter sign-up are handled by <a href="https://www.zeffy.com/en-US/privacy-policy">Zeffy</a>, in forms shown on our pages. Zeffy receives what you type into those forms, sends your receipt, and shares your gift or registration with RCOBEC Foundation. Card details go to Zeffy’s payment processor and never reach this website.' ),
			Blocks::heading( 'Visitor counts' ),
			Blocks::paragraph( 'If we turn on visitor statistics, they come from a privacy-friendly service (Cloudflare Web Analytics or Umami) that counts page views without cookies and without identifying you. The website itself sets no tracking cookies; a cookie is set only when a volunteer logs in to edit the site.' ),
			Blocks::heading( 'Table Lookup on Ball night' ),
			Blocks::paragraph( 'For “Find your table”, we upload the Ball’s seating list shortly before the Ball. Names are stored only in a scrambled form that can be matched but not read back, the lookup shows nothing but your own table number, and the list is deleted automatically the day after the Ball.' ),
			Blocks::heading( 'Questions and corrections' ),
			Blocks::paragraph( 'To ask what we hold about you, to correct it, or to be removed from our lists, email the Secretary at <a href="mailto:secretary@rcobeca.org">secretary@rcobeca.org</a>. We may update this page; the version here is the current one.' ),
		);
	};

	$privacy = $import->upsert(
		'page:privacy',
		array(
			'post_type'    => 'page',
			'post_name'    => 'privacy',
			'post_title'   => 'Privacy',
			'post_excerpt' => 'What the RCOBECA website collects (only what you send through its forms), what it does with it, and how to ask about it.',
			'post_content' => Blocks::markup( $privacy_blocks() ),
		)
	);
	update_option( 'wp_page_for_privacy_policy', $privacy );
	$import->redirect( '/index-6.html', $privacy );
	$import->moved( '/index-6.html', 'Privacy Policy (2008)', $privacy );
	$import->check( 'Privacy page (/privacy/): written for the new site from what it actually does (forms emailed, not stored; cookie-free analytics; Zeffy for payments; seating lists hashed and deleted). RCOBECA should read and approve it; it replaces the 2008 policy, which cited the UK Data Protection Act.' );

	// 2008–2016 site pages whose content is gone: send them to the nearest page.
	$royal_college = (int) ( get_page_by_path( 'royal-college' )->ID ?? 0 );
	foreach ( array( '/documentary.html', '/documentary-l.html' ) as $path ) {
		$import->redirect( $path, $royal_college ? $royal_college : '/royal-college/' );
		$import->dropped( $path, 'Royal College documentary (Flash video)', 'the video was never archived; the page held only the Flash player' );
	}
	$import->redirect( '/directions.htm', '/ball/past/' );
	$import->dropped( '/directions.htm', 'Driving directions to the Palisadium and VIP Country Club', 'directions to venues of the 2000–2004 Balls; the venues are on Past Balls' );
	$import->redirect( '/imagepage.html', '/events/' );
	$import->dropped( '/imagepage.html', 'A single cricket photo (Dreamweaver stub page)', 'no text; the cricket festivals are on Events' );

	// The Ball's long name, in case it was printed or shared that way.
	$import->redirect( '/royal-charity-ball/', '/ball/' );
	$import->redirect( '/royal-charity-ball/past/', '/ball/past/' );
	foreach ( Events::balls() as $ball ) {
		if ( Events::has_page( $ball ) ) {
			$import->redirect( '/royal-charity-ball/' . Events::year( $ball ) . '/', $ball );
		}
	}
	$import->log( 'privacy page and the last old-site redirects added' );
};
