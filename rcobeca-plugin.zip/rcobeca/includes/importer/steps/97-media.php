<?php
/**
 * Importer step: the old uploads no page's own step imports (theme demo
 * images, duplicates, and photos uploaded but never shown), from
 * data/media-files.tsv. A photo joins a "More photos" gallery at the end of
 * the post it belongs to; anything else is recorded as dropped with its
 * reason, so the migration checklist accounts for every public media file.
 *
 * Runs after every step that builds those posts, since they rewrite their
 * content on each run.
 *
 * @package RCOBECA
 */

namespace RCOBECA\Importer;

return static function ( Context $import ): void {
	// Gallery headings; any other post gets "More photos".
	$headings = array(
		'page:our-story'     => 'From RCOBECA’s early Projects',
		'page:royal-college' => 'Royal College in pictures',
		'page:committee'     => 'Committee photos',
	);

	$photos = array();
	foreach ( file( RCOBECA_DIR . '/data/media-files.tsv', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES ) as $line ) {
		if ( '#' === $line[0] ) {
			continue;
		}
		[ $file, $home, $note ] = array_pad( explode( "\t", $line ), 3, '' );
		$url                    = 'https://rcobeca.org/newsite/wp-content/uploads/' . $file;
		if ( 'dropped' === $home ) {
			$import->dropped( $url, Checklist::MEDIA_FILE, $note );
			continue;
		}
		$id = $import->media->import( $url, array( 'about' => $note ) );
		if ( $id && Context::find( $home ) ) {
			$photos[ $home ][] = $id;
			$import->moved( $url, Checklist::MEDIA_FILE, Context::find( $home ) );
		}
	}

	foreach ( $photos as $key => $ids ) {
		$post = Context::find( $key );
		// The gallery from an earlier run (it holds no nested group), if this step runs alone.
		$content = (string) preg_replace( '#\s*<!-- wp:group \{"className":"rcobeca-more-photos"\} -->.*?<!-- /wp:group -->#s', '', (string) get_post_field( 'post_content', $post ) );
		$gallery = Blocks::markup( array( Blocks::heading( $headings[ $key ] ?? 'More photos' ), Blocks::gallery( $ids ) ) );
		$import->upsert(
			$key,
			array(
				'post_type'    => get_post_type( $post ),
				'post_status'  => get_post_status( $post ),
				'post_content' => $content . "\n\n<!-- wp:group {\"className\":\"rcobeca-more-photos\"} -->\n<div class=\"wp-block-group rcobeca-more-photos\">\n$gallery\n</div>\n<!-- /wp:group -->",
			)
		);
	}
	$import->log( count( $photos, COUNT_RECURSIVE ) - count( $photos ) . ' more photos placed on ' . count( $photos ) . ' posts' );
};
