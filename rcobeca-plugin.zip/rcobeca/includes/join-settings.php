<?php
/**
 * Settings → Join and newsletter: the links to RCOBECA's Zeffy membership
 * and newsletter forms. Both are placeholders until RCOBECA creates the forms
 * in Zeffy (docs/pre-launch.md); the pages show a labelled placeholder (the
 * membership card) or fall back to emailing the Secretary (the newsletter)
 * until then.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

/**
 * The Zeffy forms set on this page, by key: option name, label and help.
 *
 * @return array<string, array{option: string, label: string, help: string, example: string}>
 */
function rcobeca_zeffy_settings(): array {
	return array(
		'membership' => array(
			'option'  => 'rcobeca_zeffy_membership_url',
			'label'   => __( 'Zeffy membership form link', 'rcobeca' ),
			'help'    => __( 'Placeholder until RCOBECA creates its membership form in Zeffy (Annual $30, Life $300). Paste the form’s Share link. Shown on Join or Renew.', 'rcobeca' ),
			'example' => 'https://www.zeffy.com/en-US/membership/…',
		),
		'donation'   => array(
			'option'  => 'rcobeca_zeffy_donation_url',
			'label'   => __( 'Zeffy general donation form link', 'rcobeca' ),
			'help'    => __( 'Placeholder until RCOBECA creates a general donation form in Zeffy (once or monthly). Paste the form’s Share link. Shown on Donate; until then Donate links to RCOBEC Foundation’s Zeffy page.', 'rcobeca' ),
			'example' => 'https://www.zeffy.com/en-US/donation-form/…',
		),
		'newsletter' => array(
			'option'  => 'rcobeca_zeffy_newsletter_url',
			'label'   => __( 'Zeffy newsletter sign-up link', 'rcobeca' ),
			'help'    => __( 'Placeholder until RCOBECA sets up its newsletter sign-up in Zeffy’s email tool. Paste the sign-up form’s link. Until then, the footer’s sign-up button emails the Secretary.', 'rcobeca' ),
			'example' => 'https://www.zeffy.com/…',
		),
	);
}

/**
 * The link set for a Zeffy form, or '' while it is still a placeholder.
 *
 * @param string $key "membership" or "newsletter".
 */
function rcobeca_zeffy_setting( string $key ): string {
	$setting = rcobeca_zeffy_settings()[ $key ] ?? null;
	return $setting ? (string) get_option( $setting['option'], '' ) : '';
}

/**
 * Keeps a pasted link only if it is an https link on zeffy.com.
 *
 * @param string $option Option name.
 * @param mixed  $value Submitted value.
 */
function rcobeca_sanitize_zeffy_link( string $option, $value ): string {
	$value = trim( (string) $value );
	if ( '' === $value ) {
		return '';
	}
	if ( null !== rcobeca_zeffy_link( $value ) ) {
		return esc_url_raw( $value );
	}
	add_settings_error( $option, $option, __( 'That is not a Zeffy link (https://www.zeffy.com/…); the previous link was kept.', 'rcobeca' ) );
	return (string) get_option( $option, '' );
}

/**
 * Registers the settings (also used by the REST API and WP-CLI).
 */
function rcobeca_register_join_settings(): void {
	foreach ( rcobeca_zeffy_settings() as $setting ) {
		$option = $setting['option'];
		register_setting(
			'rcobeca_join',
			$option,
			array(
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => static fn( $value ) => rcobeca_sanitize_zeffy_link( $option, $value ),
			)
		);
	}
}
add_action( 'init', 'rcobeca_register_join_settings' );

/**
 * Adds the page under Settings.
 */
function rcobeca_add_join_settings_page(): void {
	add_options_page(
		__( 'Join and newsletter', 'rcobeca' ),
		__( 'Join and newsletter', 'rcobeca' ),
		'manage_options',
		'rcobeca-join',
		'rcobeca_render_join_settings_page'
	);
}
add_action( 'admin_menu', 'rcobeca_add_join_settings_page' );

/**
 * Renders the settings page.
 */
function rcobeca_render_join_settings_page(): void {
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Join and newsletter', 'rcobeca' ); ?></h1>
		<p><?php esc_html_e( 'Links to the forms RCOBECA runs on Zeffy. Payments and email sign-ups happen on Zeffy (ADR 0002); this site only embeds or links to them.', 'rcobeca' ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'rcobeca_join' ); ?>
			<table class="form-table" role="presentation">
				<?php foreach ( rcobeca_zeffy_settings() as $setting ) : ?>
				<tr>
					<th scope="row"><label for="<?php echo esc_attr( $setting['option'] ); ?>"><?php echo esc_html( $setting['label'] ); ?></label></th>
					<td>
						<input type="url" class="large-text code" id="<?php echo esc_attr( $setting['option'] ); ?>" name="<?php echo esc_attr( $setting['option'] ); ?>" value="<?php echo esc_attr( (string) get_option( $setting['option'], '' ) ); ?>" placeholder="<?php echo esc_attr( $setting['example'] ); ?>" aria-describedby="<?php echo esc_attr( $setting['option'] . '-help' ); ?>">
						<p class="description" id="<?php echo esc_attr( $setting['option'] . '-help' ); ?>"><?php echo esc_html( $setting['help'] ); ?></p>
					</td>
				</tr>
				<?php endforeach; ?>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}
