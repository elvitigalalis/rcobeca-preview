<?php
/**
 * Where a Person's name leads outside the Committee pages (search results,
 * "People in this story"): his profile when he has one, else his Club Year
 * in the Committee history, else the Life Members roll. Also the people a
 * story names, and a one-line summary of a Person's service.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

/**
 * A Person's published Committee Terms, newest first, read once per request.
 *
 * @param int $person Person ID.
 * @return array[] Terms (see rcobeca_committee_terms()).
 */
function rcobeca_person_service( int $person ): array {
	static $by_person = null;
	if ( null === $by_person ) {
		$by_person = array();
		foreach ( rcobeca_committee_terms() as $term ) {
			$by_person[ $term['person'] ][] = $term;
		}
	}
	return $by_person[ $person ] ?? array();
}

/**
 * The Term a Person held in a year: his latest in or before that year, else
 * his earliest; with no year, his latest.
 *
 * @param int      $person Person ID.
 * @param int|null $year Starting year of a Club Year.
 * @return array|null Term.
 */
function rcobeca_person_term_at( int $person, ?int $year = null ): ?array {
	$terms = rcobeca_person_service( $person );
	if ( ! $terms ) {
		return null;
	}
	if ( null !== $year ) {
		foreach ( $terms as $term ) {
			if ( $term['year'] <= $year ) {
				return $term;
			}
		}
		return end( $terms );
	}
	return $terms[0];
}

/**
 * Where a Person's name links: his profile, else his Club Year in the
 * Committee history (the one at $year, see rcobeca_person_term_at()), else the
 * Life Members roll; '' when none applies.
 *
 * @param int      $person Person ID.
 * @param int|null $year Club Year to prefer.
 */
function rcobeca_person_url( int $person, ?int $year = null ): string {
	if ( rcobeca_person_has_profile( $person ) ) {
		return (string) get_permalink( $person );
	}
	$term = rcobeca_person_term_at( $person, $year );
	if ( $term ) {
		$history = get_page_by_path( 'committee/history' );
		return $history ? get_permalink( $history ) . '#club-year-' . $term['year'] : '';
	}
	if ( function_exists( 'rcobeca_life_member_since' ) && '' !== rcobeca_life_member_since( $person ) ) {
		$roll = get_page_by_path( 'life-members' );
		return $roll ? (string) get_permalink( $roll ) : '';
	}
	return '';
}

/**
 * A Person's service on one line, newest first, runs of one role joined:
 * "President, 2024–25; President Elect, 2023–24; Committee Member, 2018–19 to 2022–23".
 *
 * @param int $person Person ID.
 */
function rcobeca_person_summary( int $person ): string {
	$runs = array();
	foreach ( rcobeca_person_service( $person ) as $term ) {
		$last = count( $runs ) - 1;
		if ( $last >= 0 && $runs[ $last ]['role'] === $term['role'] && $runs[ $last ]['from'] - 1 <= $term['year'] ) {
			$runs[ $last ]['from'] = min( $runs[ $last ]['from'], $term['year'] );
			continue;
		}
		$runs[] = array(
			'role' => $term['role'],
			'from' => $term['year'],
			'to'   => $term['year'],
		);
	}
	$parts = array();
	foreach ( $runs as $run ) {
		$years   = rcobeca_club_year_label( $run['from'] ) . ( $run['from'] !== $run['to'] ? ' ' . __( 'to', 'rcobeca' ) . ' ' . rcobeca_club_year_label( $run['to'] ) : '' );
		$parts[] = $run['role'] . ', ' . $years;
	}
	if ( function_exists( 'rcobeca_life_member_since' ) && '' !== rcobeca_life_member_since( $person ) ) {
		$parts[] = __( 'Life Member', 'rcobeca' );
	}
	return implode( '; ', $parts );
}

/**
 * The Persons a story names, in the order they first appear. A Person counts
 * when his full name appears as written (any case, whole words).
 *
 * @param int $post Story ID.
 * @return int[] Person IDs.
 */
function rcobeca_story_people( int $post ): array {
	$text = html_entity_decode( wp_strip_all_tags( (string) get_post_field( 'post_content', $post ) ), ENT_QUOTES, 'UTF-8' );
	$text = (string) preg_replace( '/\s+/u', ' ', $text );
	if ( '' === trim( $text ) ) {
		return array();
	}
	$found = array();
	foreach ( get_posts(
		array(
			'post_type'      => 'rcobeca_person',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
		)
	) as $person ) {
		$name = trim( (string) preg_replace( '/\s+/u', ' ', $person->post_title ) );
		if ( '' !== $name && preg_match( '/(?<![\p{L}])' . preg_quote( $name, '/' ) . '(?![\p{L}])/iu', $text, $match, PREG_OFFSET_CAPTURE ) ) {
			$found[ $person->ID ] = $match[0][1];
		}
	}
	asort( $found );
	return array_keys( $found );
}
