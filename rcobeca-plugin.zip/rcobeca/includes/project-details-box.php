<?php
/**
 * The "Project details" box on the Project edit screen: every field in
 * rcobeca_project_fields() as a plain form, dollars instead of cents, with the
 * Zeffy sync's figures and any sync problem shown next to the manual override
 * so a volunteer can see why they might need it.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Fields the Zeffy sync writes: shown, never edited here.
 */
const RCOBECA_PROJECT_SYNCED_FIELDS = array( 'rcobeca_raised_cents', 'rcobeca_raised_synced_at', 'rcobeca_raised_override_at', 'rcobeca_zeffy_sync_error' );

/**
 * Adds the box.
 */
function rcobeca_add_project_details_box(): void {
	add_meta_box( 'rcobeca-project-details', __( 'Project details', 'rcobeca' ), 'rcobeca_project_details_box', RCOBECA_PROJECT, 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'rcobeca_add_project_details_box' );

/**
 * Cents as a dollar figure for an input: 123450 => "1234.50", unset => "".
 *
 * @param mixed $cents Stored value.
 */
function rcobeca_cents_input( $cents ): string {
	if ( '' === $cents || null === $cents || false === $cents ) {
		return '';
	}
	$cents = (int) $cents;
	return 0 === $cents % 100 ? (string) intdiv( $cents, 100 ) : number_format( $cents / 100, 2, '.', '' );
}

/**
 * Renders the box.
 *
 * @param WP_Post $post Project.
 */
function rcobeca_project_details_box( WP_Post $post ): void {
	wp_nonce_field( 'rcobeca_project_details', 'rcobeca_project_nonce' );
	$choices = array(
		'rcobeca_status'      => rcobeca_project_statuses(),
		'rcobeca_beneficiary' => array( '' => __( '— Choose —', 'rcobeca' ) ) + rcobeca_project_beneficiaries(),
	);
	echo '<table class="form-table" role="presentation"><tbody>';
	foreach ( rcobeca_project_fields() as $key => [ $type, $label, $help ] ) {
		if ( in_array( $key, RCOBECA_PROJECT_SYNCED_FIELDS, true ) ) {
			continue;
		}
		if ( 'rcobeca_zeffy_campaign_id' === $key ) {
			echo '<tr><th colspan="2"><h3 style="margin:1em 0 0">' . esc_html__( 'Fundraising', 'rcobeca' ) . '</h3><p class="description" style="font-weight:400">' . esc_html__( 'While the status is Fundraising and a goal is set, the Project shows a progress bar. The amount raised is read from the linked Zeffy form every hour.', 'rcobeca' ) . '</p></th></tr>';
		}
		if ( 'rcobeca_raised_override_cents' === $key ) {
			rcobeca_project_sync_status_row( $post->ID );
		}
		$value = get_post_meta( $post->ID, $key, true );
		$help  = 'rcobeca_status' === $key ? '' : $help;
		echo '<tr><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td>';
		$described = '' !== $help ? ' aria-describedby="' . esc_attr( $key ) . '-help"' : '';
		if ( isset( $choices[ $key ] ) ) {
			$value = 'rcobeca_status' === $key ? rcobeca_project_status( $post->ID ) : (string) $value;
			echo '<select id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '"' . $described . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from esc_attr().
			foreach ( $choices[ $key ] as $option => $text ) {
				echo '<option value="' . esc_attr( $option ) . '"' . selected( $value, (string) $option, false ) . '>' . esc_html( $text ) . '</option>';
			}
			echo '</select>';
		} elseif ( 'rcobeca_timeline' === $key ) {
			echo '<textarea class="large-text" rows="4" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '"' . $described . '>' . esc_textarea( (string) $value ) . '</textarea>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from esc_attr().
		} elseif ( 'integer' === $type ) {
			echo '<input type="text" inputmode="decimal" class="regular-text" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( rcobeca_cents_input( $value ) ) . '"' . $described . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from esc_attr().
		} else {
			$list = 'rcobeca_zeffy_campaign_id' === $key ? rcobeca_zeffy_campaign_options() : '';
			echo '<input type="text" class="regular-text" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( (string) $value ) . '"' . ( '' !== $list ? ' list="rcobeca-zeffy-campaigns"' : '' ) . $described . '>' . $list; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from esc_attr() and esc_html().
		}
		if ( '' !== $help ) {
			echo '<p class="description" id="' . esc_attr( $key ) . '-help">' . esc_html( $help ) . '</p>';
		}
		echo '</td></tr>';
	}
	echo '</tbody></table>';
}

/**
 * The campaigns on the Zeffy account, as a <datalist> for the campaign ID
 * field, so volunteers pick a form by its title. Empty without an API key.
 */
function rcobeca_zeffy_campaign_options(): string {
	$options = '';
	foreach ( RCOBECA\Zeffy_Sync::campaigns() as $id => $title ) {
		$options .= '<option value="' . esc_attr( $id ) . '">' . esc_html( $title ) . '</option>';
	}
	return '' !== $options ? '<datalist id="rcobeca-zeffy-campaigns">' . $options . '</datalist>' : '';
}

/**
 * The read-only row with what the sync last stored, and any problem.
 *
 * @param int $id Project ID.
 */
function rcobeca_project_sync_status_row( int $id ): void {
	$raised = get_post_meta( $id, 'rcobeca_raised_cents', true );
	$at     = (int) get_post_meta( $id, 'rcobeca_raised_synced_at', true );
	$error  = (string) get_post_meta( $id, 'rcobeca_zeffy_sync_error', true );
	echo '<tr><th scope="row">' . esc_html__( 'Raised, synced from Zeffy', 'rcobeca' ) . '</th><td><p>';
	if ( $at ) {
		/* translators: 1: amount, 2: date. */
		echo esc_html( sprintf( __( '%1$s, last synced %2$s', 'rcobeca' ), rcobeca_money( (int) $raised ), wp_date( 'F j, Y g:i a', $at ) ) );
	} else {
		echo esc_html__( 'Not synced yet. Set the Zeffy campaign ID, and ask an administrator to add the Zeffy API key (Settings → Zeffy sync).', 'rcobeca' );
	}
	echo '</p>';
	if ( '' !== $error ) {
		echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Last sync problem:', 'rcobeca' ) . ' ' . esc_html( $error ) . '</p></div>';
	}
	echo '</td></tr>';
}

/**
 * Dollars typed by a volunteer as cents ("$1,234.50" => 123450), or null when
 * left blank.
 *
 * @param string $dollars Input.
 */
function rcobeca_dollars_to_cents( string $dollars ): ?int {
	$dollars = trim( str_replace( array( '$', ',', ' ' ), '', $dollars ) );
	return is_numeric( $dollars ) ? (int) round( (float) $dollars * 100 ) : null;
}

/**
 * Saves the box. Setting or changing the override dates it now; clearing it
 * hands the bar back to Zeffy's figure.
 *
 * @param int $post_id Project ID.
 */
function rcobeca_save_project_details( int $post_id ): void {
	if ( ! isset( $_POST['rcobeca_project_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['rcobeca_project_nonce'] ), 'rcobeca_project_details' ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	foreach ( rcobeca_project_fields() as $key => [ $type ] ) {
		if ( in_array( $key, RCOBECA_PROJECT_SYNCED_FIELDS, true ) ) {
			continue;
		}
		$raw = trim( sanitize_textarea_field( wp_unslash( $_POST[ $key ] ?? '' ) ) );
		if ( 'rcobeca_raised_override_cents' === $key ) {
			$cents = rcobeca_dollars_to_cents( $raw );
			$old   = get_post_meta( $post_id, $key, true );
			if ( null === $cents ) {
				delete_post_meta( $post_id, $key );
				delete_post_meta( $post_id, 'rcobeca_raised_override_at' );
			} elseif ( '' === $old || (int) $old !== $cents ) {
				update_post_meta( $post_id, $key, $cents );
				update_post_meta( $post_id, 'rcobeca_raised_override_at', time() );
			}
		} elseif ( 'integer' === $type ) {
			$cents = rcobeca_dollars_to_cents( $raw );
			null === $cents ? delete_post_meta( $post_id, $key ) : update_post_meta( $post_id, $key, $cents );
		} elseif ( 'rcobeca_status' === $key ) {
			update_post_meta( $post_id, $key, isset( rcobeca_project_statuses()[ $raw ] ) ? $raw : 'completed' );
		} elseif ( 'rcobeca_zeffy_form_url' === $key ) {
			update_post_meta( $post_id, $key, esc_url_raw( $raw ) );
		} else {
			update_post_meta( $post_id, $key, 'rcobeca_timeline' === $key ? $raw : sanitize_text_field( $raw ) );
		}
	}
}
add_action( 'save_post_rcobeca_project', 'rcobeca_save_project_details' );
