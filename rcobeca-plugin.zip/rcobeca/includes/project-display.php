<?php
/**
 * What a Project shows, worked out once for every view (the Project page,
 * listing cards, and later the home page): its status line, money line and
 * progress, and its timeline. Reads post meta only; never calls Zeffy.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Dollars from cents, without cents when whole: 745400 => "$7,454".
 *
 * @param int $cents Amount in US cents.
 */
function rcobeca_money( int $cents ): string {
	$decimals = 0 === $cents % 100 ? 0 : 2;
	return '$' . number_format( $cents / 100, $decimals );
}

/**
 * A Project date (YYYY, YYYY-MM or YYYY-MM-DD) as words: "2013",
 * "June 2018", "June 21, 2017".
 *
 * @param string $date Date.
 */
function rcobeca_project_date_label( string $date ): string {
	$date = trim( $date );
	if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
		return wp_date( 'F j, Y', (int) strtotime( "$date 12:00 UTC" ), new DateTimeZone( 'UTC' ) );
	}
	if ( preg_match( '/^\d{4}-\d{2}$/', $date ) ) {
		return wp_date( 'F Y', (int) strtotime( "$date-01 12:00 UTC" ), new DateTimeZone( 'UTC' ) );
	}
	return $date;
}

/**
 * A Project's year: from its date field, else its publish date.
 *
 * @param int $id Project ID.
 */
function rcobeca_project_year( int $id ): string {
	$date = (string) get_post_meta( $id, 'rcobeca_date', true );
	return preg_match( '/^\d{4}/', $date, $m ) ? $m[0] : get_the_date( 'Y', $id );
}

/**
 * The amount delivered, as written: "Rs 15 million", "$7,454", or ''.
 *
 * @param int $id Project ID.
 */
function rcobeca_project_amount( int $id ): string {
	$text = trim( (string) get_post_meta( $id, 'rcobeca_amount_text', true ) );
	if ( '' !== $text ) {
		return $text;
	}
	$cents = get_post_meta( $id, 'rcobeca_amount_cents', true );
	return '' !== $cents && (int) $cents > 0 ? rcobeca_money( (int) $cents ) : '';
}

/**
 * Fundraising progress, or null when there is no bar to show. The bar shows
 * only while the Project is Fundraising and has a goal. The manual override
 * wins over the figure synced from Zeffy; "as of" is when that figure was set.
 *
 * @param int $id Project ID.
 * @return array{raised: int, goal: int, percent: int, as_of: int}|null
 */
function rcobeca_project_progress( int $id ): ?array {
	$goal = (int) get_post_meta( $id, 'rcobeca_goal_cents', true );
	if ( 'fundraising' !== rcobeca_project_status( $id ) || $goal <= 0 ) {
		return null;
	}
	$override = get_post_meta( $id, 'rcobeca_raised_override_cents', true );
	if ( '' !== $override && null !== $override ) {
		$raised = (int) $override;
		$as_of  = (int) get_post_meta( $id, 'rcobeca_raised_override_at', true );
	} else {
		$raised = (int) get_post_meta( $id, 'rcobeca_raised_cents', true );
		$as_of  = (int) get_post_meta( $id, 'rcobeca_raised_synced_at', true );
	}
	return array(
		'raised'  => $raised,
		'goal'    => $goal,
		'percent' => (int) min( 100, floor( $raised * 100 / $goal ) ),
		'as_of'   => $as_of,
	);
}

/**
 * "$X of $Y raised, as of <date>".
 *
 * @param array $progress From rcobeca_project_progress().
 */
function rcobeca_progress_sentence( array $progress ): string {
	/* translators: 1: amount raised, 2: goal. */
	$sentence = sprintf( __( '%1$s of %2$s raised', 'rcobeca' ), rcobeca_money( $progress['raised'] ), rcobeca_money( $progress['goal'] ) );
	if ( $progress['as_of'] ) {
		/* translators: %s: date. */
		$sentence .= sprintf( __( ', as of %s', 'rcobeca' ), wp_date( 'F j, Y', $progress['as_of'] ) );
	}
	return $sentence;
}

/**
 * The progress bar markup.
 *
 * @param array $progress From rcobeca_project_progress().
 */
function rcobeca_progress_bar( array $progress ): string {
	return sprintf(
		'<div class="rcobeca-progress"><p class="rcobeca-progress__label">%1$s</p><div class="rcobeca-progress__track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="%2$d" aria-label="%3$s"><span class="rcobeca-progress__fill" style="width:%2$d%%"></span></div></div>',
		esc_html( rcobeca_progress_sentence( $progress ) ),
		$progress['percent'],
		/* translators: %d: percent of the goal raised. */
		esc_attr( sprintf( __( '%d%% of the goal raised', 'rcobeca' ), $progress['percent'] ) )
	);
}

/**
 * The money line under a Project: what was delivered, or how giving is going.
 *
 * @param int $id Project ID.
 */
function rcobeca_project_money_line( int $id ): string {
	$status = rcobeca_project_status( $id );
	if ( 'fundraising' === $status ) {
		return rcobeca_project_progress( $id ) ? '' : __( 'Accepting gifts', 'rcobeca' );
	}
	$amount = rcobeca_project_amount( $id );
	if ( 'completed' === $status && '' !== $amount ) {
		/* translators: %s: amount, e.g. "$7,454" or "Rs 15 million". */
		return sprintf( __( '%s delivered', 'rcobeca' ), $amount );
	}
	if ( 'ongoing' === $status ) {
		return '' !== $amount ? sprintf( /* translators: %s: amount. */ __( '%s so far · under way', 'rcobeca' ), $amount ) : __( 'Under way', 'rcobeca' );
	}
	return '';
}

/**
 * The timeline: [date, label, text] per step, in the order written.
 *
 * @param int $id Project ID.
 * @return array<int, array{date: string, label: string, text: string}>
 */
function rcobeca_project_timeline( int $id ): array {
	$steps = array();
	foreach ( preg_split( '/\R/', (string) get_post_meta( $id, 'rcobeca_timeline', true ) ) as $line ) {
		$parts = array_map( 'trim', explode( '|', $line, 3 ) );
		if ( count( $parts ) === 3 && '' !== $parts[0] ) {
			$steps[] = array_combine( array( 'date', 'label', 'text' ), $parts );
		}
	}
	return $steps;
}
