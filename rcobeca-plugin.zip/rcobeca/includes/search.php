<?php
/**
 * Site search: pages, Projects, Events and Persons (Persons are left out of
 * WordPress's own search, because most have no page; here they are found by
 * name and lead to their Club Year). The rcobeca/search-results block shows
 * the results.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

use RCOBECA\Events;

/**
 * What site search looks through.
 *
 * @return string[] Post types.
 */
function rcobeca_search_types(): array {
	return array( 'page', RCOBECA_PROJECT, Events::POST_TYPE, 'rcobeca_person' );
}

/**
 * Pages that are never a search result: the noindex style guide and
 * WordPress's sample page.
 *
 * @return string[] Page paths.
 */
function rcobeca_search_hidden_pages(): array {
	return array( 'style-guide', 'sample-page' );
}

/**
 * Points the front-end search at the site's content types.
 *
 * @param WP_Query $query Query.
 */
function rcobeca_search_query( WP_Query $query ): void {
	if ( is_admin() || ! $query->is_main_query() || ! $query->is_search() ) {
		return;
	}
	$query->set( 'post_type', rcobeca_search_types() );
	$query->set( 'post_status', 'publish' );
	$query->set( 'posts_per_page', 20 );
	$hidden = array();
	foreach ( rcobeca_search_hidden_pages() as $path ) {
		$page = get_page_by_path( $path );
		if ( $page ) {
			$hidden[] = $page->ID;
		}
	}
	if ( $hidden ) {
		$query->set( 'post__not_in', $hidden );
	}
}
add_action( 'pre_get_posts', 'rcobeca_search_query' );

/**
 * One search result as it is shown: what it is, its title and link, a line
 * of text and a photo.
 *
 * @param int $id Post ID.
 * @return array{kind: string, meta: string, title: string, url: string, text: string, image: int}
 */
function rcobeca_search_result( int $id ): array {
	$type   = get_post_type( $id );
	$result = array(
		'kind'  => __( 'Page', 'rcobeca' ),
		'meta'  => '',
		'title' => get_the_title( $id ),
		'url'   => (string) get_permalink( $id ),
		'text'  => rcobeca_story_excerpt( $id, 28 ),
		'image' => (int) get_post_thumbnail_id( $id ),
	);
	if ( RCOBECA_PROJECT === $type ) {
		$result['kind'] = __( 'Project', 'rcobeca' );
		$result['meta'] = implode( ' · ', array_filter( array( rcobeca_project_statuses()[ rcobeca_project_status( $id ) ] ?? '', rcobeca_project_year( $id ) ) ) );
	} elseif ( Events::POST_TYPE === $type ) {
		$result['kind'] = 'other' === Events::type( $id ) ? __( 'Event', 'rcobeca' ) : Events::kicker( $id );
		$result['meta'] = Events::short_date( $id );
	} elseif ( 'rcobeca_person' === $type ) {
		$result['kind']  = __( 'Person', 'rcobeca' );
		$result['title'] = rcobeca_person_name( $id );
		$result['url']   = rcobeca_person_url( $id );
		$result['text']  = rcobeca_person_summary( $id );
		$result['image'] = rcobeca_person_has_profile( $id ) ? $result['image'] : 0;
	}
	return $result;
}
