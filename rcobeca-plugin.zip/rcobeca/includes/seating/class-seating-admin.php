<?php
/**
 * The Seating lists admin screen (Events → Seating lists): a volunteer
 * uploads a Ball's seating CSV, sees how many guests and tables it holds
 * (never the names), deletes a list early, and sets how long lists are kept
 * after the Ball. The CSV is read straight from the upload and never saved
 * as a file or in the media library.
 *
 * @package RCOBECA
 */

namespace RCOBECA;

defined( 'ABSPATH' ) || exit;

/**
 * The admin screen and its form handler.
 */
class Seating_Admin {

	public const PAGE = 'rcobeca-seating';

	public const ACTION = 'rcobeca_seating';

	/**
	 * Editors can use it (they edit others' posts).
	 */
	private const CAPABILITY = 'edit_others_posts';

	/**
	 * Adds the screen under Events.
	 */
	public static function admin_menu(): void {
		add_submenu_page(
			'edit.php?post_type=' . Events::POST_TYPE,
			__( 'Seating lists', 'rcobeca' ),
			__( 'Seating lists', 'rcobeca' ),
			self::CAPABILITY,
			self::PAGE,
			array( self::class, 'render' )
		);
	}

	/**
	 * Balls a list can be uploaded for: those still to come, else the newest.
	 *
	 * @return int[]
	 */
	private static function balls(): array {
		$balls = array_values( array_filter( Events::balls(), array( Events::class, 'is_upcoming' ) ) );
		return $balls ? $balls : array_filter( array( Events::current_ball() ) );
	}

	/**
	 * A timestamp in site time, for people.
	 *
	 * @param int $time Timestamp.
	 */
	private static function when( int $time ): string {
		return (string) wp_date( __( 'l, F j, Y \a\t g:i A', 'rcobeca' ), $time );
	}

	/**
	 * Renders the screen.
	 */
	public static function render(): void {
		$url    = admin_url( 'admin-post.php' );
		$report = get_transient( self::report_key() );
		delete_transient( self::report_key() );
		$with_list = array_filter( Events::balls(), array( Seating::class, 'has_list' ) );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Seating lists', 'rcobeca' ); ?></h1>
			<?php self::notices( is_array( $report ) ? $report : array() ); ?>
			<p><?php esc_html_e( 'On Ball night, guests type their full name on the Ball page or at /table/ (the address for the QR code at the venue) and see only their table number. The lookup answers only while the Ball page is set to “Ball night”.', 'rcobeca' ); ?></p>
			<p><?php esc_html_e( 'The list is private: names are never shown on the site, in search or anywhere in this admin, and the list is deleted automatically after the Ball.', 'rcobeca' ); ?></p>

			<h2><?php esc_html_e( 'Upload a seating list', 'rcobeca' ); ?></h2>
			<p><?php esc_html_e( 'A CSV file with two columns: the guest’s full name (first and last) and the table, for example “Nimal Perera,12”. A header row is fine. Save it from Excel or Google Sheets as CSV. Uploading again replaces the Ball’s whole list.', 'rcobeca' ); ?></p>
			<form method="post" action="<?php echo esc_url( $url ); ?>" enctype="multipart/form-data">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
				<input type="hidden" name="do" value="upload">
				<?php wp_nonce_field( self::ACTION ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="rcobeca-seating-ball"><?php esc_html_e( 'Ball', 'rcobeca' ); ?></label></th>
						<td>
							<select id="rcobeca-seating-ball" name="ball">
								<?php foreach ( self::balls() as $ball ) : ?>
									<option value="<?php echo esc_attr( (string) $ball ); ?>"><?php echo esc_html( get_the_title( $ball ) ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="rcobeca-seating-file"><?php esc_html_e( 'Seating list (CSV file)', 'rcobeca' ); ?></label></th>
						<td><input type="file" id="rcobeca-seating-file" name="seating" accept=".csv,text/csv" required></td>
					</tr>
				</table>
				<?php submit_button( __( 'Upload seating list', 'rcobeca' ) ); ?>
			</form>

			<h2><?php esc_html_e( 'Stored lists', 'rcobeca' ); ?></h2>
			<?php if ( ! $with_list ) : ?>
				<p><?php esc_html_e( 'None.', 'rcobeca' ); ?></p>
			<?php else : ?>
				<table class="widefat striped">
					<thead><tr>
						<th scope="col"><?php esc_html_e( 'Ball', 'rcobeca' ); ?></th>
						<th scope="col"><?php esc_html_e( 'List', 'rcobeca' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Table Lookup', 'rcobeca' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Deleted automatically', 'rcobeca' ); ?></th>
						<th scope="col"><span class="screen-reader-text"><?php esc_html_e( 'Actions', 'rcobeca' ); ?></span></th>
					</tr></thead>
					<tbody>
					<?php
					foreach ( $with_list as $ball ) :
						$summary = (array) Seating::summary( $ball );
						?>
						<tr>
							<th scope="row"><?php echo esc_html( get_the_title( $ball ) ); ?></th>
							<td>
								<?php
								/* translators: 1: guests, 2: tables, 3: date and time. */
								echo esc_html( sprintf( __( '%1$d guests at %2$d tables, uploaded %3$s', 'rcobeca' ), $summary['guests'], $summary['tables'], self::when( $summary['uploaded'] ) ) );
								?>
							</td>
							<td><?php echo Seating::is_open( $ball ) ? esc_html__( 'Open now', 'rcobeca' ) : esc_html__( 'Opens when the Ball page is set to “Ball night”', 'rcobeca' ); ?></td>
							<td><?php echo Seating::expires( $ball ) ? esc_html( self::when( Seating::expires( $ball ) ) ) : esc_html__( 'When the Ball has a date', 'rcobeca' ); ?></td>
							<td>
								<form method="post" action="<?php echo esc_url( $url ); ?>">
									<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
									<input type="hidden" name="do" value="delete">
									<input type="hidden" name="ball" value="<?php echo esc_attr( (string) $ball ); ?>">
									<?php wp_nonce_field( self::ACTION ); ?>
									<button type="submit" class="button button-link-delete">
										<?php
										/* translators: %s: Ball title. */
										echo esc_html( sprintf( __( 'Delete the list for %s now', 'rcobeca' ), get_the_title( $ball ) ) );
										?>
									</button>
								</form>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>

			<h2><?php esc_html_e( 'Automatic deletion', 'rcobeca' ); ?></h2>
			<form method="post" action="<?php echo esc_url( $url ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
				<input type="hidden" name="do" value="keep">
				<?php wp_nonce_field( self::ACTION ); ?>
				<p>
					<label for="rcobeca-seating-keep"><?php esc_html_e( 'Delete each list this many hours after the Ball’s day ends (midnight):', 'rcobeca' ); ?></label>
					<input type="number" min="0" max="720" class="small-text" id="rcobeca-seating-keep" name="keep" value="<?php echo esc_attr( (string) Seating::keep_hours() ); ?>">
				</p>
				<p class="description"><?php esc_html_e( 'The default, 12, deletes it at noon the day after the Ball.', 'rcobeca' ); ?></p>
				<?php submit_button( __( 'Save', 'rcobeca' ), 'secondary' ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Prints the result of the last action.
	 *
	 * @param array $report Report from handle().
	 */
	private static function notices( array $report ): void {
		if ( ! empty( $report['error'] ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html( $report['error'] ) . '</p></div>';
		}
		if ( ! empty( $report['success'] ) ) {
			echo '<div class="notice notice-success"><p>' . esc_html( $report['success'] ) . '</p></div>';
		}
		if ( ! empty( $report['skipped'] ) ) {
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'These rows were left out. Fix them in the spreadsheet and upload it again:', 'rcobeca' ) . '</p><ul>';
			foreach ( $report['skipped'] as $line => $reason ) {
				/* translators: 1: line number, 2: reason. */
				echo '<li>' . esc_html( sprintf( __( 'Line %1$d: %2$s', 'rcobeca' ), $line, $reason ) ) . '</li>';
			}
			echo '</ul></div>';
		}
	}

	/**
	 * Where the last action's report waits for the screen, per user.
	 */
	private static function report_key(): string {
		return 'rcobeca_seating_report_' . get_current_user_id();
	}

	/**
	 * Handles the screen's forms, then returns to it.
	 */
	public static function handle(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to manage seating lists.', 'rcobeca' ), 403 );
		}
		check_admin_referer( self::ACTION );
		$do     = sanitize_key( wp_unslash( $_POST['do'] ?? '' ) );
		$ball   = absint( $_POST['ball'] ?? 0 );
		$title  = $ball ? get_the_title( $ball ) : '';
		$report = array();

		if ( 'keep' === $do ) {
			update_option( Seating::KEEP_OPTION, min( 720, absint( $_POST['keep'] ?? Seating::KEEP_DEFAULT ) ), false );
			$report['success'] = __( 'Saved.', 'rcobeca' );
		} elseif ( ! $ball || ! Events::is_ball( $ball ) ) {
			$report['error'] = __( 'Choose a Ball.', 'rcobeca' );
		} elseif ( 'delete' === $do ) {
			Seating::delete( $ball );
			/* translators: %s: Ball title. */
			$report['success'] = sprintf( __( 'The seating list for %s was deleted.', 'rcobeca' ), $title );
		} else {
			$file = $_FILES['seating']['tmp_name'] ?? ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- a temporary path PHP chose, read only.
			$csv  = is_uploaded_file( $file ) ? (string) file_get_contents( $file ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a local upload.
			$done = '' !== $csv ? Seating::store( $ball, $csv ) : array(
				'guests'  => 0,
				'tables'  => 0,
				'skipped' => array(),
			);
			if ( $done['guests'] ) {
				/* translators: 1: Ball title, 2: guests, 3: tables. */
				$report['success'] = sprintf( __( 'Seating list loaded for %1$s: %2$d guests at %3$d tables.', 'rcobeca' ), $title, $done['guests'], $done['tables'] );
			} else {
				$report['error'] = __( 'No guests were found in that file, so nothing changed. It needs two columns: full name, table.', 'rcobeca' );
			}
			$report['skipped'] = $done['skipped'];
		}

		set_transient( self::report_key(), $report, 5 * MINUTE_IN_SECONDS );
		wp_safe_redirect( admin_url( 'edit.php?post_type=' . Events::POST_TYPE . '&page=' . self::PAGE ) );
		exit;
	}
}

add_action( 'admin_menu', array( Seating_Admin::class, 'admin_menu' ) );
add_action( 'admin_post_' . Seating_Admin::ACTION, array( Seating_Admin::class, 'handle' ) );
