<?php
/**
 * Seating lists for Table Lookup (GLOSSARY: Table Lookup).
 *
 * A volunteer uploads a Ball's seating list as CSV (full name, table). It is
 * kept private: names are never stored as text, only as keyed hashes of the
 * normalised name, in protected post meta on the Ball's Event that no REST
 * route, search, sitemap or page ever reads. A guest's exact full name finds
 * its table; nothing else does.
 *
 * The lookup answers only while the Ball's state is "Ball night", and the
 * list is deleted a configurable number of hours after the Ball's day ends
 * (noon the next day by default): at the first lookup after that, or by the
 * hourly purge, whichever comes first.
 *
 * @package RCOBECA
 */

namespace RCOBECA;

defined( 'ABSPATH' ) || exit;

/**
 * Stores, looks up and purges seating lists.
 */
class Seating {

	/**
	 * Protected (underscore) post meta: never in REST or the Custom Fields box.
	 */
	public const META = '_rcobeca_seating';

	/**
	 * Hours to keep a list after the Ball's day ends.
	 */
	public const KEEP_OPTION = 'rcobeca_seating_keep_hours';

	public const KEEP_DEFAULT = 12;

	public const PURGE_HOOK = 'rcobeca_seating_purge';

	/**
	 * Now, as a timestamp. Tests fake the clock with the rcobeca_seating_now filter.
	 */
	public static function now(): int {
		return (int) apply_filters( 'rcobeca_seating_now', time() );
	}

	/**
	 * The name as compared: diacritics removed, typographic apostrophes made
	 * plain, whitespace collapsed, lower case. Nothing else is forgiven.
	 *
	 * @param string $name A full name.
	 */
	public static function normalise( string $name ): string {
		$name = remove_accents( wp_strip_all_tags( $name ) );
		$name = str_replace( array( '’', '‘', '`', '´' ), "'", $name );
		$name = trim( (string) preg_replace( '/[\s\x{00A0}]+/u', ' ', $name ) );
		return function_exists( 'mb_strtolower' ) ? mb_strtolower( $name, 'UTF-8' ) : strtolower( $name );
	}

	/**
	 * Whether a normalised name is a full name (at least two words).
	 *
	 * @param string $normal Normalised name.
	 */
	public static function is_full_name( string $normal ): bool {
		return str_contains( $normal, ' ' );
	}

	/**
	 * Option holding the site's own random key for the name hashes.
	 */
	public const KEY_OPTION = 'rcobeca_seating_key';

	/**
	 * The stored key for a normalised name.
	 *
	 * @param string $normal Normalised name.
	 */
	private static function key( string $normal ): string {
		return hash_hmac( 'sha256', $normal, self::secret() );
	}

	/**
	 * The key behind the name hashes: random, made on first use and kept in a
	 * non-autoloaded option. Not WordPress's salts, so rotating them (a routine
	 * security step) leaves an uploaded list working.
	 */
	private static function secret(): string {
		$secret = (string) get_option( self::KEY_OPTION, '' );
		if ( '' === $secret ) {
			$secret = bin2hex( random_bytes( 32 ) );
			add_option( self::KEY_OPTION, $secret, '', false );
			$secret = (string) get_option( self::KEY_OPTION, $secret ); // Another request may have made it first.
		}
		return $secret;
	}

	/**
	 * Replaces a Ball's seating list with a CSV of full name, table.
	 *
	 * A header row is optional. Rows without a full name or a table are
	 * skipped and reported; a name listed twice keeps both tables.
	 *
	 * @param int    $ball Ball Event ID.
	 * @param string $csv  The CSV text.
	 * @return array{guests: int, tables: int, skipped: array<int, string>} Skipped: line => reason.
	 */
	public static function store( int $ball, string $csv ): array {
		$list   = self::parse( $csv );
		$report = array(
			'guests'  => count( $list['seats'] ),
			'tables'  => $list['tables'],
			'skipped' => $list['skipped'],
		);
		if ( $list['seats'] ) {
			update_post_meta(
				$ball,
				self::META,
				array(
					'seats'    => $list['seats'],
					'guests'   => $report['guests'],
					'tables'   => $report['tables'],
					'uploaded' => self::now(),
				)
			);
		}
		return $report;
	}

	/**
	 * Reads a seating CSV into keyed seats.
	 *
	 * @param string $csv The CSV text.
	 * @return array{seats: array<string, string>, tables: int, skipped: array<int, string>}
	 */
	private static function parse( string $csv ): array {
		$seats   = array();
		$tables  = array();
		$skipped = array();
		foreach ( self::rows( $csv ) as $line => $row ) {
			$normal = self::normalise( (string) ( $row[0] ?? '' ) );
			$table  = trim( (string) preg_replace( '/^table\s*/i', '', trim( (string) ( $row[1] ?? '' ) ) ) );
			if ( 1 === $line && '' !== $normal && ! preg_match( '/\d/', $table ) && str_contains( $normal, 'name' ) ) {
				continue; // The header row.
			}
			if ( '' === $normal && '' === $table ) {
				continue;
			}
			if ( ! self::is_full_name( $normal ) ) {
				$skipped[ $line ] = __( 'needs a first and last name', 'rcobeca' );
				continue;
			}
			if ( '' === $table ) {
				$skipped[ $line ] = __( 'has no table', 'rcobeca' );
				continue;
			}
			$key = self::key( $normal );
			if ( ! isset( $seats[ $key ] ) ) {
				$seats[ $key ] = array();
			}
			$seats[ $key ][]                = sanitize_text_field( $table );
			$tables[ strtolower( $table ) ] = true;
		}
		return array(
			'seats'   => array_map( static fn( $choices ) => implode( ' or ', array_unique( $choices ) ), $seats ),
			'tables'  => count( $tables ),
			'skipped' => $skipped,
		);
	}

	/**
	 * CSV rows keyed by line number, from UTF-8 or Windows (Excel) text, with
	 * commas, semicolons or tabs.
	 *
	 * @param string $csv The CSV text.
	 * @return array<int, string[]>
	 */
	private static function rows( string $csv ): array {
		$csv = (string) preg_replace( '/^\xEF\xBB\xBF/', '', $csv );
		if ( function_exists( 'mb_check_encoding' ) && ! mb_check_encoding( $csv, 'UTF-8' ) ) {
			$csv = (string) mb_convert_encoding( $csv, 'UTF-8', 'Windows-1252' );
		}
		$first     = strtok( $csv, "\r\n" );
		$delimiter = ',';
		foreach ( array( "\t", ';' ) as $other ) {
			if ( false !== $first && ! str_contains( $first, ',' ) && str_contains( $first, $other ) ) {
				$delimiter = $other;
			}
		}
		$rows = array();
		foreach ( preg_split( '/\r\n|\r|\n/', $csv ) as $index => $text ) {
			if ( '' !== trim( $text ) ) {
				$rows[ $index + 1 ] = str_getcsv( $text, $delimiter, '"', '' );
			}
		}
		return $rows;
	}

	/**
	 * Whether a Ball has a seating list stored.
	 *
	 * @param int $ball Ball Event ID.
	 */
	public static function has_list( int $ball ): bool {
		return ! empty( get_post_meta( $ball, self::META, true )['seats'] );
	}

	/**
	 * What the admin screen shows about a stored list (never the names).
	 *
	 * @param int $ball Ball Event ID.
	 * @return array{guests: int, tables: int, uploaded: int}|null
	 */
	public static function summary( int $ball ): ?array {
		$list = get_post_meta( $ball, self::META, true );
		if ( empty( $list['seats'] ) ) {
			return null;
		}
		return array(
			'guests'   => (int) $list['guests'],
			'tables'   => (int) $list['tables'],
			'uploaded' => (int) $list['uploaded'],
		);
	}

	/**
	 * Deletes a Ball's seating list.
	 *
	 * @param int $ball Ball Event ID.
	 */
	public static function delete( int $ball ): void {
		delete_post_meta( $ball, self::META );
	}

	/**
	 * Hours a list is kept after the Ball's day ends.
	 */
	public static function keep_hours(): int {
		return max( 0, (int) get_option( self::KEEP_OPTION, self::KEEP_DEFAULT ) );
	}

	/**
	 * When a Ball's list expires: midnight at the end of the Ball's day (site
	 * time), plus the hours kept. 0 when the Ball has no date.
	 *
	 * @param int $ball Ball Event ID.
	 */
	public static function expires( int $ball ): int {
		$date = Events::get( $ball, 'date' );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			return 0;
		}
		$end = new \DateTimeImmutable( $date . ' 00:00:00 +1 day', wp_timezone() );
		return $end->getTimestamp() + self::keep_hours() * HOUR_IN_SECONDS;
	}

	/**
	 * Whether a Ball's list has expired.
	 *
	 * @param int $ball Ball Event ID.
	 */
	private static function expired( int $ball ): bool {
		$expires = self::expires( $ball );
		return $expires && self::now() >= $expires;
	}

	/**
	 * Whether the lookup answers for this Ball now: on Ball night (the state
	 * the volunteer set, which also holds after midnight), with a list, before
	 * it expires. An expired list is purged here.
	 *
	 * @param int $ball Ball Event ID.
	 */
	public static function is_open( int $ball ): bool {
		if ( self::expired( $ball ) ) {
			self::delete( $ball );
			return false;
		}
		return 'ball-night' === Events::get( $ball, 'ball_state' ) && self::has_list( $ball );
	}

	/**
	 * Looks up a guest's table by exact full name.
	 *
	 * @param int    $ball Ball Event ID.
	 * @param string $name What the guest typed.
	 * @return array{status: string, table?: string} Status: found (with table),
	 *     not-found, full-name (empty or one word) or closed.
	 */
	public static function lookup( int $ball, string $name ): array {
		if ( ! self::is_open( $ball ) ) {
			return array( 'status' => 'closed' );
		}
		return self::find( $name, static fn() => get_post_meta( $ball, self::META, true )['seats'] );
	}

	/**
	 * Looks up a name in the made-up demo list (data/seating-demo.csv), for the
	 * style guide and the public preview. Always open; never a real list.
	 *
	 * @param string $name What the visitor typed.
	 * @return array{status: string, table?: string} As lookup().
	 */
	public static function demo_lookup( string $name ): array {
		return self::find( $name, static fn() => self::parse( (string) file_get_contents( RCOBECA_DIR . '/data/seating-demo.csv' ) )['seats'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a plugin file.
	}

	/**
	 * The answer for a name in a list: found (with its table), not-found, or
	 * full-name when it isn't a full name (the list is then never read).
	 *
	 * @param string   $name  What the guest typed.
	 * @param callable $seats Returns the list: name hash => table.
	 * @return array{status: string, table?: string}
	 */
	private static function find( string $name, callable $seats ): array {
		$normal = self::normalise( $name );
		if ( ! self::is_full_name( $normal ) ) {
			return array( 'status' => 'full-name' );
		}
		$table = $seats()[ self::key( $normal ) ] ?? null;
		return null === $table
			? array( 'status' => 'not-found' )
			: array(
				'status' => 'found',
				'table'  => (string) $table,
			);
	}

	/**
	 * Deletes every expired list. Runs hourly.
	 */
	public static function purge_expired(): void {
		$balls = get_posts(
			array(
				'post_type'      => Events::POST_TYPE,
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_key'       => self::META, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			)
		);
		foreach ( $balls as $ball ) {
			if ( self::expired( (int) $ball ) ) {
				self::delete( (int) $ball );
			}
		}
	}

	/**
	 * Schedules the hourly purge.
	 */
	public static function schedule(): void {
		if ( ! wp_next_scheduled( self::PURGE_HOOK ) ) {
			wp_schedule_event( time(), 'hourly', self::PURGE_HOOK );
		}
	}
}

add_action( Seating::PURGE_HOOK, array( Seating::class, 'purge_expired' ) );
add_action( 'init', array( Seating::class, 'schedule' ) );
