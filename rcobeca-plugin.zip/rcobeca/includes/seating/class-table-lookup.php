<?php
/**
 * Table Lookup's public side (GLOSSARY: Table Lookup): the answer a guest
 * gets, the rate limit, and the endpoint the rcobeca/table-lookup block calls
 * (POST /wp-json/rcobeca/v1/table-lookup with ball and name). Without
 * JavaScript the block's form posts to its own page and gets the same answer.
 *
 * An answer is a table number or a polite message; never a list, a partial
 * match or a hint about who else is coming.
 *
 * @package RCOBECA
 */

namespace RCOBECA;

defined( 'ABSPATH' ) || exit;

/**
 * Answers lookups, within a per-address and a per-name rate limit.
 */
class Table_Lookup {

	/**
	 * The guest's answer.
	 *
	 * @param int    $ball   Ball Event ID (0: the current Ball).
	 * @param string $name   What the guest typed.
	 * @param string $client Who is asking, for the rate limit.
	 * @param bool   $demo   Look up the made-up demo list instead (style guide).
	 * @return array{status: string, message: string, table?: string} Status:
	 *     found, not-found, full-name, closed or rate-limited.
	 */
	public static function answer( int $ball, string $name, string $client, bool $demo = false ): array {
		$ball   = $ball ? $ball : Events::current_ball();
		$result = array( 'status' => 'full-name' );
		if ( '' !== Seating::normalise( $name ) ) {
			if ( ! self::within_rate_limit( $client, $name ) ) {
				$result = array( 'status' => 'rate-limited' );
			} else {
				$result = $demo ? Seating::demo_lookup( $name ) : Seating::lookup( $ball, $name );
			}
		} elseif ( ! $demo && ! Seating::is_open( $ball ) ) {
			$result = array( 'status' => 'closed' );
		}
		return array( 'message' => self::messages()[ $result['status'] ] ) + $result;
	}

	/**
	 * What each answer says.
	 *
	 * @return array<string, string>
	 */
	public static function messages(): array {
		return array(
			'found'        => __( 'Enjoy the evening!', 'rcobeca' ),
			'not-found'    => __( 'We couldn’t find that name. Check the spelling, or please see the welcome desk.', 'rcobeca' ),
			'full-name'    => __( 'Please type your first and last name, as on your ticket.', 'rcobeca' ),
			'closed'       => __( 'Table Lookup isn’t open right now. Please see the welcome desk.', 'rcobeca' ),
			'rate-limited' => __( 'Too many tries from this device. Please wait a few minutes, or see the welcome desk.', 'rcobeca' ),
		);
	}

	/**
	 * Who is asking: the visitor's address (Rate_Limit::client_ip()). Local
	 * development tells test visitors apart through the
	 * rcobeca_table_lookup_client filter.
	 */
	public static function client(): string {
		return (string) apply_filters( 'rcobeca_table_lookup_client', Rate_Limit::client_ip() );
	}

	/**
	 * Allows this lookup, and counts it, unless it is over either limit.
	 *
	 * A ballroom of guests on the venue's Wi-Fi (or behind a CDN) shares one
	 * address, so the per-address ceiling (600 in 10 minutes) is sized for a
	 * few hundred guests each trying a couple of times. What stops someone
	 * retrying one name is the tight per-name limit: 10 lookups of the same
	 * normalised name from one address in 10 minutes.
	 *
	 * @param string $client Visitor key.
	 * @param string $name   What the guest typed.
	 */
	private static function within_rate_limit( string $client, string $name ): bool {
		/**
		 * Filters how many lookups one address may make in a window.
		 *
		 * @param array{max: int, window: int} $limit Lookups, and window in seconds.
		 */
		$address = apply_filters(
			'rcobeca_table_lookup_rate_limit',
			array(
				'max'    => 600,
				'window' => 10 * MINUTE_IN_SECONDS,
			)
		);
		/**
		 * Filters how many times one address may look up the same name in a window.
		 *
		 * @param array{max: int, window: int} $limit Lookups, and window in seconds.
		 */
		$same_name = apply_filters(
			'rcobeca_table_lookup_name_rate_limit',
			array(
				'max'    => 10,
				'window' => 10 * MINUTE_IN_SECONDS,
			)
		);
		return Rate_Limit::allow( 'lookup', $client, $address )
			&& Rate_Limit::allow( 'lookup_name', $client . "\n" . Seating::normalise( $name ), $same_name );
	}

	/**
	 * Registers POST /rcobeca/v1/table-lookup.
	 */
	public static function register_route(): void {
		register_rest_route(
			'rcobeca/v1',
			'/table-lookup',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'args'                => array(
					'ball' => array(
						'type'    => 'integer',
						'default' => 0,
						'minimum' => 0,
					),
					'name' => array(
						'type'      => 'string',
						'default'   => '',
						'maxLength' => 200,
					),
					'demo' => array(
						'type'    => 'boolean',
						'default' => false,
					),
				),
				'callback'            => static function ( \WP_REST_Request $request ) {
					$answer   = self::answer( (int) $request['ball'], (string) $request['name'], self::client(), (bool) $request['demo'] );
					$response = new \WP_REST_Response( $answer, 'rate-limited' === $answer['status'] ? 429 : 200 );
					$response->header( 'Cache-Control', 'no-store' );
					return $response;
				},
			)
		);
	}

	/**
	 * Keeps pages built around the lookup (/table/) out of search engines.
	 *
	 * @param array $robots Robots directives.
	 */
	public static function robots( array $robots ): array {
		if ( is_singular() && has_block( 'rcobeca/table-lookup', get_queried_object() ) ) {
			$robots['noindex'] = true;
			$robots['follow']  = true;
		}
		return $robots;
	}
}

add_action( 'rest_api_init', array( Table_Lookup::class, 'register_route' ) );
add_filter( 'wp_robots', array( Table_Lookup::class, 'robots' ) );
