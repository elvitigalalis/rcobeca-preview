<?php
/**
 * Search and sharing: the meta description, Open Graph and Twitter cards
 * (with a fallback image), the XML sitemap's contents and schema.org data
 * (NonprofitOrganization on the home page, Event on Event pages,
 * BreadcrumbList below the home page). WordPress prints the title, canonical
 * link, robots tag and sitemap itself; this file fills in the rest.
 *
 * Descriptions: a page's Excerpt when it has one (editors set it in the
 * Excerpt panel), else its first real paragraph, else a sentence built from
 * its record. Every page's description is different.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

use RCOBECA\Events;

/** The shared card for pages without a photo of their own (1200 × 630). */
const RCOBECA_SOCIAL_CARD = 'assets/social-card.jpg';

/**
 * Pages get an Excerpt panel: it is their meta description.
 */
function rcobeca_page_excerpts(): void {
	add_post_type_support( 'page', 'excerpt' );
}
add_action( 'init', 'rcobeca_page_excerpts' );

/**
 * Plain text, whitespace collapsed, cut to about 155 characters at a word.
 *
 * @param string $text Text or HTML.
 * @param int    $max  Longest result.
 */
function rcobeca_seo_trim( string $text, int $max = 155 ): string {
	$text = html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	$text = trim( (string) preg_replace( '/\s+/u', ' ', $text ) );
	if ( mb_strlen( $text ) <= $max ) {
		return $text;
	}
	$cut = mb_substr( $text, 0, $max );
	$cut = (string) preg_replace( '/\s+\S*$/u', '', $cut );
	return rtrim( $cut, ' ,;:–—-' ) . '…';
}

/**
 * The first paragraph of a post's own words that is long enough to describe
 * it: no kickers or captions, and nothing a block renders.
 *
 * @param string $content Post content.
 */
function rcobeca_seo_first_paragraph( string $content ): string {
	$walk = static function ( array $blocks ) use ( &$walk ): string {
		foreach ( $blocks as $block ) {
			if ( 'core/paragraph' === $block['blockName'] ) {
				$class = (string) ( $block['attrs']['className'] ?? '' );
				if ( preg_match( '/is-style-kicker|has-small-font-size/', $class . $block['innerHTML'] ) ) {
					continue;
				}
				$text = rcobeca_seo_trim( $block['innerHTML'], 1000 );
				if ( mb_strlen( $text ) >= 60 ) {
					return $text;
				}
			}
			if ( ! empty( $block['innerBlocks'] ) && ! str_starts_with( (string) $block['blockName'], 'core/quote' ) ) {
				$found = $walk( $block['innerBlocks'] );
				if ( '' !== $found ) {
					return $found;
				}
			}
		}
		return '';
	};
	return $walk( parse_blocks( $content ) );
}

/**
 * A sentence about a record that has no words of its own to quote.
 *
 * @param WP_Post $post Post.
 */
function rcobeca_seo_record_sentence( WP_Post $post ): string {
	$title = get_the_title( $post );
	switch ( $post->post_type ) {
		case 'rcobeca_event':
			$parts = array_filter( array( Events::date_label( $post->ID ), Events::get( $post->ID, 'venue' ) ) );
			/* translators: 1: Event title, 2: date and venue. */
			return sprintf( __( '%1$s, an RCOBECA event: %2$s.', 'rcobeca' ), $title, implode( ', ', $parts ) );
		case 'rcobeca_person':
			$summary = function_exists( 'rcobeca_person_summary' ) ? rcobeca_person_summary( $post->ID ) : '';
			/* translators: 1: name, 2: service summary. */
			return sprintf( __( '%1$s, Royal College old boy: %2$s', 'rcobeca' ), $title, $summary ? $summary : __( 'his service to RCOBECA.', 'rcobeca' ) );
		default:
			/* translators: %s: page title. */
			return sprintf( __( '%s, from RCOBECA, the Royal College Old Boys’ East Coast Association in the New York tri-state area.', 'rcobeca' ), $title );
	}
}

/**
 * The meta description for the current request.
 */
function rcobeca_meta_description(): string {
	if ( is_search() ) {
		/* translators: %s: search terms. */
		return rcobeca_seo_trim( sprintf( __( 'Search results for “%s” on the RCOBECA website: Projects, Events, people and pages.', 'rcobeca' ), get_search_query( false ) ) );
	}
	if ( is_404() ) {
		return __( 'This page is not on the RCOBECA website. Search the site or start from the home page.', 'rcobeca' );
	}
	if ( is_post_type_archive( 'rcobeca_project' ) ) {
		$text = __( 'Every RCOBECA Project since 2002: classrooms, labs, scholarships and sport at Royal College, relief in Sri Lanka and causes in the US. Filter by status and beneficiary.', 'rcobeca' );
	} elseif ( is_singular() ) {
		$post = get_queried_object();
		$text = has_excerpt( $post ) ? $post->post_excerpt : rcobeca_seo_first_paragraph( $post->post_content );
		if ( '' === $text ) {
			$text = rcobeca_seo_record_sentence( $post );
		}
		$text = rcobeca_seo_dated( $post, rcobeca_seo_trim( $text, 1000 ) );
	} else {
		$text = get_bloginfo( 'description' );
	}
	$text = rcobeca_seo_trim( $text );
	$page = max( (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) );
	if ( $page > 1 ) {
		/* translators: 1: description, 2: page number. */
		$text = rcobeca_seo_trim( $text, 140 ) . ' ' . sprintf( __( 'Page %d.', 'rcobeca' ), $page );
	}
	return $text;
}

/**
 * A Project's or Event's description opens with its date unless it already
 * names the year, so yearly ones (a scholarship given twice, an AGM held
 * every year) read differently.
 *
 * @param WP_Post $post Post.
 * @param string  $text Description.
 */
function rcobeca_seo_dated( WP_Post $post, string $text ): string {
	$date = '';
	if ( 'rcobeca_event' === $post->post_type ) {
		$date = Events::date_label( $post->ID );
	} elseif ( 'rcobeca_project' === $post->post_type ) {
		$date = rcobeca_project_date_label( (string) get_post_meta( $post->ID, 'rcobeca_date', true ) );
	}
	if ( '' === $date || ! preg_match( '/\d{4}/', $date, $year ) || str_contains( $text, $year[0] ) ) {
		return $text;
	}
	return $date . ': ' . $text;
}

/**
 * The address this page is known by: WordPress's canonical URL, or the
 * listing's own address.
 */
function rcobeca_seo_url(): string {
	if ( is_singular() ) {
		$url = wp_get_canonical_url();
		if ( $url ) {
			return $url;
		}
	}
	if ( is_post_type_archive() ) {
		$page = (int) get_query_var( 'paged' );
		$url  = (string) get_post_type_archive_link( (string) get_query_var( 'post_type' ) );
		return $page > 1 ? trailingslashit( $url ) . user_trailingslashit( 'page/' . $page ) : $url;
	}
	if ( is_front_page() ) {
		return home_url( '/' );
	}
	global $wp;
	return home_url( user_trailingslashit( (string) $wp->request ) );
}

/**
 * The image a share shows: the page's featured photo, or the RCOBECA card.
 *
 * @return array{url: string, width: int, height: int, alt: string}
 */
function rcobeca_seo_image(): array {
	$id = is_singular() ? (int) get_post_thumbnail_id( get_queried_object_id() ) : 0;
	if ( $id ) {
		$src = wp_get_attachment_image_src( $id, 'full' );
		if ( $src ) {
			return array(
				'url'    => $src[0],
				'width'  => (int) $src[1],
				'height' => (int) $src[2],
				'alt'    => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
			);
		}
	}
	return array(
		'url'    => plugins_url( RCOBECA_SOCIAL_CARD, RCOBECA_DIR . '/rcobeca.php' ),
		'width'  => 1200,
		'height' => 630,
		'alt'    => __( 'The Royal College crest in gold on royal blue, with the RCOBECA name', 'rcobeca' ),
	);
}

/**
 * Prints the description, Open Graph and Twitter tags.
 */
function rcobeca_seo_head(): void {
	$description = rcobeca_meta_description();
	$image       = rcobeca_seo_image();
	$type        = is_singular( array( 'rcobeca_project', 'rcobeca_event' ) ) ? 'article' : ( is_singular( 'rcobeca_person' ) ? 'profile' : 'website' );
	$tags        = array(
		'name="description"'         => $description,
		'property="og:site_name"'    => get_bloginfo( 'name' ),
		'property="og:type"'         => $type,
		'property="og:title"'        => wp_get_document_title(),
		'property="og:description"'  => $description,
		'property="og:url"'          => rcobeca_seo_url(),
		'property="og:image"'        => $image['url'],
		'property="og:image:width"'  => (string) $image['width'],
		'property="og:image:height"' => (string) $image['height'],
		'property="og:image:alt"'    => $image['alt'],
		'property="og:locale"'       => 'en_US',
		'name="twitter:card"'        => 'summary_large_image',
	);
	foreach ( $tags as $key => $content ) {
		if ( '' !== $content ) {
			printf( "<meta %s content=\"%s\" />\n", $key, esc_attr( $content ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $key is a literal above.
		}
	}
	if ( is_post_type_archive() ) {
		printf( "<link rel=\"canonical\" href=\"%s\" />\n", esc_url( rcobeca_seo_url() ) );
	}
	foreach ( rcobeca_structured_data() as $data ) {
		echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ) . "</script>\n";
	}
}
add_action( 'wp_head', 'rcobeca_seo_head', 2 );

/**
 * RCOBECA as schema.org describes it.
 */
function rcobeca_organization_data(): array {
	return array(
		'@type'           => 'NonprofitOrganization',
		'@id'             => home_url( '/#organization' ),
		'name'            => 'RCOBECA',
		'alternateName'   => 'Royal College Old Boys’ East Coast Association',
		'legalName'       => 'RCOBEC Foundation Inc.',
		'nonprofitStatus' => 'Nonprofit501c3',
		'taxID'           => '81-4203477',
		'foundingDate'    => '1993',
		'url'             => home_url( '/' ),
		'logo'            => plugins_url( 'assets/crest.png', RCOBECA_DIR . '/rcobeca.php' ),
		'email'           => 'secretary@rcobeca.org',
		'sameAs'          => array(
			'https://www.facebook.com/rcobecf',
			'https://www.instagram.com/rcobeca/',
			'https://x.com/rcobeca',
			'https://www.linkedin.com/groups/2417585/',
			'https://www.youtube.com/@rcobeca',
		),
	);
}

/**
 * The breadcrumb trail to the current page, home first: [name, url] pairs.
 *
 * @return array<int, array{0: string, 1: string}>
 */
function rcobeca_breadcrumbs(): array {
	if ( is_front_page() || is_search() || is_404() ) {
		return array();
	}
	$page  = static function ( string $path ): array {
		$found = get_page_by_path( $path );
		return $found ? array( get_the_title( $found ), get_permalink( $found ) ) : array();
	};
	$trail = array( array( __( 'Home', 'rcobeca' ), home_url( '/' ) ) );
	if ( is_post_type_archive( 'rcobeca_project' ) ) {
		$trail[] = array( __( 'Projects', 'rcobeca' ), rcobeca_seo_url() );
		return $trail;
	}
	if ( ! is_singular() ) {
		return array();
	}
	$post = get_queried_object();
	switch ( $post->post_type ) {
		case 'page':
			foreach ( array_reverse( get_post_ancestors( $post ) ) as $ancestor ) {
				$trail[] = array( get_the_title( $ancestor ), get_permalink( $ancestor ) );
			}
			break;
		case 'rcobeca_project':
			$trail[] = array( __( 'Projects', 'rcobeca' ), (string) get_post_type_archive_link( 'rcobeca_project' ) );
			break;
		case 'rcobeca_event':
			$trail = array_merge( $trail, Events::is_ball( $post->ID ) ? array_filter( array( $page( 'ball' ), $page( 'ball/past' ) ) ) : array_filter( array( $page( 'events' ) ) ) );
			break;
		case 'rcobeca_person':
			$trail = array_merge( $trail, array_filter( array( $page( 'committee' ) ) ) );
			break;
	}
	$trail[] = array( get_the_title( $post ), rcobeca_seo_url() );
	return $trail;
}

/**
 * Event data (schema.org) for an Event with a known day and venue.
 *
 * @param int $id Event ID.
 */
function rcobeca_event_data( int $id ): array {
	$date  = Events::get( $id, 'date' );
	$venue = Events::get( $id, 'venue' );
	if ( 'day' !== ( Events::get( $id, 'date_precision' ) ? Events::get( $id, 'date_precision' ) : 'day' ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) || '' === $venue ) {
		return array();
	}
	$start = $date;
	if ( preg_match( '/^(\d{1,2})(?::(\d{2}))?\s*([AP])\.?M/i', Events::get( $id, 'time' ), $m ) ) {
		$hour  = ( (int) $m[1] % 12 ) + ( 'P' === strtoupper( $m[3] ) ? 12 : 0 );
		$start = ( new DateTimeImmutable( sprintf( '%s %02d:%02d', $date, $hour, (int) ( $m[2] ?? 0 ) ), wp_timezone() ) )->format( 'c' );
	}
	$address = Events::get( $id, 'address' );
	$data    = array(
		'@type'               => 'Event',
		'name'                => get_the_title( $id ),
		'startDate'           => $start,
		'eventStatus'         => 'https://schema.org/EventScheduled',
		'eventAttendanceMode' => 'https://schema.org/OfflineEventAttendanceMode',
		'location'            => array(
			'@type'   => 'Place',
			'name'    => $venue,
			'address' => '' !== $address ? $address : $venue,
		),
		'organizer'           => array(
			'@type' => 'Organization',
			'name'  => 'RCOBECA',
			'url'   => home_url( '/' ),
		),
		'image'               => array( rcobeca_seo_image()['url'] ),
		'description'         => rcobeca_meta_description(),
		'url'                 => get_permalink( $id ),
	);
	$tickets = Events::get( $id, 'ticket_url' );
	if ( '' !== $tickets && Events::is_upcoming( $id ) ) {
		$data['offers'] = array(
			'@type'        => 'Offer',
			'url'          => $tickets,
			'availability' => 'https://schema.org/InStock',
		);
	}
	return $data;
}

/**
 * The JSON-LD documents for the current page.
 *
 * @return array<int, array>
 */
function rcobeca_structured_data(): array {
	$graph = array();
	if ( is_front_page() ) {
		$graph[] = rcobeca_organization_data();
	}
	// Event schema only for Events still to come: a past Event is history, not a listing.
	if ( is_singular( 'rcobeca_event' ) ) {
		if ( Events::is_upcoming( get_queried_object_id() ) ) {
			$graph[] = rcobeca_event_data( get_queried_object_id() );
		}
	} elseif ( is_page( 'ball' ) ) {
		$ball = Events::current_ball();
		if ( $ball && Events::is_upcoming( $ball ) ) {
			$graph[] = rcobeca_event_data( $ball );
		}
	}
	$crumbs = rcobeca_breadcrumbs();
	if ( count( $crumbs ) > 1 ) {
		$items = array();
		foreach ( array_values( $crumbs ) as $n => [ $name, $url ] ) {
			$items[] = array(
				'@type'    => 'ListItem',
				'position' => $n + 1,
				'name'     => html_entity_decode( $name, ENT_QUOTES, 'UTF-8' ),
				'item'     => $url,
			);
		}
		$graph[] = array(
			'@type'           => 'BreadcrumbList',
			'itemListElement' => $items,
		);
	}
	$graph = array_values( array_filter( $graph ) );
	return array_map( static fn( $node ) => array( '@context' => 'https://schema.org' ) + $node, $graph );
}

/**
 * The sitemap lists pages people should find: no author archives (there are
 * no authors), no builder or noindex pages.
 *
 * @param WP_Sitemaps_Provider $provider Provider.
 * @param string               $name     Provider name.
 * @return WP_Sitemaps_Provider|false
 */
function rcobeca_sitemap_providers( $provider, string $name ) {
	return in_array( $name, array( 'users', 'taxonomies' ), true ) ? false : $provider;
}
add_filter( 'wp_sitemaps_add_provider', 'rcobeca_sitemap_providers', 10, 2 );

/**
 * RCOBECA publishes no blog posts: WordPress's own "Hello world!" stays out.
 *
 * @param array $post_types Post types in the sitemap.
 */
function rcobeca_sitemap_post_types( array $post_types ): array {
	unset( $post_types['post'] );
	return $post_types;
}
add_filter( 'wp_sitemaps_post_types', 'rcobeca_sitemap_post_types' );

/**
 * Listings that are not pages: the Projects listing.
 */
function rcobeca_sitemap_listings(): void {
	if ( ! class_exists( 'WP_Sitemaps_Provider' ) ) {
		return;
	}
	$provider = new class() extends WP_Sitemaps_Provider {
		/** Sets the provider's name. */
		public function __construct() {
			$this->name        = 'listings';
			$this->object_type = 'listing';
		}

		/**
		 * The listing URLs.
		 *
		 * @param int    $page_num Page.
		 * @param string $object_subtype Unused.
		 */
		public function get_url_list( $page_num, $object_subtype = '' ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- the parent's signature.
			return 1 === (int) $page_num ? array( array( 'loc' => (string) get_post_type_archive_link( 'rcobeca_project' ) ) ) : array();
		}

		/**
		 * One page of URLs.
		 *
		 * @param string $object_subtype Unused.
		 */
		public function get_max_num_pages( $object_subtype = '' ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- the parent's signature.
			return 1;
		}
	};
	wp_register_sitemap_provider( 'listings', $provider );
}
add_action( 'init', 'rcobeca_sitemap_listings' );

/**
 * Pages that are not for search engines (the style guide, the Table Lookup
 * page, WordPress's sample page) and Balls without a page stay out of the
 * sitemap.
 *
 * @param array  $args      Query arguments.
 * @param string $post_type Post type.
 */
function rcobeca_sitemap_exclusions( array $args, string $post_type ): array {
	$hidden = array();
	if ( 'page' === $post_type ) {
		foreach ( array( 'style-guide', 'table', 'sample-page' ) as $path ) {
			$page = get_page_by_path( $path );
			if ( $page ) {
				$hidden[] = $page->ID;
			}
		}
	}
	if ( 'rcobeca_event' === $post_type ) {
		$ids    = get_posts(
			array(
				'post_type'      => 'rcobeca_event',
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);
		$hidden = array_values( array_filter( $ids, static fn( $id ) => ! Events::has_page( $id ) ) );
	}
	if ( $hidden ) {
		$args['post__not_in'] = array_merge( $args['post__not_in'] ?? array(), $hidden );
	}
	return $args;
}
add_filter( 'wp_sitemaps_posts_query_args', 'rcobeca_sitemap_exclusions', 10, 2 );

/**
 * Missing pages and WordPress's sample page are not RCOBECA content: keep
 * them out of search engines (WordPress already does so for search results).
 *
 * @param array $robots Robots directives.
 */
function rcobeca_noindex_robots( array $robots ): array {
	if ( is_404() || is_page( 'sample-page' ) ) {
		$robots['noindex'] = true;
	}
	return $robots;
}
add_filter( 'wp_robots', 'rcobeca_noindex_robots' );
