<?php
/**
 * Stories: the Project and Event records News is made of. A story is a
 * published Project, or a past Event with a page of its own (a Ball known only
 * from a line of history is a Past Balls row, not a story). Dated by when it
 * happened: a Project by its publish date (the old post's date), an Event by
 * its date.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

use RCOBECA\Events;

/**
 * Every story, newest first.
 *
 * @return int[] Post IDs.
 */
function rcobeca_stories(): array {
	$dates = array();
	foreach ( get_posts(
		array(
			'post_type'      => RCOBECA_PROJECT,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
		)
	) as $id ) {
		$dates[ $id ] = rcobeca_story_date( $id );
	}
	foreach ( Events::query() as $id ) {
		if ( ! Events::is_upcoming( $id ) && Events::has_page( $id ) ) {
			$dates[ $id ] = rcobeca_story_date( $id );
		}
	}
	uksort( $dates, static fn( $a, $b ) => array( $dates[ $b ], $b ) <=> array( $dates[ $a ], $a ) );
	return array_keys( $dates );
}

/**
 * A story's date, YYYY-MM-DD.
 *
 * @param int $id Project or Event ID.
 */
function rcobeca_story_date( int $id ): string {
	return Events::POST_TYPE === get_post_type( $id ) ? Events::get( $id, 'date' ) : (string) get_the_date( 'Y-m-d', $id );
}

/**
 * A story's date as visitors read it: "Dec 6, 2025", or "2010" when only the
 * year of an Event is known.
 *
 * @param int $id Project or Event ID.
 */
function rcobeca_story_date_label( int $id ): string {
	return Events::POST_TYPE === get_post_type( $id ) ? Events::short_date( $id ) : (string) get_the_date( 'M j, Y', $id );
}

/**
 * The label above a story's title: "30th Royal Charity Ball", "Cricket
 * Festival", or "Project · Royal College".
 *
 * @param int $id Project or Event ID.
 */
function rcobeca_story_kicker( int $id ): string {
	if ( Events::POST_TYPE === get_post_type( $id ) ) {
		return Events::kicker( $id );
	}
	$for = rcobeca_project_beneficiaries()[ (string) get_post_meta( $id, 'rcobeca_beneficiary', true ) ] ?? '';
	return implode( ' · ', array_filter( array( __( 'Project', 'rcobeca' ), $for ) ) );
}

/**
 * A story's excerpt: its own, else the opening words of its story.
 *
 * @param int $id Project or Event ID.
 * @param int $words Length.
 */
function rcobeca_story_excerpt( int $id, int $words = 30 ): string {
	if ( has_excerpt( $id ) ) {
		return wp_strip_all_tags( get_the_excerpt( $id ) );
	}
	$content = (string) get_post_field( 'post_content', $id );

	// Photos, headings and link lists ("Photos · Video") make poor opening words.
	$content = (string) preg_replace( '#<(figure|h[1-6]|ul|ol)\b[^>]*>.*?</\1>#s', ' ', $content );
	$text    = html_entity_decode( wp_strip_all_tags( strip_shortcodes( $content ) ), ENT_QUOTES, 'UTF-8' );
	return wp_trim_words( trim( (string) preg_replace( '/\s+/', ' ', $text ) ), $words );
}

/**
 * Records shown in full on the current page, so a later listing on the same
 * page (the home page's News after its Projects) doesn't repeat them.
 *
 * @param int[] $ids IDs just shown; omit to read.
 * @return int[] Every ID shown so far.
 */
function rcobeca_shown( array $ids = array() ): array {
	static $shown = array();
	$shown        = array_values( array_unique( array_merge( $shown, array_map( 'intval', $ids ) ) ) );
	return $shown;
}

/**
 * News's pages: 12 stories each.
 */
function rcobeca_news_pages(): int {
	return max( 1, (int) ceil( count( rcobeca_stories() ) / 12 ) );
}

/**
 * Whether a query is a numbered page of News (/news/2/) that has stories.
 *
 * @param WP_Query $query Query.
 */
function rcobeca_is_news_page( WP_Query $query ): bool {
	$page = (int) $query->get( 'page' );
	return $query->is_page() && $page > 1 && has_block( 'rcobeca/news-list', $query->get_queried_object_id() ) && $page <= rcobeca_news_pages();
}

/**
 * Serves News's numbered pages: WordPress would treat /news/2/ of a page
 * without page breaks as not found, then redirect it to /news/.
 *
 * @param bool     $preempt Whether another filter handled the request.
 * @param WP_Query $query Main query.
 */
function rcobeca_serve_news_pages( bool $preempt, WP_Query $query ): bool {
	return $preempt || rcobeca_is_news_page( $query );
}
add_filter( 'pre_handle_404', 'rcobeca_serve_news_pages', 10, 2 );

/**
 * Keeps a numbered News page at its own address.
 *
 * @param string|false $redirect Where WordPress would redirect.
 * @return string|false
 */
function rcobeca_keep_news_pages( $redirect ) {
	global $wp_query;
	return rcobeca_is_news_page( $wp_query ) ? false : $redirect;
}
add_filter( 'redirect_canonical', 'rcobeca_keep_news_pages' );
