<?php
/**
 * Zeffy embeds: turns any Zeffy form link into its embed URL and knows how
 * tall each kind of form is (Zeffy iframes cannot resize themselves).
 * Used by the rcobeca/zeffy-card block. ADR 0002: all payments go through Zeffy.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

/**
 * The kinds of Zeffy form we embed, keyed by the type segment of Zeffy's URL.
 *
 * @return array<string, array{noun: string, heading: string, height: int}>
 */
function rcobeca_zeffy_form_types(): array {
	return array(
		'donation-form' => array(
			'noun'    => __( 'donation form', 'rcobeca' ),
			'heading' => __( 'Make a gift', 'rcobeca' ),
			'height'  => 1150,
		),
		'membership'    => array(
			'noun'    => __( 'membership form', 'rcobeca' ),
			'heading' => __( 'Join or renew', 'rcobeca' ),
			'height'  => 1150,
		),
		'ticketing'     => array(
			'noun'    => __( 'ticket form', 'rcobeca' ),
			'heading' => __( 'Buy tickets', 'rcobeca' ),
			'height'  => 1250,
		),
		'peer-to-peer'  => array(
			'noun'    => __( 'fundraising form', 'rcobeca' ),
			'heading' => __( 'Support this fundraiser', 'rcobeca' ),
			'height'  => 1150,
		),
	);
}

/**
 * RCOBEC Foundation's charity status, as every giving card states it (inline HTML).
 */
function rcobeca_charity_status_html(): string {
	return '<strong>RCOBEC Foundation Inc.</strong> ' . esc_html__( 'is a 501(c)(3) public charity, EIN 81-4203477.', 'rcobeca' );
}

/**
 * The one check every Zeffy link passes (forms, organisation pages and the
 * Join and newsletter settings): an https link on zeffy.com. Gives its path
 * as Zeffy's optional locale ("en-US/") and the segments after it.
 *
 * @param string $url Link copied from Zeffy.
 * @return array{locale: string, segments: string[]}|null Null when it is not a Zeffy link.
 */
function rcobeca_zeffy_link( string $url ): ?array {
	$parts = wp_parse_url( trim( $url ) );
	if ( ! is_array( $parts ) || 'https' !== strtolower( $parts['scheme'] ?? '' ) || ! in_array( strtolower( $parts['host'] ?? '' ), array( 'zeffy.com', 'www.zeffy.com' ), true ) ) {
		return null;
	}
	$segments = array_values( array_filter( explode( '/', $parts['path'] ?? '' ), 'strlen' ) );
	$locale   = isset( $segments[0] ) && preg_match( '/^[a-z]{2}(-[A-Za-z]{2})?$/', $segments[0] ) ? array_shift( $segments ) . '/' : '';
	return array(
		'locale'   => $locale,
		'segments' => $segments,
	);
}

/**
 * Parses a Zeffy form link, whether the share link, the embed link or a
 * modal link: https://www.zeffy.com/[locale/][embed/]<type>/<slug>.
 *
 * @param string $url Link copied from Zeffy.
 * @return array{type: string, embed: string}|null Null when it is not a Zeffy form link.
 */
function rcobeca_zeffy_form( string $url ): ?array {
	$link = rcobeca_zeffy_link( $url );
	if ( null === $link ) {
		return null;
	}
	$segments = $link['segments'];
	if ( isset( $segments[0] ) && 'embed' === $segments[0] ) {
		array_shift( $segments );
	}
	if ( count( $segments ) !== 2 || 'organizations' === $segments[0] || ! preg_match( '/^[a-z-]+$/', $segments[0] ) || ! preg_match( '/^[A-Za-z0-9_-]+$/', $segments[1] ) ) {
		return null;
	}
	return array(
		'type'  => $segments[0],
		'embed' => 'https://www.zeffy.com/' . $link['locale'] . 'embed/' . $segments[0] . '/' . $segments[1],
	);
}

/**
 * Whether a link is an organisation's page on Zeffy
 * (https://www.zeffy.com/[locale/]organizations/<slug>), which lists its
 * forms but cannot be embedded. The Zeffy card links out to it instead.
 *
 * @param string $url Link.
 */
function rcobeca_zeffy_organization( string $url ): bool {
	$segments = rcobeca_zeffy_link( $url )['segments'] ?? array();
	return 2 === count( $segments ) && 'organizations' === $segments[0] && (bool) preg_match( '/^[A-Za-z0-9_-]+$/', $segments[1] );
}
