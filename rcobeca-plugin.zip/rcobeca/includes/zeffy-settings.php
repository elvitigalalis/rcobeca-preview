<?php
/**
 * Settings → Zeffy sync: the Zeffy API key and webhook signing secret, the
 * webhook URL to give Zeffy, how each linked Project last synced, and a
 * "Sync now" button. The key and secret are write-only here (never printed
 * back, never in the REST API); ZEFFY_API_KEY and ZEFFY_WEBHOOK_SECRET in
 * wp-config.php take precedence (docs/pre-launch.md, #5).
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

/**
 * The two secrets: option => [constant, label, remove label, help].
 *
 * @return array<string, array{constant: string, label: string, remove: string, help: string}>
 */
function rcobeca_zeffy_secrets(): array {
	return array(
		'rcobeca_zeffy_api_key'        => array(
			'constant' => 'ZEFFY_API_KEY',
			'label'    => __( 'Zeffy API key', 'rcobeca' ),
			'remove'   => __( 'Remove the saved API key', 'rcobeca' ),
			'help'     => __( 'Created by the Zeffy organisation owner in Zeffy → Settings → Integrations. Without it, Projects show the figures typed in by hand.', 'rcobeca' ),
		),
		'rcobeca_zeffy_webhook_secret' => array(
			'constant' => 'ZEFFY_WEBHOOK_SECRET',
			'label'    => __( 'Webhook signing secret', 'rcobeca' ),
			'remove'   => __( 'Remove the saved webhook secret', 'rcobeca' ),
			'help'     => __( 'Optional. Starts with whsec_; Zeffy shows it when you add the webhook below. Without it the hourly sync still runs.', 'rcobeca' ),
		),
	);
}

/**
 * Adds the page under Settings.
 */
function rcobeca_add_zeffy_settings_page(): void {
	add_options_page( __( 'Zeffy sync', 'rcobeca' ), __( 'Zeffy sync', 'rcobeca' ), 'manage_options', 'rcobeca-zeffy', 'rcobeca_render_zeffy_settings_page' );
}
add_action( 'admin_menu', 'rcobeca_add_zeffy_settings_page' );

/**
 * Renders the page.
 */
function rcobeca_render_zeffy_settings_page(): void {
	$done = sanitize_key( wp_unslash( $_GET['rcobeca-zeffy'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a notice flag only.
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Zeffy sync', 'rcobeca' ); ?></h1>
		<?php if ( 'saved' === $done ) : ?>
			<div class="notice notice-success"><p><?php esc_html_e( 'Settings saved.', 'rcobeca' ); ?></p></div>
		<?php elseif ( 'synced' === $done ) : ?>
			<div class="notice notice-info"><p><?php esc_html_e( 'Sync finished. Each Project’s result is below.', 'rcobeca' ); ?></p></div>
		<?php endif; ?>
		<p><?php esc_html_e( 'Every hour this site reads each Fundraising Project’s Zeffy form and updates its progress bar. A Project’s manual override always wins. Zeffy’s webhook, if added, makes a new gift show within a minute instead of within the hour.', 'rcobeca' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="rcobeca_zeffy_settings">
			<?php wp_nonce_field( 'rcobeca_zeffy_settings' ); ?>
			<table class="form-table" role="presentation">
				<?php
				foreach ( rcobeca_zeffy_secrets() as $option => $secret ) :
					$id       = str_replace( '_', '-', $option );
					$constant = defined( $secret['constant'] );
					$saved    = '' !== (string) get_option( $option, '' );
					?>
				<tr>
					<th scope="row"><label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $secret['label'] ); ?></label></th>
					<td>
						<p id="<?php echo esc_attr( $id ); ?>-status"><strong>
						<?php
						if ( $constant ) {
							/* translators: %s: constant name. */
							echo esc_html( sprintf( __( 'Set in wp-config.php (%s)', 'rcobeca' ), $secret['constant'] ) );
						} else {
							echo esc_html( $saved ? __( 'Saved (hidden)', 'rcobeca' ) : __( 'Not set', 'rcobeca' ) );
						}
						?>
						</strong></p>
						<?php if ( ! $constant ) : ?>
						<input type="password" class="regular-text code" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $option ); ?>" value="" autocomplete="off" placeholder="<?php echo esc_attr( $saved ? __( 'Paste a new value to replace it', 'rcobeca' ) : '' ); ?>" aria-describedby="<?php echo esc_attr( $id ); ?>-help">
							<?php if ( $saved ) : ?>
						<p><label><input type="checkbox" name="<?php echo esc_attr( $option ); ?>_remove" value="1"> <?php echo esc_html( $secret['remove'] ); ?></label></p>
						<?php endif; ?>
						<?php endif; ?>
						<p class="description" id="<?php echo esc_attr( $id ); ?>-help"><?php echo esc_html( $secret['help'] ); ?></p>
					</td>
				</tr>
				<?php endforeach; ?>
				<tr>
					<th scope="row"><?php esc_html_e( 'Webhook URL', 'rcobeca' ); ?></th>
					<td>
						<p><code><?php echo esc_html( RCOBECA\Zeffy_Sync::webhook_url() ); ?></code></p>
						<p class="description"><?php esc_html_e( 'In Zeffy → Settings → Integrations, add a webhook with this URL and the events payment.completed, payment.updated and payment.deleted, then paste its signing secret above.', 'rcobeca' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button( __( 'Save', 'rcobeca' ) ); ?>
		</form>
		<h2><?php esc_html_e( 'Linked Projects', 'rcobeca' ); ?></h2>
		<?php rcobeca_zeffy_linked_projects_table(); ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="rcobeca_zeffy_sync_now">
			<?php wp_nonce_field( 'rcobeca_zeffy_sync_now' ); ?>
			<?php submit_button( __( 'Sync now', 'rcobeca' ), 'secondary', 'submit', false, '' === RCOBECA\Zeffy_Sync::api_key() ? array( 'disabled' => 'disabled' ) : null ); ?>
		</form>
	</div>
	<?php
}

/**
 * The Fundraising Projects linked to a Zeffy form, with their last sync.
 */
function rcobeca_zeffy_linked_projects_table(): void {
	$projects = RCOBECA\Zeffy_Sync::linked_projects();
	if ( ! $projects ) {
		echo '<p>' . esc_html__( 'No Fundraising Project has a Zeffy campaign ID yet. Set one in the Project’s “Project details” box.', 'rcobeca' ) . '</p>';
		return;
	}
	echo '<table class="widefat striped"><thead><tr><th scope="col">' . esc_html__( 'Project', 'rcobeca' ) . '</th><th scope="col">' . esc_html__( 'Raised, synced', 'rcobeca' ) . '</th><th scope="col">' . esc_html__( 'Last synced', 'rcobeca' ) . '</th><th scope="col">' . esc_html__( 'Last sync problem', 'rcobeca' ) . '</th></tr></thead><tbody>';
	foreach ( $projects as $id ) {
		$at = (int) get_post_meta( $id, 'rcobeca_raised_synced_at', true );
		printf(
			'<tr><td><a href="%s">%s</a></td><td>%s</td><td>%s</td><td>%s</td></tr>',
			esc_url( (string) get_edit_post_link( $id ) ),
			esc_html( get_the_title( $id ) ),
			esc_html( $at ? rcobeca_money( (int) get_post_meta( $id, 'rcobeca_raised_cents', true ) ) : '—' ),
			esc_html( $at ? wp_date( 'F j, Y g:i a', $at ) : __( 'Never', 'rcobeca' ) ),
			esc_html( (string) get_post_meta( $id, 'rcobeca_zeffy_sync_error', true ) )
		);
	}
	echo '</tbody></table>';
}

/**
 * Saves the key and secret: a pasted value replaces the saved one, an empty
 * box keeps it, and the Remove box deletes it.
 */
function rcobeca_save_zeffy_settings(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Sorry, you are not allowed to change these settings.', 'rcobeca' ), 403 );
	}
	check_admin_referer( 'rcobeca_zeffy_settings' );
	foreach ( array_keys( rcobeca_zeffy_secrets() ) as $option ) {
		$value = trim( sanitize_text_field( wp_unslash( $_POST[ $option ] ?? '' ) ) );
		if ( ! empty( $_POST[ $option . '_remove' ] ) ) {
			delete_option( $option );
		} elseif ( '' !== $value ) {
			update_option( $option, $value, false );
		}
	}
	delete_transient( 'rcobeca_zeffy_campaigns' );
	wp_safe_redirect( admin_url( 'options-general.php?page=rcobeca-zeffy&rcobeca-zeffy=saved' ) );
	exit;
}
add_action( 'admin_post_rcobeca_zeffy_settings', 'rcobeca_save_zeffy_settings' );

/**
 * Runs the sync now, from the button.
 */
function rcobeca_zeffy_sync_now(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'rcobeca' ), 403 );
	}
	check_admin_referer( 'rcobeca_zeffy_sync_now' );
	RCOBECA\Zeffy_Sync::sync_all();
	wp_safe_redirect( admin_url( 'options-general.php?page=rcobeca-zeffy&rcobeca-zeffy=synced' ) );
	exit;
}
add_action( 'admin_post_rcobeca_zeffy_sync_now', 'rcobeca_zeffy_sync_now' );
