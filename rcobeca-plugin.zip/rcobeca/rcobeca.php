<?php
/**
 * Plugin Name: RCOBECA
 * Description: Content structure for the RCOBECA site: content types, fields, dynamic blocks, Zeffy sync, forms and the importer.
 * Version: 0.1.0
 * Requires at least: 6.6
 * Requires PHP: 8.1
 * License: GPL-2.0-or-later
 * Text Domain: rcobeca
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

define( 'RCOBECA_VERSION', '0.1.0' );
define( 'RCOBECA_DIR', __DIR__ );

// Every concern is a file under includes/ or one folder down (for example
// includes/content-types/project.php). Adding the file is enough: nothing here
// needs editing, so parallel work never collides on this file.
foreach ( array_merge( glob( __DIR__ . '/includes/*.php' ), glob( __DIR__ . '/includes/*/*.php' ) ) as $rcobeca_file ) {
	require_once $rcobeca_file;
}
unset( $rcobeca_file );
