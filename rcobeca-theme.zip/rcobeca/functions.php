<?php
/**
 * RCOBECA theme: presentation only. Tokens live in theme.json, markup in
 * templates, parts and patterns; this file loads the stylesheet and
 * registers block styles.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

require get_theme_file_path( 'inc/gallery-lightbox.php' );
require get_theme_file_path( 'inc/video-facade.php' );

/**
 * Loads the theme stylesheet on the front end and in the editor.
 */
function rcobeca_theme_styles(): void {
	$version = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'rcobeca', get_stylesheet_uri(), array(), $version );
}
add_action( 'wp_enqueue_scripts', 'rcobeca_theme_styles' );

/**
 * Editor parity: the same stylesheet inside the block editor canvas.
 */
function rcobeca_editor_styles(): void {
	add_editor_style( 'style.css' );
}
add_action( 'after_setup_theme', 'rcobeca_editor_styles' );

/**
 * Block styles editors can pick in the Styles panel.
 */
function rcobeca_block_styles(): void {
	register_block_style(
		'core/button',
		array(
			'name'  => 'gold',
			'label' => __( 'Gold (Donate)', 'rcobeca' ),
		)
	);
	register_block_style(
		'core/paragraph',
		array(
			'name'  => 'kicker',
			'label' => __( 'Kicker (small italic label)', 'rcobeca' ),
		)
	);
}
add_action( 'init', 'rcobeca_block_styles' );

/**
 * The inserter category that holds the shared patterns (patterns/*.php).
 */
function rcobeca_pattern_category(): void {
	register_block_pattern_category(
		'rcobeca',
		array(
			'label'       => __( 'RCOBECA', 'rcobeca' ),
			'description' => __( 'Shared RCOBECA sections: bands, headers, cards, impact figures, quotes and calls to action.', 'rcobeca' ),
		)
	);
}
add_action( 'init', 'rcobeca_pattern_category' );

/**
 * The style-guide page is a reference for builders, not content: keep it out of search.
 *
 * @param array $robots Robots directives.
 * @return array
 */
function rcobeca_style_guide_robots( array $robots ): array {
	if ( is_page( 'style-guide' ) ) {
		$robots['noindex'] = true;
		$robots['follow']  = true;
	}
	return $robots;
}
add_filter( 'wp_robots', 'rcobeca_style_guide_robots' );

/**
 * Lighter pages: only the first content image loads eagerly (the hero or a
 * page's lead photo); every image below it waits until it is scrolled near.
 */
function rcobeca_eager_images(): int {
	return 1;
}
add_filter( 'wp_omit_loading_attr_threshold', 'rcobeca_eager_images' );

// No emoji script: every browser the site supports draws emoji itself.
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
