<?php
/**
 * Lightbox for galleries: any Gallery block whose images link to their media
 * files opens in PhotoSwipe (MIT, vendored in assets/vendor/photoswipe). The
 * script and styles load only on pages that have such a gallery.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registers the lightbox script module and the PhotoSwipe stylesheet.
 */
function rcobeca_register_lightbox(): void {
	$version = wp_get_theme()->get( 'Version' );
	wp_register_script_module( 'rcobeca-gallery-lightbox', get_theme_file_uri( 'assets/js/gallery-lightbox.js' ), array( '@wordpress/interactivity' ), $version );
	wp_register_style( 'rcobeca-photoswipe', get_theme_file_uri( 'assets/vendor/photoswipe/photoswipe.css' ), array(), '5.4.4' );
}
add_action( 'init', 'rcobeca_register_lightbox' );

/**
 * Marks galleries linked to media files and loads the lightbox for them.
 *
 * @param string $block_content Rendered gallery.
 * @param array  $block         Parsed block.
 * @return string
 */
function rcobeca_gallery_lightbox( string $block_content, array $block ): string {
	if ( 'media' !== ( $block['attrs']['linkTo'] ?? '' ) ) {
		return $block_content;
	}
	$tags = new WP_HTML_Tag_Processor( $block_content );
	if ( ! $tags->next_tag( array( 'class_name' => 'wp-block-gallery' ) ) ) {
		return $block_content;
	}
	// Interactivity API (assets/js/gallery-lightbox.js): each photo's link opens
	// the viewer; without JavaScript it opens the photo itself.
	$tags->add_class( 'rcobeca-lightbox' );
	$tags->set_attribute( 'data-wp-interactive', 'rcobeca/lightbox' );
	// A long gallery shows its first photos; "See all" opens the rest in the
	// same viewer. Without JavaScript the theme's CSS shows every photo.
	$shown  = 6;
	$photos = 0;
	while ( $tags->next_tag() ) {
		if ( 'FIGURE' === $tags->get_tag() && $tags->has_class( 'wp-block-image' ) && ++$photos > $shown ) {
			$tags->add_class( 'is-extra' );
		} elseif ( 'A' === $tags->get_tag() ) {
			$tags->set_attribute( 'data-wp-on--click', 'actions.open' );
		}
	}
	wp_enqueue_script_module( 'rcobeca-gallery-lightbox' );
	wp_enqueue_style( 'rcobeca-photoswipe' );
	$html = $tags->get_updated_html();
	$end  = strrpos( $html, '</figure>' );
	if ( $photos <= $shown || false === $end ) {
		return $html;
	}
	$button = sprintf(
		'<div class="rcobeca-lightbox__all"><button type="button" data-start="%1$d" data-wp-on--click="actions.open">%2$s</button></div>',
		$shown,
		/* translators: %d: number of photos in the gallery. */
		esc_html( sprintf( _n( 'See all %d photo', 'See all %d photos', $photos, 'rcobeca' ), $photos ) )
	);
	return substr_replace( $html, $button, $end, 0 );
}
add_filter( 'render_block_core/gallery', 'rcobeca_gallery_lightbox', 10, 2 );

/**
 * Gives each media-linked image from the media library its full size, which
 * the lightbox needs to lay the photo out before it loads.
 *
 * @param string $block_content Rendered image.
 * @param array  $block         Parsed block.
 * @return string
 */
function rcobeca_image_full_size( string $block_content, array $block ): string {
	$id = (int) ( $block['attrs']['id'] ?? 0 );
	if ( ! $id || 'media' !== ( $block['attrs']['linkDestination'] ?? '' ) ) {
		return $block_content;
	}
	$full = wp_get_attachment_image_src( $id, 'full' );
	$tags = new WP_HTML_Tag_Processor( $block_content );
	if ( $full && $tags->next_tag( 'a' ) ) {
		$tags->set_attribute( 'data-pswp-width', (string) $full[1] );
		$tags->set_attribute( 'data-pswp-height', (string) $full[2] );
	}
	return $tags->get_updated_html();
}
add_filter( 'render_block_core/image', 'rcobeca_image_full_size', 10, 2 );
