<?php
/**
 * YouTube videos load YouTube's player (about 4 MB of script) only when a
 * visitor asks to play one. Until then an Embed block shows the video's
 * poster (YouTube's thumbnail, loaded lazily) with a play button and its
 * title over it, which is a plain link to the video on YouTube
 * when JavaScript is off. Playing uses youtube-nocookie.com.
 *
 * @package RCOBECA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registers the script that swaps a poster for the player.
 */
function rcobeca_register_video_facade(): void {
	wp_register_script_module( 'rcobeca-video', get_theme_file_uri( 'assets/js/video.js' ), array( '@wordpress/interactivity' ), wp_get_theme()->get( 'Version' ) );
}
add_action( 'init', 'rcobeca_register_video_facade' );

/**
 * Replaces a YouTube Embed block's player with its poster and a play link.
 *
 * @param string $block_content Rendered embed.
 * @param array  $block         Parsed block.
 * @return string
 */
function rcobeca_video_facade( string $block_content, array $block ): string {
	if ( 'youtube' !== ( $block['attrs']['providerNameSlug'] ?? '' ) || ! preg_match( '#<iframe[^>]*></iframe>#s', $block_content, $iframe ) ) {
		return $block_content;
	}
	$tags = new WP_HTML_Tag_Processor( $iframe[0] );
	$tags->next_tag( 'iframe' );
	$src   = (string) $tags->get_attribute( 'src' );
	$title = (string) $tags->get_attribute( 'title' );
	if ( ! preg_match( '#youtube(?:-nocookie)?\.com/embed/([\w-]{11})#', $src, $id ) ) {
		return $block_content;
	}
	$id      = $id[1];
	$context = array(
		'video'   => $id,
		'title'   => '' !== $title ? $title : __( 'YouTube video', 'rcobeca' ),
		'playing' => false,
	);
	// Interactivity API (assets/js/video.js): the link becomes a play button,
	// and playing puts the player in the wrapper (callbacks.load).
	$facade = sprintf(
		'<div class="rcobeca-video" data-wp-interactive="rcobeca/video" %1$s data-wp-watch="callbacks.load"><a class="rcobeca-video__link" href="%2$s" data-wp-on--click="actions.play" data-wp-bind--role="state.role" data-wp-bind--hidden="context.playing"><img class="rcobeca-video__poster" src="%3$s" alt="" width="480" height="360" loading="lazy" decoding="async" /><span class="rcobeca-video__play" aria-hidden="true"></span><span class="rcobeca-video__title" aria-hidden="true">%5$s</span><span class="screen-reader-text">%4$s</span></a></div>',
		wp_interactivity_data_wp_context( $context ),
		esc_url( 'https://www.youtube.com/watch?v=' . $id ),
		esc_url( 'https://i.ytimg.com/vi/' . $id . '/hqdefault.jpg' ),
		/* translators: %s: video title. */
		esc_html( sprintf( __( 'Play video: %s', 'rcobeca' ), $context['title'] ) ),
		esc_html( $context['title'] )
	);
	wp_enqueue_script_module( 'rcobeca-video' );
	return str_replace( $iframe[0], $facade, $block_content );
}
add_filter( 'render_block_core/embed', 'rcobeca_video_facade', 10, 2 );
