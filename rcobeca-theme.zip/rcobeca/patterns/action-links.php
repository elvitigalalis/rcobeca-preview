<?php
/**
 * Title: Action links
 * Slug: rcobeca/action-links
 * Categories: rcobeca, call-to-action
 * Keywords: connect, give, attend, actions, links
 * Description: A full-width royal blue band of three ways in (Exeter's Connect · Make a Gift · Attend): a short heading and one sentence each, the whole column a link. Sits under the home page's hero.
 *
 * @package RCOBECA
 */

$rcobeca_actions = array(
	array(
		'title' => 'Connect',
		'text'  => 'Join or renew your membership, update your details, and find Old Royalists around the world.',
		'path'  => '/join/',
	),
	array(
		'title' => 'Give',
		'text'  => 'Fund classrooms, labs and scholarships at Royal College, and relief in Sri Lanka. Gifts are tax-deductible in the US.',
		'path'  => '/donate/',
	),
	array(
		'title' => 'Attend',
		'text'  => 'The Royal Charity Ball each year, cricket festivals and get-togethers with Old Royalists and their families.',
		'path'  => '/events/',
	),
);
?>
<!-- wp:group {"tagName":"section","align":"full","className":"rcobeca-actions","backgroundColor":"primary","textColor":"base","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull rcobeca-actions has-base-color has-primary-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)">
	<!-- wp:group {"align":"wide","className":"rcobeca-actions__grid","layout":{"type":"grid","columnCount":3,"minimumColumnWidth":"16rem"}} -->
	<div class="wp-block-group alignwide rcobeca-actions__grid">
		<?php foreach ( $rcobeca_actions as $rcobeca_action ) : ?>
		<!-- wp:group {"className":"rcobeca-action","layout":{"type":"default"}} -->
		<div class="wp-block-group rcobeca-action">
			<!-- wp:heading {"className":"rcobeca-action__title"} -->
			<h2 class="wp-block-heading rcobeca-action__title"><a href="<?php echo esc_url( home_url( $rcobeca_action['path'] ) ); ?>"><?php echo esc_html( $rcobeca_action['title'] ); ?></a></h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"className":"rcobeca-action__text"} -->
			<p class="rcobeca-action__text"><?php echo esc_html( $rcobeca_action['text'] ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->
		<?php endforeach; ?>
	</div>
	<!-- /wp:group -->
</section>
<!-- /wp:group -->
