<?php
/**
 * Title: Card grid
 * Slug: rcobeca/card-grid
 * Categories: rcobeca
 * Keywords: cards, grid, projects, stories, features
 * Description: Three cards, each a square-cornered photo, a meta line, a linked title and one or two sentences. No boxes or shadows.
 *
 * @package RCOBECA
 */

$rcobeca_cards = array(
	array(
		'image' => 'smart-conference-room.webp',
		'alt'   => 'The new smart conference room at Royal College, with a long table and wall screens',
		'meta'  => 'Royal College · 2025',
		'title' => 'A smart conference room for the College',
		'text'  => 'Opened at the College in January 2025, funded by Old Boys on the East Coast.',
	),
	array(
		'image' => 'cyclone-relief.webp',
		'alt'   => 'Families gathered to receive relief supplies after Cyclone Ditwah',
		'meta'  => 'Relief in Sri Lanka · 2025',
		'title' => 'Immediate relief after Cyclone Ditwah',
		'text'  => 'Food and essentials for families affected by the cyclone.',
	),
	array(
		'image' => 'school-supplies.webp',
		'alt'   => 'A young pupil receives school supplies in a classroom',
		'meta'  => 'Relief in Sri Lanka · 2025',
		'title' => 'Back to school after the cyclone',
		'text'  => 'Books and school supplies so children could return to class.',
	),
);
?>
<!-- wp:group {"align":"wide","className":"rcobeca-card-grid","style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"grid","columnCount":3,"minimumColumnWidth":"17rem"}} -->
<div class="wp-block-group alignwide rcobeca-card-grid">
	<?php foreach ( $rcobeca_cards as $rcobeca_card ) : ?>
	<!-- wp:group {"tagName":"article","className":"rcobeca-card","layout":{"type":"default"}} -->
	<article class="wp-block-group rcobeca-card">
		<!-- wp:image {"aspectRatio":"3/2","scale":"cover","sizeSlug":"large","className":"rcobeca-card__image"} -->
		<figure class="wp-block-image size-large rcobeca-card__image"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/samples/' . $rcobeca_card['image'] ) ); ?>" alt="<?php echo esc_attr( $rcobeca_card['alt'] ); ?>" style="aspect-ratio:3/2;object-fit:cover"/></figure>
		<!-- /wp:image -->
		<!-- wp:paragraph {"className":"rcobeca-card__meta"} -->
		<p class="rcobeca-card__meta"><?php echo esc_html( $rcobeca_card['meta'] ); ?></p>
		<!-- /wp:paragraph -->
		<!-- wp:heading {"level":3,"className":"rcobeca-card__title"} -->
		<h3 class="wp-block-heading rcobeca-card__title"><a href="<?php echo esc_url( home_url( '/projects/' ) ); ?>"><?php echo esc_html( $rcobeca_card['title'] ); ?></a></h3>
		<!-- /wp:heading -->
		<!-- wp:paragraph -->
		<p><?php echo esc_html( $rcobeca_card['text'] ); ?></p>
		<!-- /wp:paragraph -->
	</article>
	<!-- /wp:group -->
	<?php endforeach; ?>
</div>
<!-- /wp:group -->
