<?php
/**
 * Title: Colour band
 * Slug: rcobeca/colour-band
 * Categories: rcobeca
 * Keywords: band, banner, feature, ball, announcement
 * Description: A full-width royal blue band for one big message, such as the Royal Charity Ball. Switch the background to Navy or Cream for rhythm.
 *
 * @package RCOBECA
 */

?>
<!-- wp:group {"align":"full","className":"rcobeca-colour-band","backgroundColor":"primary","textColor":"base","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull rcobeca-colour-band has-base-color has-primary-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
	<!-- wp:columns {"verticalAlignment":"bottom","align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
	<div class="wp-block-columns alignwide are-vertically-aligned-bottom">
		<!-- wp:column {"verticalAlignment":"bottom","width":"58%"} -->
		<div class="wp-block-column is-vertically-aligned-bottom" style="flex-basis:58%">
			<!-- wp:paragraph {"className":"is-style-kicker"} -->
			<p class="is-style-kicker">The 30th Royal Charity Ball</p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"fontSize":"xxx-large"} -->
			<h2 class="wp-block-heading has-xxx-large-font-size">An evening for Royal College</h2>
			<!-- /wp:heading -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"bottom","className":"rcobeca-colour-band__aside"} -->
		<div class="wp-block-column is-vertically-aligned-bottom rcobeca-colour-band__aside">
			<!-- wp:paragraph {"className":"rcobeca-colour-band__meta"} -->
			<p class="rcobeca-colour-band__meta">Saturday 25 April 2026<br>The Royal Manor, Garfield, New Jersey</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph -->
			<p>Our flagship gala for three decades: dinner, music and dancing, raising funds for the College.</p>
			<!-- /wp:paragraph -->
			<!-- wp:buttons -->
			<div class="wp-block-buttons">
				<!-- wp:button {"className":"is-style-gold"} -->
				<div class="wp-block-button is-style-gold"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/ball/' ) ); ?>">About the Ball</a></div>
				<!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
