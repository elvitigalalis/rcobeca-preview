<?php
/**
 * Title: Call-to-action band
 * Slug: rcobeca/cta-band
 * Categories: rcobeca, call-to-action
 * Keywords: join, donate, membership, action
 * Description: A navy band with one invitation and the Join and Donate buttons. Use it to close a page.
 *
 * @package RCOBECA
 */

?>
<!-- wp:group {"align":"full","className":"rcobeca-cta-band","backgroundColor":"primary-deep","textColor":"base","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull rcobeca-cta-band has-base-color has-primary-deep-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
	<!-- wp:image {"width":"48px","sizeSlug":"full","align":"center","className":"rcobeca-cta-band__crest"} -->
	<figure class="wp-block-image aligncenter size-full is-resized rcobeca-cta-band__crest"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/crest.svg' ) ); ?>" alt="" style="width:48px"/></figure>
	<!-- /wp:image -->
	<!-- wp:paragraph {"align":"center","className":"is-style-kicker"} -->
	<p class="has-text-align-center is-style-kicker">Membership</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading {"textAlign":"center"} -->
	<h2 class="wp-block-heading has-text-align-center">Once a Royalist, always a Royalist</h2>
	<!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","className":"rcobeca-cta-band__text"} -->
	<p class="has-text-align-center rcobeca-cta-band__text">Join RCOBECA as an Annual or Life Member: meet Old Boys on the East Coast and help the students of Royal College.</p>
	<!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-buttons">
		<!-- wp:button {"className":"is-style-gold"} -->
		<div class="wp-block-button is-style-gold"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/join/' ) ); ?>">Join or renew</a></div>
		<!-- /wp:button -->
		<!-- wp:button {"className":"is-style-outline rcobeca-on-dark"} -->
		<div class="wp-block-button is-style-outline rcobeca-on-dark"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/donate/' ) ); ?>">Donate</a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
