<?php
/**
 * Title: Trust footer
 * Slug: rcobeca/footer
 * Categories: footer
 * Block Types: core/template-part/footer
 * Inserter: no
 * Description: Newsletter slot, sitemap, contacts and socials, then the RCOBEC Foundation trust line (501(c)(3), EIN), the Transparency link and the current-year copyright.
 *
 * @package RCOBECA
 */

$rcobeca_footer_columns = array(
	'About'      => array(
		'Our Story'         => '/our-story/',
		'Committee'         => '/committee/',
		'Committee History' => '/committee/history/',
		'Royal College'     => '/royal-college/',
		'Contact'           => '/contact/',
	),
	'Our Impact' => array(
		'Projects'           => '/projects/',
		'Donate'             => '/donate/',
		'Royal Charity Ball' => '/ball/',
		'Events'             => '/events/',
		'News'               => '/news/',
	),
	'Community'  => array(
		'Join or Renew'           => '/join/',
		'Life Members'            => '/life-members/',
		'Update Your Details'     => '/update-your-details/',
		'Royal College Worldwide' => '/royal-college-worldwide/',
	),
);
?>
<!-- wp:group {"className":"rcobeca-footer","backgroundColor":"primary-deep","textColor":"base","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|40"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group rcobeca-footer has-base-color has-primary-deep-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--40)">
	<!-- wp:pattern {"slug":"rcobeca/newsletter-signup"} /-->

	<!-- wp:columns {"align":"wide","className":"rcobeca-footer__main"} -->
	<div class="wp-block-columns alignwide rcobeca-footer__main">
		<!-- wp:column {"width":"36%","className":"rcobeca-footer__brand"} -->
		<div class="wp-block-column rcobeca-footer__brand" style="flex-basis:36%">
			<!-- wp:paragraph {"className":"rcobeca-brand rcobeca-brand--footer"} -->
			<p class="rcobeca-brand rcobeca-brand--footer"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img class="rcobeca-brand__crest" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/crest.svg' ) ); ?>" alt="" width="41" height="61" loading="lazy"/><span class="rcobeca-brand__name">RCOBECA</span></a></p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"className":"rcobeca-footer__mission"} -->
			<p class="rcobeca-footer__mission">Old Boys of Royal College, Colombo, on the US East Coast since 1993: bringing our families together and helping the students of Royal College.</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"className":"rcobeca-footer__contact"} -->
			<p class="rcobeca-footer__contact">General enquiries<br><a href="mailto:secretary@rcobeca.org">secretary@rcobeca.org</a><br>Donations and dues<br><a href="mailto:treasurer@rcobeca.org">treasurer@rcobeca.org</a></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<?php foreach ( $rcobeca_footer_columns as $rcobeca_heading => $rcobeca_links ) : ?>
		<!-- wp:column {"className":"rcobeca-footer__links"} -->
		<div class="wp-block-column rcobeca-footer__links">
			<!-- wp:heading {"level":2,"className":"rcobeca-footer__heading"} -->
			<h2 class="wp-block-heading rcobeca-footer__heading"><?php echo esc_html( $rcobeca_heading ); ?></h2>
			<!-- /wp:heading -->
			<!-- wp:list {"className":"rcobeca-footer__list"} -->
			<ul class="wp-block-list rcobeca-footer__list">
				<?php foreach ( $rcobeca_links as $rcobeca_label => $rcobeca_path ) : ?>
				<!-- wp:list-item -->
				<li><a href="<?php echo esc_url( home_url( $rcobeca_path ) ); ?>"><?php echo esc_html( $rcobeca_label ); ?></a></li>
				<!-- /wp:list-item -->
				<?php endforeach; ?>
			</ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->
		<?php endforeach; ?>
	</div>
	<!-- /wp:columns -->

	<!-- wp:group {"align":"wide","className":"rcobeca-footer__trust","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"center"}} -->
	<div class="wp-block-group alignwide rcobeca-footer__trust">
		<!-- wp:paragraph {"className":"rcobeca-footer__legal"} -->
		<p class="rcobeca-footer__legal"><strong>RCOBEC Foundation Inc.</strong> is a 501(c)(3) tax-exempt public charity, EIN 81-4203477. Gifts are tax-deductible to the extent allowed by law. <a href="<?php echo esc_url( home_url( '/transparency/' ) ); ?>">Transparency</a> · <a href="<?php echo esc_url( home_url( '/privacy/' ) ); ?>">Privacy</a></p>
		<!-- /wp:paragraph -->
		<!-- wp:social-links {"iconColor":"base","iconColorValue":"#FFFFFF","className":"is-style-logos-only rcobeca-footer__socials","layout":{"type":"flex","flexWrap":"nowrap"}} -->
		<ul class="wp-block-social-links has-icon-color is-style-logos-only rcobeca-footer__socials">
			<!-- wp:social-link {"url":"https://www.facebook.com/rcobecf","service":"facebook"} /-->
			<!-- wp:social-link {"url":"https://www.instagram.com/rcobeca/","service":"instagram"} /-->
			<!-- wp:social-link {"url":"https://x.com/rcobeca","service":"x"} /-->
			<!-- wp:social-link {"url":"https://www.linkedin.com/groups/2417585/","service":"linkedin"} /-->
			<!-- wp:social-link {"url":"https://www.youtube.com/@rcobeca","service":"youtube"} /-->
		</ul>
		<!-- /wp:social-links -->
	</div>
	<!-- /wp:group -->

	<!-- wp:paragraph {"align":"wide","className":"rcobeca-footer__small"} -->
	<p class="alignwide rcobeca-footer__small">&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> RCOBEC Foundation Inc. RCOBECA is the Royal College Old Boys&#8217; East Coast Association, founded 1993. Its 2017 website was developed by a student of the Royal College Computer Society.</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
