<?php
/**
 * Title: Site header
 * Slug: rcobeca/header
 * Categories: header
 * Block Types: core/template-part/header
 * Inserter: no
 * Description: Crest and wordmark, the main menu and the persistent Join and Donate buttons. Menu links point at each page's final URL.
 *
 * @package RCOBECA
 */

?>
<!-- wp:group {"className":"rcobeca-header","layout":{"type":"constrained"}} -->
<div class="wp-block-group rcobeca-header">
	<!-- wp:group {"align":"wide","className":"rcobeca-header__bar","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
	<div class="wp-block-group alignwide rcobeca-header__bar">
		<!-- wp:paragraph {"className":"rcobeca-brand"} -->
		<p class="rcobeca-brand"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img class="rcobeca-brand__crest" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/crest.svg' ) ); ?>" alt="" width="34" height="50"/><span class="rcobeca-brand__name">RCOBECA</span><span class="rcobeca-brand__full">Royal College Old Boys&#8217;<br>East Coast Association</span></a></p>
		<!-- /wp:paragraph -->

		<!-- wp:group {"className":"rcobeca-header__actions","layout":{"type":"flex","flexWrap":"nowrap"}} -->
		<div class="wp-block-group rcobeca-header__actions">
			<!-- wp:navigation {"ariaLabel":"Main","overlayMenu":"mobile","openSubmenusOnClick":true,"overlayBackgroundColor":"primary-deep","overlayTextColor":"base","className":"rcobeca-menu","layout":{"type":"flex","justifyContent":"right","orientation":"horizontal"}} -->
				<!-- wp:navigation-submenu {"label":"About","kind":"custom","isTopLevelItem":true} -->
					<!-- wp:navigation-link {"label":"Our Story","url":"<?php echo esc_url( home_url( '/our-story/' ) ); ?>","kind":"custom"} /-->
					<!-- wp:navigation-link {"label":"Committee","url":"<?php echo esc_url( home_url( '/committee/' ) ); ?>","kind":"custom"} /-->
					<!-- wp:navigation-link {"label":"Committee History","url":"<?php echo esc_url( home_url( '/committee/history/' ) ); ?>","kind":"custom"} /-->
					<!-- wp:navigation-link {"label":"Royal College","url":"<?php echo esc_url( home_url( '/royal-college/' ) ); ?>","kind":"custom"} /-->
					<!-- wp:navigation-link {"label":"Transparency","url":"<?php echo esc_url( home_url( '/transparency/' ) ); ?>","kind":"custom"} /-->
					<!-- wp:navigation-link {"label":"Contact","url":"<?php echo esc_url( home_url( '/contact/' ) ); ?>","kind":"custom"} /-->
				<!-- /wp:navigation-submenu -->
				<!-- wp:navigation-submenu {"label":"Our Impact","kind":"custom","isTopLevelItem":true} -->
					<!-- wp:navigation-link {"label":"Projects","url":"<?php echo esc_url( home_url( '/projects/' ) ); ?>","kind":"custom"} /-->
					<!-- wp:navigation-link {"label":"Donate","url":"<?php echo esc_url( home_url( '/donate/' ) ); ?>","kind":"custom"} /-->
				<!-- /wp:navigation-submenu -->
				<!-- wp:navigation-submenu {"label":"Events","kind":"custom","isTopLevelItem":true} -->
					<!-- wp:navigation-link {"label":"Royal Charity Ball","url":"<?php echo esc_url( home_url( '/ball/' ) ); ?>","kind":"custom"} /-->
					<!-- wp:navigation-link {"label":"Upcoming & Past Events","url":"<?php echo esc_url( home_url( '/events/' ) ); ?>","kind":"custom"} /-->
					<!-- wp:navigation-link {"label":"Past Balls","url":"<?php echo esc_url( home_url( '/ball/past/' ) ); ?>","kind":"custom"} /-->
				<!-- /wp:navigation-submenu -->
				<!-- wp:navigation-submenu {"label":"Community","kind":"custom","isTopLevelItem":true} -->
					<!-- wp:navigation-link {"label":"Join or Renew","url":"<?php echo esc_url( home_url( '/join/' ) ); ?>","kind":"custom"} /-->
					<!-- wp:navigation-link {"label":"Life Members","url":"<?php echo esc_url( home_url( '/life-members/' ) ); ?>","kind":"custom"} /-->
					<!-- wp:navigation-link {"label":"Update Your Details","url":"<?php echo esc_url( home_url( '/update-your-details/' ) ); ?>","kind":"custom"} /-->
					<!-- wp:navigation-link {"label":"Royal College Worldwide","url":"<?php echo esc_url( home_url( '/royal-college-worldwide/' ) ); ?>","kind":"custom"} /-->
				<!-- /wp:navigation-submenu -->
				<!-- wp:navigation-link {"label":"News","url":"<?php echo esc_url( home_url( '/news/' ) ); ?>","kind":"custom","isTopLevelLink":true} /-->
				<!-- wp:search {"label":"Search the site","showLabel":false,"placeholder":"Search Projects, Events, people and pages","buttonText":"Search","buttonPosition":"button-only","buttonUseIcon":true,"isSearchFieldHidden":true,"className":"rcobeca-menu-search"} /-->
			<!-- /wp:navigation -->

			<!-- wp:buttons {"className":"rcobeca-header__buttons","layout":{"type":"flex","flexWrap":"nowrap"}} -->
			<div class="wp-block-buttons rcobeca-header__buttons">
				<!-- wp:button {"className":"is-style-outline"} -->
				<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/join/' ) ); ?>">Join</a></div>
				<!-- /wp:button -->
				<!-- wp:button {"className":"is-style-gold"} -->
				<div class="wp-block-button is-style-gold"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/donate/' ) ); ?>">Donate</a></div>
				<!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
