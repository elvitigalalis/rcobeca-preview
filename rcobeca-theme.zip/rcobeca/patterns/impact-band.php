<?php
/**
 * Title: Impact band
 * Slug: rcobeca/impact-band
 * Categories: rcobeca
 * Keywords: numbers, stats, figures, impact, proof
 * Description: A cream band of headline figures. Each figure has a one-line definition and a link to its proof; the band carries an "As of" date so a figure never reads as live.
 *
 * @package RCOBECA
 */

$rcobeca_stats = array(
	array(
		'figure' => '1993',
		'label'  => 'Founded by Old Royalists in the New York tri-state area.',
		'link'   => 'Our Story',
		'path'   => '/our-story/',
	),
	array(
		'figure' => '30',
		'label'  => 'Royal Charity Balls, the 30th held in April 2026.',
		'link'   => 'Past Balls',
		'path'   => '/ball/past/',
	),
	array(
		'figure' => 'Rs 15M',
		'label'  => 'A 32-bed nurses’ quarters for the Infectious Diseases Hospital, 2020.',
		'link'   => 'Projects',
		'path'   => '/projects/',
	),
	array(
		'figure' => '501(c)(3)',
		'label'  => 'RCOBEC Foundation Inc., so gifts are tax-deductible in the US.',
		'link'   => 'Transparency',
		'path'   => '/transparency/',
	),
);
?>
<!-- wp:group {"align":"full","className":"rcobeca-impact-band","backgroundColor":"cream","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull rcobeca-impact-band has-cream-background-color has-background" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
	<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
	<div class="wp-block-columns alignwide">
		<!-- wp:column {"width":"32%"} -->
		<div class="wp-block-column" style="flex-basis:32%">
			<!-- wp:paragraph {"className":"is-style-kicker"} -->
			<p class="is-style-kicker">Our impact</p>
			<!-- /wp:paragraph -->
			<!-- wp:heading -->
			<h2 class="wp-block-heading">RCOBECA in numbers</h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"className":"rcobeca-impact-band__asof"} -->
			<p class="rcobeca-impact-band__asof">As of October 2026</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:group {"className":"rcobeca-stats","style":{"spacing":{"blockGap":"var:preset|spacing|50"}},"layout":{"type":"grid","columnCount":2,"minimumColumnWidth":"14rem"}} -->
			<div class="wp-block-group rcobeca-stats">
				<?php foreach ( $rcobeca_stats as $rcobeca_stat ) : ?>
				<!-- wp:group {"className":"rcobeca-stat","layout":{"type":"default"}} -->
				<div class="wp-block-group rcobeca-stat">
					<!-- wp:paragraph {"className":"rcobeca-stat__figure"} -->
					<p class="rcobeca-stat__figure"><?php echo esc_html( $rcobeca_stat['figure'] ); ?></p>
					<!-- /wp:paragraph -->
					<!-- wp:paragraph {"className":"rcobeca-stat__label"} -->
					<p class="rcobeca-stat__label"><?php echo esc_html( $rcobeca_stat['label'] ); ?></p>
					<!-- /wp:paragraph -->
					<!-- wp:paragraph {"className":"rcobeca-more"} -->
					<p class="rcobeca-more"><a href="<?php echo esc_url( home_url( $rcobeca_stat['path'] ) ); ?>"><?php echo esc_html( $rcobeca_stat['link'] ); ?></a></p>
					<!-- /wp:paragraph -->
				</div>
				<!-- /wp:group -->
				<?php endforeach; ?>
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
