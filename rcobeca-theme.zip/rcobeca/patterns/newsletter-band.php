<?php
/**
 * Title: Newsletter band
 * Slug: rcobeca/newsletter-band
 * Categories: rcobeca, call-to-action
 * Keywords: newsletter, subscribe, mailing list, email
 * Description: A cream band inviting people to the newsletter: headline left, the sign-up button right. The button is the site's one newsletter sign-up (Settings → Join and newsletter). Use it near the end of the home page.
 *
 * @package RCOBECA
 */

?>
<!-- wp:group {"align":"full","className":"rcobeca-newsletter-band","backgroundColor":"cream","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull rcobeca-newsletter-band has-cream-background-color has-background" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
	<!-- wp:columns {"verticalAlignment":"center","align":"wide"} -->
	<div class="wp-block-columns alignwide are-vertically-aligned-center">
		<!-- wp:column {"verticalAlignment":"center","width":"60%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:60%">
			<!-- wp:paragraph {"className":"is-style-kicker"} -->
			<p class="is-style-kicker">The RCOBECA newsletter</p>
			<!-- /wp:paragraph -->
			<!-- wp:heading -->
			<h2 class="wp-block-heading">News from Old Royalists on the East Coast</h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"className":"rcobeca-newsletter-band__text"} -->
			<p class="rcobeca-newsletter-band__text">The Royal Charity Ball, our Projects at Royal College and get-togethers, a few times a year. One list, no spam.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center","width":"40%","className":"rcobeca-newsletter-band__action"} -->
		<div class="wp-block-column is-vertically-aligned-center rcobeca-newsletter-band__action" style="flex-basis:40%">
			<!-- wp:rcobeca/newsletter-signup /-->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
