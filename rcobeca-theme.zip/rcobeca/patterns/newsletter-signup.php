<?php
/**
 * Title: Newsletter signup
 * Slug: rcobeca/newsletter-signup
 * Categories: call-to-action
 * Inserter: no
 * Description: The site-wide newsletter slot used by the footer. Its button is the RCOBECA plugin's newsletter sign-up block, which leads to the Zeffy sign-up form set under Settings → Join and newsletter.
 *
 * @package RCOBECA
 */

?>
<!-- wp:group {"align":"wide","className":"rcobeca-newsletter","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"center"}} -->
<div class="wp-block-group alignwide rcobeca-newsletter">
	<!-- wp:group {"className":"rcobeca-newsletter__intro","layout":{"type":"default"}} -->
	<div class="wp-block-group rcobeca-newsletter__intro">
		<!-- wp:heading {"level":2,"className":"rcobeca-newsletter__heading"} -->
		<h2 class="wp-block-heading rcobeca-newsletter__heading">Stay in touch</h2>
		<!-- /wp:heading -->
		<!-- wp:paragraph -->
		<p>News of the Royal Charity Ball, our Projects and get-togethers, a few times a year.</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:rcobeca/newsletter-signup /-->
</div>
<!-- /wp:group -->
