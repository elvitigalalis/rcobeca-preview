<?php
/**
 * Title: Page header
 * Slug: rcobeca/page-header
 * Categories: rcobeca
 * Keywords: title, hero, intro
 * Description: Cream title band for a page: kicker, the page title (H1) and a one-sentence lead.
 *
 * @package RCOBECA
 */

?>
<!-- wp:group {"align":"full","className":"rcobeca-page-header","backgroundColor":"cream","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull rcobeca-page-header has-cream-background-color has-background" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:paragraph {"className":"is-style-kicker"} -->
	<p class="is-style-kicker">About RCOBECA</p>
	<!-- /wp:paragraph -->
	<!-- wp:post-title {"level":1} /-->
	<!-- wp:paragraph {"fontSize":"large"} -->
	<p class="has-large-font-size">One sentence that tells a visitor what this page is for.</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
