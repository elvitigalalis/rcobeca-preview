<?php
/**
 * Title: Photo gallery
 * Slug: rcobeca/photo-gallery
 * Categories: rcobeca, gallery
 * Keywords: photos, album, gallery, lightbox, event
 * Description: A three-column Gallery whose photos open in the lightbox. Keep "Link to: Media file" when you swap in your photos, give each one alt text, and credit the photographer in the caption.
 *
 * @package RCOBECA
 */

$rcobeca_photos = array(
	'committee-2025.webp'        => 'The 2025 Committee at the 29th Royal Charity Ball',
	'committee-stage.webp'       => 'Committee members standing together on a stage',
	'handover.webp'              => 'Guests gathered in a trophy room at Royal College',
	'principal-meeting.webp'     => 'Officials seated around a boardroom table at Royal College',
	'smart-conference-room.webp' => 'The smart conference room at Royal College in use',
	'school-supplies.webp'       => 'A young pupil receives school supplies in a classroom',
);
?>
<!-- wp:gallery {"columns":3,"linkTo":"media","sizeSlug":"large","align":"wide","className":"rcobeca-gallery"} -->
<figure class="wp-block-gallery alignwide has-nested-images columns-3 is-cropped rcobeca-gallery">
	<?php foreach ( $rcobeca_photos as $rcobeca_file => $rcobeca_alt ) : ?>
		<?php $rcobeca_src = get_theme_file_uri( 'assets/images/samples/' . $rcobeca_file ); ?>
	<!-- wp:image {"sizeSlug":"large","linkDestination":"media"} -->
	<figure class="wp-block-image size-large"><a href="<?php echo esc_url( $rcobeca_src ); ?>"><img src="<?php echo esc_url( $rcobeca_src ); ?>" alt="<?php echo esc_attr( $rcobeca_alt ); ?>"/></a></figure>
	<!-- /wp:image -->
	<?php endforeach; ?>
	<figcaption class="blocks-gallery-caption wp-element-caption">Photographs: RCOBECA. Select a photo to open the viewer.</figcaption>
</figure>
<!-- /wp:gallery -->
