<?php
/**
 * Title: Post list
 * Slug: rcobeca/post-list
 * Inserter: no
 * Description: The listing used by the index, archive and search templates: the current query as a hairline-separated list (date, title, excerpt, thumbnail), then pagination.
 *
 * @package RCOBECA
 */

?>
<!-- wp:query {"queryId":1,"query":{"inherit":true},"align":"wide","className":"rcobeca-post-list"} -->
<div class="wp-block-query alignwide rcobeca-post-list">
	<!-- wp:post-template {"layout":{"type":"default"}} -->
		<!-- wp:group {"className":"rcobeca-post-list__item","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between","verticalAlignment":"top"}} -->
		<div class="wp-block-group rcobeca-post-list__item">
			<!-- wp:group {"className":"rcobeca-post-list__text","layout":{"type":"default"}} -->
			<div class="wp-block-group rcobeca-post-list__text">
				<!-- wp:post-date {"className":"rcobeca-post-list__date"} /-->
				<!-- wp:post-title {"level":2,"isLink":true,"className":"rcobeca-post-list__title"} /-->
				<!-- wp:post-excerpt {"excerptLength":32,"className":"rcobeca-post-list__excerpt"} /-->
			</div>
			<!-- /wp:group -->
			<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"4/3","width":"220px","className":"rcobeca-post-list__image"} /-->
		</div>
		<!-- /wp:group -->
	<!-- /wp:post-template -->

	<!-- wp:query-no-results -->
		<!-- wp:paragraph {"className":"rcobeca-post-list__empty"} -->
		<p class="rcobeca-post-list__empty">Nothing matched. Try other words, or browse the menu above.</p>
		<!-- /wp:paragraph -->
	<!-- /wp:query-no-results -->

	<!-- wp:query-pagination {"layout":{"type":"flex","justifyContent":"space-between"},"className":"rcobeca-pagination"} -->
		<!-- wp:query-pagination-previous {"label":"Newer"} /-->
		<!-- wp:query-pagination-numbers /-->
		<!-- wp:query-pagination-next {"label":"Older"} /-->
	<!-- /wp:query-pagination -->
</div>
<!-- /wp:query -->
