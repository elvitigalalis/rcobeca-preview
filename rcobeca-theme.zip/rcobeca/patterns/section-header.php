<?php
/**
 * Title: Section header
 * Slug: rcobeca/section-header
 * Categories: rcobeca
 * Keywords: heading, kicker, label, intro
 * Description: The small italic serif label above a section headline, with an optional intro and a link to more.
 *
 * @package RCOBECA
 */

?>
<!-- wp:group {"align":"wide","className":"rcobeca-section-header","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group alignwide rcobeca-section-header">
	<!-- wp:group {"className":"rcobeca-section-header__text","layout":{"type":"default"}} -->
	<div class="wp-block-group rcobeca-section-header__text">
		<!-- wp:paragraph {"className":"is-style-kicker"} -->
		<p class="is-style-kicker">Our impact</p>
		<!-- /wp:paragraph -->
		<!-- wp:heading -->
		<h2 class="wp-block-heading">Giving back to Royal College since 1993</h2>
		<!-- /wp:heading -->
		<!-- wp:paragraph {"className":"rcobeca-section-header__intro"} -->
		<p class="rcobeca-section-header__intro">Classrooms, sports facilities and relief in Sri Lanka, funded by Old Boys on the East Coast.</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->
	<!-- wp:paragraph {"className":"rcobeca-more"} -->
	<p class="rcobeca-more"><a href="<?php echo esc_url( home_url( '/projects/' ) ); ?>">See all Projects</a></p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
