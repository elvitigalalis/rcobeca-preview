<?php
/**
 * Title: Style guide: blocks
 * Slug: rcobeca/style-guide-blocks
 * Inserter: no
 * Description: The RCOBECA plugin's Zeffy card and the lightbox gallery, as page slices use them. Rendered on the style-guide page.
 *
 * @package RCOBECA
 */

?>
<!-- wp:group {"align":"full","className":"rcobeca-sg-section","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull rcobeca-sg-section">
	<!-- wp:paragraph {"className":"is-style-kicker"} -->
	<p class="is-style-kicker">Blocks</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading -->
	<h2 class="wp-block-heading">Payments and photos</h2>
	<!-- /wp:heading -->
	<!-- wp:paragraph -->
	<p>The Zeffy card embeds any Zeffy form inline with our trust copy around it. A Gallery whose images link to their media files opens in an accessible lightbox.</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","className":"rcobeca-sg-example","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull rcobeca-sg-example" aria-label="Block: Zeffy card">
	<!-- wp:paragraph {"align":"wide","className":"rcobeca-sg-label"} -->
	<p class="alignwide rcobeca-sg-label"><strong>Zeffy card</strong> <code>rcobeca/zeffy-card</code></p>
	<!-- /wp:paragraph -->
	<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
	<div class="wp-block-columns alignwide">
		<!-- wp:column {"width":"45%"} -->
		<div class="wp-block-column" style="flex-basis:45%">
			<!-- wp:paragraph {"className":"is-style-kicker"} -->
			<p class="is-style-kicker">Royal Charity Ball 2026</p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"fontSize":"xx-large"} -->
			<h3 class="wp-block-heading has-xx-large-font-size">The form sits in our card, never on a bare page</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p>Give the block the link from Zeffy’s Share menu. It switches to Zeffy’s embed address, sets the height for the kind of form, and adds the RCOBEC Foundation trust lines outside the iframe.</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph -->
			<p>Pair it with an appeal like this one: what the money does, then the form.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:rcobeca/zeffy-card {"formUrl":"https://www.zeffy.com/en-US/ticketing/30th-annual-royal-charity-ball","heading":"Tickets for the 30th Royal Charity Ball"} /-->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","className":"rcobeca-sg-example","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull rcobeca-sg-example" aria-label="Block: Form">
	<!-- wp:paragraph {"align":"wide","className":"rcobeca-sg-label"} -->
	<p class="alignwide rcobeca-sg-label"><strong>Form</strong> <code>rcobeca/form</code> (Contact or Update your details; emailed to the Secretary, never stored)</p>
	<!-- /wp:paragraph -->
	<!-- wp:rcobeca/form {"form":"contact"} /-->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","className":"rcobeca-sg-example","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull rcobeca-sg-example" aria-label="Block: Table Lookup">
	<!-- wp:paragraph {"align":"wide","className":"rcobeca-sg-label"} -->
	<p class="alignwide rcobeca-sg-label"><strong>Table Lookup</strong> <code>rcobeca/table-lookup</code> (Ball night's "Find your table", on the Ball page and /table/; shown here on made-up demo guests)</p>
	<!-- /wp:paragraph -->
	<!-- wp:rcobeca/table-lookup {"demo":true} /-->
</section>
<!-- /wp:group -->

<?php $rcobeca_sg_ball = class_exists( 'RCOBECA\Events' ) ? RCOBECA\Events::current_ball() : 0; ?>
<!-- wp:group {"tagName":"section","align":"full","className":"rcobeca-sg-example","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull rcobeca-sg-example" aria-label="Block: Event details">
	<!-- wp:paragraph {"align":"wide","className":"rcobeca-sg-label"} -->
	<p class="alignwide rcobeca-sg-label"><strong>Event details</strong> <code>rcobeca/event-details</code> (filled from an Event's fields; on every Event page and the Ball page)</p>
	<!-- /wp:paragraph -->
	<!-- wp:group {"align":"wide","layout":{"type":"constrained","contentSize":"21rem","justifyContent":"left"}} -->
	<div class="wp-block-group alignwide">
		<!-- wp:rcobeca/event-details {"eventId":<?php echo (int) $rcobeca_sg_ball; ?>} /-->
	</div>
	<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","className":"rcobeca-sg-example","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull rcobeca-sg-example" aria-label="Block: Gallery">
	<!-- wp:paragraph {"align":"wide","className":"rcobeca-sg-label"} -->
	<p class="alignwide rcobeca-sg-label"><strong>Gallery with lightbox</strong> <code>core/gallery</code> linked to media files, pattern <code>rcobeca/photo-gallery</code></p>
	<!-- /wp:paragraph -->
	<!-- wp:pattern {"slug":"rcobeca/photo-gallery"} /-->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","className":"rcobeca-sg-example","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull rcobeca-sg-example" aria-label="Block: Impact numbers">
	<!-- wp:paragraph {"align":"wide","className":"rcobeca-sg-label"} -->
	<p class="alignwide rcobeca-sg-label"><strong>Impact numbers</strong> <code>rcobeca/impact-numbers</code> (counted from the records, each linked to its proof; one extra figure can be typed in)</p>
	<!-- /wp:paragraph -->
	<!-- wp:rcobeca/impact-numbers {"align":"full"} /-->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","className":"rcobeca-sg-example","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull rcobeca-sg-example" aria-label="Block: Royal Charity Ball band">
	<!-- wp:paragraph {"align":"wide","className":"rcobeca-sg-label"} -->
	<p class="alignwide rcobeca-sg-label"><strong>Royal Charity Ball band</strong> <code>rcobeca/ball-band</code> (the current Ball, in the Ball page's state)</p>
	<!-- /wp:paragraph -->
	<!-- wp:rcobeca/ball-band {"align":"full"} /-->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","className":"rcobeca-sg-example","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull rcobeca-sg-example" aria-label="Block: News">
	<!-- wp:paragraph {"align":"wide","className":"rcobeca-sg-label"} -->
	<p class="alignwide rcobeca-sg-label"><strong>News</strong> <code>rcobeca/news-list</code> (Project and Event stories, newest first; three on the home page, the full feed on News)</p>
	<!-- /wp:paragraph -->
	<!-- wp:rcobeca/news-list {"limit":3,"headingLevel":3,"align":"wide"} /-->
</section>
<!-- /wp:group -->
