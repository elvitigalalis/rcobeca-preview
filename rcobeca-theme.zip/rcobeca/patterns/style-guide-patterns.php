<?php
/**
 * Title: Style guide: patterns
 * Slug: rcobeca/style-guide-patterns
 * Inserter: no
 * Description: Every shared pattern, each labelled with its slug. Rendered on the style-guide page.
 *
 * @package RCOBECA
 */

$rcobeca_patterns = array(
	'rcobeca/page-header'     => 'Page header',
	'rcobeca/section-header'  => 'Section header',
	'rcobeca/colour-band'     => 'Colour band',
	'rcobeca/action-links'    => 'Action links',
	'rcobeca/card-grid'       => 'Card grid',
	'rcobeca/impact-band'     => 'Impact band',
	'rcobeca/testimonial'     => 'Testimonial',
	'rcobeca/cta-band'        => 'Call-to-action band',
	'rcobeca/newsletter-band' => 'Newsletter band',
);
?>
<!-- wp:group {"align":"full","className":"rcobeca-sg-section","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull rcobeca-sg-section">
	<!-- wp:paragraph {"className":"is-style-kicker"} -->
	<p class="is-style-kicker">Patterns</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading -->
	<h2 class="wp-block-heading">Shared sections</h2>
	<!-- /wp:heading -->
	<!-- wp:paragraph -->
	<p>Insert these from the RCOBECA category in the block inserter, then replace the sample words and photos. Alternate white, cream and blue bands down a page.</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<?php foreach ( $rcobeca_patterns as $rcobeca_slug => $rcobeca_title ) : ?>
<!-- wp:group {"tagName":"section","align":"full","className":"rcobeca-sg-example","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull rcobeca-sg-example" aria-label="Pattern: <?php echo esc_attr( $rcobeca_title ); ?>">
	<!-- wp:paragraph {"align":"wide","className":"rcobeca-sg-label"} -->
	<p class="alignwide rcobeca-sg-label"><strong><?php echo esc_html( $rcobeca_title ); ?></strong> <code><?php echo esc_html( $rcobeca_slug ); ?></code></p>
	<!-- /wp:paragraph -->
	<!-- wp:pattern {"slug":"<?php echo esc_attr( $rcobeca_slug ); ?>"} /-->
</section>
<!-- /wp:group -->
<?php endforeach; ?>
