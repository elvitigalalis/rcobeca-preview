<?php
/**
 * Title: Style guide: tokens
 * Slug: rcobeca/style-guide-tokens
 * Inserter: no
 * Description: Every design token from theme.json (colours, type scale, spacing, widths) plus the button styles. Rendered on the style-guide page.
 *
 * @package RCOBECA
 */

$rcobeca_palette = wp_get_global_settings( array( 'color', 'palette', 'theme' ) );
$rcobeca_sizes   = wp_get_global_settings( array( 'typography', 'fontSizes', 'theme' ) );
$rcobeca_spacing = wp_get_global_settings( array( 'spacing', 'spacingSizes', 'theme' ) );
$rcobeca_layout  = wp_get_global_settings( array( 'layout' ) );
$rcobeca_dark    = array( 'primary', 'primary-deep', 'contrast', 'muted', 'accent-deep' );
?>
<!-- wp:group {"tagName":"section","align":"full","className":"rcobeca-sg-section","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull rcobeca-sg-section">
	<!-- wp:paragraph {"className":"is-style-kicker"} -->
	<p class="is-style-kicker">Tokens</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading -->
	<h2 class="wp-block-heading">Colour</h2>
	<!-- /wp:heading -->
	<!-- wp:paragraph -->
	<p>White pages with cream bands for rhythm. Royal blue carries bands and actions, navy the footer and overlay menu. Gold is an accent: rules, the crest, kickers on dark bands and the Donate button. Use Antique gold for gold text on light backgrounds.</p>
	<!-- /wp:paragraph -->

	<!-- wp:group {"align":"wide","className":"rcobeca-sg-swatches","layout":{"type":"grid","minimumColumnWidth":"11rem"}} -->
	<div class="wp-block-group alignwide rcobeca-sg-swatches">
		<?php foreach ( $rcobeca_palette as $rcobeca_colour ) : ?>
		<!-- wp:group {"className":"rcobeca-sg-swatch","layout":{"type":"default"}} -->
		<div class="wp-block-group rcobeca-sg-swatch">
			<!-- wp:group {"className":"rcobeca-sg-swatch__chip","backgroundColor":"<?php echo esc_attr( $rcobeca_colour['slug'] ); ?>","layout":{"type":"default"}} -->
			<div class="wp-block-group rcobeca-sg-swatch__chip has-<?php echo esc_attr( $rcobeca_colour['slug'] ); ?>-background-color has-background"></div>
			<!-- /wp:group -->
			<!-- wp:paragraph -->
			<p><strong><?php echo esc_html( $rcobeca_colour['name'] ); ?></strong><br><code><?php echo esc_html( strtoupper( $rcobeca_colour['color'] ) ); ?></code> <code><?php echo esc_html( $rcobeca_colour['slug'] ); ?></code></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->
		<?php endforeach; ?>
	</div>
	<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","className":"rcobeca-sg-section","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull rcobeca-sg-section">
	<!-- wp:paragraph {"className":"is-style-kicker"} -->
	<p class="is-style-kicker">Tokens</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading -->
	<h2 class="wp-block-heading">Type</h2>
	<!-- /wp:heading -->
	<!-- wp:paragraph -->
	<p>Newsreader (serif) for headings, quotes and kickers; Inter (sans) for body text and interface. Both are self-hosted under the SIL Open Font License. Sizes are fluid between phone and desktop.</p>
	<!-- /wp:paragraph -->

	<!-- wp:group {"align":"wide","className":"rcobeca-sg-type","layout":{"type":"default"}} -->
	<div class="wp-block-group alignwide rcobeca-sg-type">
		<?php
		foreach ( array_reverse( $rcobeca_sizes ) as $rcobeca_size ) :
			$rcobeca_serif = ! in_array( $rcobeca_size['slug'], array( 'medium', 'small' ), true );
			?>
		<!-- wp:group {"className":"rcobeca-sg-type__row","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"bottom"}} -->
		<div class="wp-block-group rcobeca-sg-type__row">
			<!-- wp:paragraph {"className":"rcobeca-sg-type__meta"} -->
			<p class="rcobeca-sg-type__meta"><strong><?php echo esc_html( $rcobeca_size['name'] ); ?></strong><br><code><?php echo esc_html( $rcobeca_size['slug'] ); ?></code></p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"<?php echo esc_attr( $rcobeca_size['slug'] ); ?>"<?php echo $rcobeca_serif ? ',"fontFamily":"serif"' : ''; ?>,"className":"rcobeca-sg-type__sample"} -->
			<p class="rcobeca-sg-type__sample has-<?php echo esc_attr( $rcobeca_size['slug'] ); ?>-font-size<?php echo $rcobeca_serif ? ' has-serif-font-family' : ''; ?>">Royal College, East Coast</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->
		<?php endforeach; ?>
	</div>
	<!-- /wp:group -->

	<!-- wp:paragraph {"className":"is-style-kicker"} -->
	<p class="is-style-kicker">Kicker: the small italic label above a section headline</p>
	<!-- /wp:paragraph -->
	<!-- wp:paragraph {"fontSize":"large"} -->
	<p class="has-large-font-size">A lead paragraph introduces a page or section in one or two sentences.</p>
	<!-- /wp:paragraph -->
	<!-- wp:paragraph -->
	<p>Body text is set at 17px with generous leading and a reading width of about 68 characters. <a href="#type">Links are underlined</a> in royal blue.</p>
	<!-- /wp:paragraph -->
	<!-- wp:quote -->
	<blockquote class="wp-block-quote"><!-- wp:paragraph -->
	<p>A quote is set in the serif italic with a gold rule.</p>
	<!-- /wp:paragraph --><cite>Name, batch of 1985</cite></blockquote>
	<!-- /wp:quote -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","className":"rcobeca-sg-section","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull rcobeca-sg-section">
	<!-- wp:paragraph {"className":"is-style-kicker"} -->
	<p class="is-style-kicker">Tokens</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading -->
	<h2 class="wp-block-heading">Spacing and widths</h2>
	<!-- /wp:heading -->
	<!-- wp:paragraph -->
	<p>Fluid spacing steps, used for gaps and section padding (step 60 between sections, 80 for heroes).</p>
	<!-- /wp:paragraph -->
	<!-- wp:group {"className":"rcobeca-sg-spacing","layout":{"type":"default"}} -->
	<div class="wp-block-group rcobeca-sg-spacing">
		<?php foreach ( $rcobeca_spacing as $rcobeca_step ) : ?>
		<!-- wp:group {"className":"rcobeca-sg-spacing__row","layout":{"type":"flex","flexWrap":"nowrap"}} -->
		<div class="wp-block-group rcobeca-sg-spacing__row">
			<!-- wp:paragraph {"className":"rcobeca-sg-spacing__label"} -->
			<p class="rcobeca-sg-spacing__label">spacing <?php echo esc_html( $rcobeca_step['slug'] ); ?></p>
			<!-- /wp:paragraph -->
			<!-- wp:group {"className":"rcobeca-sg-spacing__bar","style":{"dimensions":{"minHeight":"0.75rem"},"layout":{"selfStretch":"fixed","flexSize":"var:preset|spacing|<?php echo esc_attr( $rcobeca_step['slug'] ); ?>"}},"backgroundColor":"primary","layout":{"type":"default"}} -->
			<div class="wp-block-group rcobeca-sg-spacing__bar has-primary-background-color has-background" style="min-height:0.75rem;flex-basis:var(--wp--preset--spacing--<?php echo esc_attr( $rcobeca_step['slug'] ); ?>)"></div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:group -->
		<?php endforeach; ?>
	</div>
	<!-- /wp:group -->

	<!-- wp:paragraph {"className":"rcobeca-sg-width"} -->
	<p class="rcobeca-sg-width">Reading width, <?php echo esc_html( $rcobeca_layout['contentSize'] ); ?></p>
	<!-- /wp:paragraph -->
	<!-- wp:paragraph {"align":"wide","className":"rcobeca-sg-width"} -->
	<p class="alignwide rcobeca-sg-width">Wide width, <?php echo esc_html( $rcobeca_layout['wideSize'] ); ?></p>
	<!-- /wp:paragraph -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","className":"rcobeca-sg-section","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull rcobeca-sg-section">
	<!-- wp:paragraph {"className":"is-style-kicker"} -->
	<p class="is-style-kicker">Tokens</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading -->
	<h2 class="wp-block-heading">Buttons and shape</h2>
	<!-- /wp:heading -->
	<!-- wp:paragraph -->
	<p>Square corners on images and cards, 2px on buttons, 1px hairlines and no shadows. Gold is reserved for Donate.</p>
	<!-- /wp:paragraph -->
	<!-- wp:buttons -->
	<div class="wp-block-buttons">
		<!-- wp:button -->
		<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#buttons">Primary</a></div>
		<!-- /wp:button -->
		<!-- wp:button {"className":"is-style-outline"} -->
		<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#buttons">Outline</a></div>
		<!-- /wp:button -->
		<!-- wp:button {"className":"is-style-gold"} -->
		<div class="wp-block-button is-style-gold"><a class="wp-block-button__link wp-element-button" href="#buttons">Gold (Donate)</a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
	<!-- wp:separator {"className":"is-style-wide"} -->
	<hr class="wp-block-separator has-alpha-channel-opacity is-style-wide"/>
	<!-- /wp:separator -->
</section>
<!-- /wp:group -->
