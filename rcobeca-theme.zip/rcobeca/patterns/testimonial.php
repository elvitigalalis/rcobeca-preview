<?php
/**
 * Title: Testimonial
 * Slug: rcobeca/testimonial
 * Categories: rcobeca
 * Keywords: quote, testimonial, voice, member
 * Description: A large italic serif quote with its attribution beside a candid photo. Replace the sample text with an Old Boy's own words, and his name and batch.
 *
 * @package RCOBECA
 */

?>
<!-- wp:columns {"verticalAlignment":"center","align":"wide","className":"rcobeca-testimonial","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center rcobeca-testimonial">
	<!-- wp:column {"verticalAlignment":"center","width":"56%"} -->
	<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:56%">
		<!-- wp:quote {"className":"is-style-plain rcobeca-testimonial__quote"} -->
		<blockquote class="wp-block-quote is-style-plain rcobeca-testimonial__quote"><!-- wp:paragraph -->
		<p>Royal gave us our start. Here, a long way from Colombo, we meet as old friends and give the next boys theirs.</p>
		<!-- /wp:paragraph --><cite>Sample quote: replace with an Old Boy&#8217;s words, name and batch</cite></blockquote>
		<!-- /wp:quote -->
	</div>
	<!-- /wp:column -->
	<!-- wp:column {"verticalAlignment":"center"} -->
	<div class="wp-block-column is-vertically-aligned-center">
		<!-- wp:image {"aspectRatio":"4/3","scale":"cover","sizeSlug":"large","className":"rcobeca-testimonial__image"} -->
		<figure class="wp-block-image size-large rcobeca-testimonial__image"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/samples/members-gathering.webp' ) ); ?>" alt="RCOBECA members gathered outdoors in suits for a group photograph" style="aspect-ratio:4/3;object-fit:cover"/></figure>
		<!-- /wp:image -->
	</div>
	<!-- /wp:column -->
</div>
<!-- /wp:columns -->
